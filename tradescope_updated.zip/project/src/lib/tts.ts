// Text-to-Speech utility for the 10 Principles audio system

let speechSynth: SpeechSynthesis | null = null;
let currentUtterance: SpeechSynthesisUtterance | null = null;
let isPlaying = false;
let currentIndex = 0;
let onProgressCallback: ((index: number) => void) | null = null;
let onCompleteCallback: (() => void) | null = null;

export function initTTS() {
  if (typeof window !== 'undefined' && window.speechSynthesis) {
    speechSynth = window.speechSynthesis;
  }
  return !!speechSynth;
}

export function isTTSAvailable(): boolean {
  return typeof window !== 'undefined' && !!window.speechSynthesis;
}

export function speakText(
  text: string,
  options?: { lang?: string; rate?: number; pitch?: number; onEnd?: () => void }
): boolean {
  if (!speechSynth) initTTS();
  if (!speechSynth) return false;

  speechSynth.cancel();
  const utterance = new SpeechSynthesisUtterance(text);
  utterance.lang = options?.lang || 'ar-SA';
  utterance.rate = options?.rate || 0.9;
  utterance.pitch = options?.pitch || 1;

  // Try to find an Arabic voice
  const voices = speechSynth.getVoices();
  const arabicVoice = voices.find(v => v.lang.startsWith('ar'));
  if (arabicVoice) utterance.voice = arabicVoice;

  if (options?.onEnd) utterance.onend = options.onEnd;
  currentUtterance = utterance;
  speechSynth.speak(utterance);
  return true;
}

export function speakPrinciplesSequentially(
  principles: { text: string; checked: boolean; why: string }[],
  onProgress: (index: number) => void,
  onComplete: () => void
) {
  if (!speechSynth) initTTS();
  if (!speechSynth) return;

  isPlaying = true;
  currentIndex = 0;
  onProgressCallback = onProgress;
  onCompleteCallback = onComplete;

  speakNextPrinciple(principles);
}

function speakNextPrinciple(
  principles: { text: string; checked: boolean; why: string }[]
) {
  if (!speechSynth || !isPlaying || currentIndex >= principles.length) {
    isPlaying = false;
    onCompleteCallback?.();
    return;
  }

  const p = principles[currentIndex];
  onProgressCallback?.(currentIndex);

  const statusText = p.checked ? 'نعم، تم الالتزام' : 'لا، لم يتم الالتزام';
  const whyText = p.why ? `السبب: ${p.why}` : '';
  const fullText = `المبدأ رقم ${currentIndex + 1}: ${p.text}. هل التزمت به اليوم؟ ${statusText}. ${whyText}`;

  const utterance = new SpeechSynthesisUtterance(fullText);
  utterance.lang = 'ar-SA';
  utterance.rate = 0.85;
  utterance.pitch = 1;

  const voices = speechSynth!.getVoices();
  const arabicVoice = voices.find(v => v.lang.startsWith('ar'));
  if (arabicVoice) utterance.voice = arabicVoice;

  utterance.onend = () => {
    currentIndex++;
    setTimeout(() => speakNextPrinciple(principles), 600);
  };

  currentUtterance = utterance;
  speechSynth!.speak(utterance);
}

export function stopSpeaking() {
  isPlaying = false;
  if (speechSynth) speechSynth.cancel();
}

export function getIsPlaying(): boolean {
  return isPlaying;
}
