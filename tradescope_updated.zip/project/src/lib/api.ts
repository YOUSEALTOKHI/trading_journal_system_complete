const API_BASE = '/api';

async function request<T>(url: string, options?: RequestInit): Promise<T> {
  const res = await fetch(`${API_BASE}${url}`, {
    headers: { 'Content-Type': 'application/json' },
    ...options,
  });
  if (!res.ok) {
    const err = await res.json().catch(() => ({ error: 'Unknown error' }));
    throw new Error(err.error || `HTTP ${res.status}`);
  }
  return res.json();
}

export const api = {
  getTrades: (params?: Record<string, string>) => {
    const qs = params ? '?' + new URLSearchParams(params).toString() : '';
    return request<any[]>(`/trades${qs}`);
  },
  createTrades: (trades: any[]) => request<any[]>('/trades', { method: 'POST', body: JSON.stringify(trades) }),
  updateTrade: (data: any) => request<any>('/trades', { method: 'PUT', body: JSON.stringify(data) }),
  deleteTrade: (id: number) => request<any>('/trades', { method: 'DELETE', body: JSON.stringify({ id }) }),

  getDebriefings: (params?: Record<string, string>) => {
    const qs = params ? '?' + new URLSearchParams(params).toString() : '';
    return request<any[]>(`/debriefings${qs}`);
  },
  createDebriefing: (data: any) => request<any>('/debriefings', { method: 'POST', body: JSON.stringify(data) }),
  updateDebriefing: (data: any) => request<any>('/debriefings', { method: 'PUT', body: JSON.stringify(data) }),

  getCoachFeedback: (params?: Record<string, string>) => {
    const qs = params ? '?' + new URLSearchParams(params).toString() : '';
    return request<any[]>(`/ai-coach${qs}`);
  },
  requestCoachAnalysis: (data: { date: string; action_plan?: string; plan_adherence?: string }) =>
    request<any>('/ai-coach', { method: 'POST', body: JSON.stringify(data) }),

  getWeeklySummaries: (params?: Record<string, string>) => {
    const qs = params ? '?' + new URLSearchParams(params).toString() : '';
    return request<any[]>(`/weekly-summaries${qs}`);
  },
  createWeeklySummary: (data: any) => request<any>('/weekly-summaries', { method: 'POST', body: JSON.stringify(data) }),
  updateWeeklySummary: (data: any) => request<any>('/weekly-summaries', { method: 'PUT', body: JSON.stringify(data) }),

  getMonthlySummaries: (params?: Record<string, string>) => {
    const qs = params ? '?' + new URLSearchParams(params).toString() : '';
    return request<any[]>(`/monthly-summaries${qs}`);
  },
  createMonthlySummary: (data: any) => request<any>('/monthly-summaries', { method: 'POST', body: JSON.stringify(data) }),
  updateMonthlySummary: (data: any) => request<any>('/monthly-summaries', { method: 'PUT', body: JSON.stringify(data) }),

  getReports: (params?: Record<string, string>) => {
    const qs = params ? '?' + new URLSearchParams(params).toString() : '';
    return request<any[]>(`/reports${qs}`);
  },
  createReport: (data: any) => request<any>('/reports', { method: 'POST', body: JSON.stringify(data) }),
  deleteReport: (id: number) => request<any>('/reports', { method: 'DELETE', body: JSON.stringify({ id }) }),

  getStats: (params: Record<string, string>) => {
    const qs = '?' + new URLSearchParams(params).toString();
    return request<any>(`/stats${qs}`);
  },

  // Trader Content
  getTraderContent: (params?: Record<string, string>) => {
    const qs = params ? '?' + new URLSearchParams(params).toString() : '';
    return request<any[]>(`/trader-content${qs}`);
  },
  createTraderContent: (data: any) => request<any>('/trader-content', { method: 'POST', body: JSON.stringify(data) }),
  updateTraderContent: (data: any) => request<any>('/trader-content', { method: 'PUT', body: JSON.stringify(data) }),
  deleteTraderContent: (id: number) => request<any>('/trader-content', { method: 'DELETE', body: JSON.stringify({ id }) }),

  // Roadmap
  getRoadmap: (params?: Record<string, string>) => {
    const qs = params ? '?' + new URLSearchParams(params).toString() : '';
    return request<any[]>(`/roadmap${qs}`);
  },
  createRoadmapItem: (data: any) => request<any>('/roadmap', { method: 'POST', body: JSON.stringify(data) }),
  updateRoadmapItem: (data: any) => request<any>('/roadmap', { method: 'PUT', body: JSON.stringify(data) }),
  deleteRoadmapItem: (id: number) => request<any>('/roadmap', { method: 'DELETE', body: JSON.stringify({ id }) }),
};
