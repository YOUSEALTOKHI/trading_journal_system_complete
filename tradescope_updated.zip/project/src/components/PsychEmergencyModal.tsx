import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { X, Volume2, VolumeX, Heart, Shield } from 'lucide-react';
import { speakText, stopSpeaking, isTTSAvailable } from '../lib/tts';

const MANTRA = '\u0623\u0646\u0627 \u062a\u0627\u062c\u0631\u064c \u062c\u064e\u064a\u0651\u062f \u0641\u064a \u0633\u0648\u0642\u064a \u0645\u062a\u0645\u0643\u0646.. \u0623\u0646\u0627 \u0623\u0633\u062a\u0645\u062a\u0639 \u0628\u0627\u0644\u062d\u064a\u0627\u0629 \u0648\u0628\u0627\u0644\u0631\u0632\u0642\u0650 \u0623\u0637\u0645\u0646. \u0623\u0646\u0627 \u0633\u0639\u064a\u062f\u064c \u0628\u0645\u0627 \u0623\u0641\u0639\u0644\u0647 \u0648\u0627\u0644\u0631\u0636\u0627 \u0639\u0646\u0648\u0627\u0646\u064a.. \u0623\u0646\u0627 \u0645\u0642\u062a\u0646\u0639\u064c \u0628\u0645\u0633\u0627\u0631\u064a \u0648\u0628\u0642\u0648\u0629\u0650 \u0625\u064a\u0645\u0627\u0646\u064a. \u0623\u0646\u0627 \u0639\u0646\u062f\u0645\u0627 \u0623\u062d\u0636\u0631 \u0627\u0644\u062b\u0645\u0627\u0631\u064f \u062a\u0641\u064a\u0636.. \u0644\u064a \u0648\u0644\u0639\u0627\u0626\u0644\u062a\u064a \u0648\u0644\u0644\u0639\u0627\u0644\u0645 \u0646\u0641\u0639\u064c \u0639\u0631\u064a\u0636. \u0623\u0646\u0627 \u0623\u062d\u0627\u0641\u0638\u064f \u062f\u0648\u0645\u0627\u064b \u0639\u0644\u0649 \u062d\u0627\u0644\u062a\u064a \u0627\u0644\u0633\u0639\u064a\u062f\u0629.. \u062b\u0628\u0627\u062a\u064c \u0648\u0639\u0632\u0645\u064c \u0628\u0631\u0624\u064a\u0629\u064d \u0633\u062f\u064a\u062f\u0629.';

const MANTRA_LINES = [
  '\u0623\u0646\u0627 \u062a\u0627\u062c\u0631\u064c \u062c\u064e\u064a\u0651\u062f \u0641\u064a \u0633\u0648\u0642\u064a \u0645\u062a\u0645\u0643\u0646',
  '\u0623\u0646\u0627 \u0623\u0633\u062a\u0645\u062a\u0639 \u0628\u0627\u0644\u062d\u064a\u0627\u0629 \u0648\u0628\u0627\u0644\u0631\u0632\u0642\u0650 \u0623\u0637\u0645\u0646',
  '\u0623\u0646\u0627 \u0633\u0639\u064a\u062f\u064c \u0628\u0645\u0627 \u0623\u0641\u0639\u0644\u0647 \u0648\u0627\u0644\u0631\u0636\u0627 \u0639\u0646\u0648\u0627\u0646\u064a',
  '\u0623\u0646\u0627 \u0645\u0642\u062a\u0646\u0639\u064c \u0628\u0645\u0633\u0627\u0631\u064a \u0648\u0628\u0642\u0648\u0629\u0650 \u0625\u064a\u0645\u0627\u0646\u064a',
  '\u0623\u0646\u0627 \u0639\u0646\u062f\u0645\u0627 \u0623\u062d\u0636\u0631 \u0627\u0644\u062b\u0645\u0627\u0631\u064f \u062a\u0641\u064a\u0636',
  '\u0644\u064a \u0648\u0644\u0639\u0627\u0626\u0644\u062a\u064a \u0648\u0644\u0644\u0639\u0627\u0644\u0645 \u0646\u0641\u0639\u064c \u0639\u0631\u064a\u0636',
  '\u0623\u0646\u0627 \u0623\u062d\u0627\u0641\u0638\u064f \u062f\u0648\u0645\u0627\u064b \u0639\u0644\u0649 \u062d\u0627\u0644\u062a\u064a \u0627\u0644\u0633\u0639\u064a\u062f\u0629',
  '\u062b\u0628\u0627\u062a\u064c \u0648\u0639\u0632\u0645\u064c \u0628\u0631\u0624\u064a\u0629\u064d \u0633\u062f\u064a\u062f\u0629',
];

export default function PsychEmergencyModal({ isOpen, onClose }: { isOpen: boolean; onClose: () => void }) {
  const [speaking, setSpeaking] = useState(false);
  const [activeLine, setActiveLine] = useState(0);
  const [breathPhase, setBreathPhase] = useState<'inhale' | 'hold' | 'exhale'>('inhale');

  useEffect(() => {
    if (!isOpen) {
      stopSpeaking();
      setSpeaking(false);
      return;
    }
    // Breathing animation
    const cycle = () => {
      setBreathPhase('inhale');
      setTimeout(() => setBreathPhase('hold'), 4000);
      setTimeout(() => setBreathPhase('exhale'), 6000);
    };
    cycle();
    const interval = setInterval(cycle, 10000);
    // Auto-advance lines
    const lineInterval = setInterval(() => {
      setActiveLine(prev => (prev + 1) % MANTRA_LINES.length);
    }, 4000);
    return () => { clearInterval(interval); clearInterval(lineInterval); };
  }, [isOpen]);

  const toggleSpeak = () => {
    if (speaking) {
      stopSpeaking();
      setSpeaking(false);
    } else {
      setSpeaking(true);
      speakText(MANTRA, {
        lang: 'ar-SA',
        rate: 0.75,
        pitch: 0.9,
        onEnd: () => setSpeaking(false),
      });
    }
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
          className="fixed inset-0 z-[100] flex items-center justify-center" onClick={onClose}>
          {/* Calming background */}
          <div className="absolute inset-0 bg-gradient-to-b from-[#050a15] via-[#0a1628] to-[#050a15]" />
          <div className="absolute inset-0 overflow-hidden">
            {[...Array(20)].map((_, i) => (
              <motion.div key={i}
                className="absolute w-1 h-1 rounded-full bg-cyan-400/30"
                style={{ left: `${Math.random() * 100}%`, top: `${Math.random() * 100}%` }}
                animate={{ opacity: [0.1, 0.6, 0.1], scale: [1, 1.5, 1] }}
                transition={{ duration: 3 + Math.random() * 4, repeat: Infinity, delay: Math.random() * 3 }}
              />
            ))}
          </div>

          <motion.div initial={{ scale: 0.8, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} exit={{ scale: 0.8, opacity: 0 }}
            className="relative z-10 w-full max-w-xl mx-4" onClick={e => e.stopPropagation()}>

            {/* Close button */}
            <button onClick={onClose} className="absolute -top-12 left-1/2 -translate-x-1/2 p-2 rounded-full bg-white/5 text-gray-400 hover:text-white hover:bg-white/10">
              <X size={20} />
            </button>

            {/* Breathing circle */}
            <div className="flex justify-center mb-8">
              <motion.div
                className="rounded-full bg-gradient-to-br from-cyan-500/20 to-emerald-500/20 border border-cyan-500/20 flex items-center justify-center"
                animate={{
                  width: breathPhase === 'inhale' ? 140 : breathPhase === 'hold' ? 140 : 80,
                  height: breathPhase === 'inhale' ? 140 : breathPhase === 'hold' ? 140 : 80,
                }}
                transition={{ duration: breathPhase === 'inhale' ? 4 : breathPhase === 'hold' ? 2 : 4, ease: 'easeInOut' }}>
                <span className="text-sm text-cyan-300/80">
                  {breathPhase === 'inhale' ? '\u0634\u0647\u064a\u0642...' : breathPhase === 'hold' ? '\u0627\u0645\u0633\u0643...' : '\u0632\u0641\u064a\u0631...'}
                </span>
              </motion.div>
            </div>

            {/* Title */}
            <div className="text-center mb-6">
              <div className="flex items-center justify-center gap-2 mb-2">
                <Shield size={20} className="text-cyan-400" />
                <h2 className="text-xl font-bold text-white">\u0646\u0634\u064a\u062f \u0627\u0644\u062b\u0628\u0627\u062a</h2>
                <Shield size={20} className="text-cyan-400" />
              </div>
              <p className="text-xs text-gray-500">\u062a\u0646\u0641\u0633 \u0628\u0639\u0645\u0642... \u0627\u0642\u0631\u0623 \u0628\u0647\u062f\u0648\u0621... \u0623\u0646\u062a \u0641\u064a \u0623\u0645\u0627\u0646</p>
            </div>

            {/* Mantra lines */}
            <div className="space-y-3 mb-8">
              {MANTRA_LINES.map((line, i) => (
                <motion.div key={i}
                  animate={{ opacity: i === activeLine ? 1 : 0.3, scale: i === activeLine ? 1.05 : 1, x: i === activeLine ? 0 : 0 }}
                  transition={{ duration: 0.8 }}
                  className="text-center">
                  <p className={`text-lg leading-relaxed transition-colors duration-700 ${
                    i === activeLine ? 'text-cyan-300 font-semibold' : 'text-gray-600'
                  }`}>{line}</p>
                </motion.div>
              ))}
            </div>

            {/* Audio button */}
            {isTTSAvailable() && (
              <div className="flex justify-center">
                <button onClick={toggleSpeak}
                  className={`flex items-center gap-3 px-8 py-3 rounded-2xl text-sm font-medium transition-all ${
                    speaking
                      ? 'bg-red-500/20 text-red-300 border border-red-500/30'
                      : 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/30 hover:bg-cyan-500/30'
                  }`}>
                  {speaking ? <><VolumeX size={18} />\u0625\u064a\u0642\u0627\u0641 \u0627\u0644\u0635\u0648\u062a</> : <><Volume2 size={18} />\u062a\u0634\u063a\u064a\u0644 \u0627\u0644\u0646\u0634\u064a\u062f \u0635\u0648\u062a\u064a\u0627\u064b</>}
                </button>
              </div>
            )}

            {/* Calm message */}
            <motion.p
              animate={{ opacity: [0.3, 0.7, 0.3] }}
              transition={{ duration: 5, repeat: Infinity }}
              className="text-center text-xs text-gray-600 mt-6">
              \u0627\u0644\u0647\u062f\u0648\u0621 \u0647\u0648 \u0623\u0639\u0638\u0645 \u0642\u0648\u0629 \u0644\u0644\u0645\u062a\u062f\u0627\u0648\u0644
            </motion.p>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
