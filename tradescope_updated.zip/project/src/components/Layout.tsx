import { useState } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import {
  BarChart3, BookOpen, FileText, MessageSquare, TrendingUp, Upload,
  Calendar, CalendarDays, Menu, X, Home, PlusCircle, ClipboardCheck, Brain,
  Shield, Compass, AlertTriangle
} from 'lucide-react';
import PsychEmergencyModal from './PsychEmergencyModal';

const navSections = [
  {
    title: null,
    items: [
      { path: '/', label: 'الرئيسية', icon: Home },
    ]
  },
  {
    title: 'التداول',
    items: [
      { path: '/trades', label: 'الصفقات', icon: TrendingUp },
      { path: '/import', label: 'استيراد Statement', icon: Upload },
      { path: '/add-trade', label: 'إضافة صفقة', icon: PlusCircle },
      { path: '/debriefing', label: 'الديلي دبريفنج', icon: ClipboardCheck },
    ]
  },
  {
    title: 'لوحات التحكم',
    items: [
      { path: '/dashboard/daily', label: 'لوحة يومية', icon: Calendar },
      { path: '/dashboard/weekly', label: 'لوحة أسبوعية', icon: CalendarDays },
      { path: '/dashboard/monthly', label: 'لوحة شهرية', icon: BarChart3 },
    ]
  },
  {
    title: 'المتداول',
    items: [
      { path: '/hub', label: 'مركز المتداول', icon: Shield },
      { path: '/roadmap', label: 'مصفوفة النجاح', icon: Compass },
      { path: '/coach', label: 'المدرب الذكي', icon: Brain, badge: 'AI' },
    ]
  },
  {
    title: 'أخرى',
    items: [
      { path: '/reports', label: 'التقارير الأساسية', icon: FileText },
      { path: '/journal', label: 'اليوميات', icon: BookOpen },
      { path: '/chat', label: 'المساعد الذكي', icon: MessageSquare, badge: 'AI' },
    ]
  },
];

export default function Layout({ children }: { children: React.ReactNode }) {
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [psychModalOpen, setPsychModalOpen] = useState(false);
  const location = useLocation();

  return (
    <div className="min-h-screen bg-[#0a0e1a] text-gray-100 flex" dir="rtl">
      <AnimatePresence>
        {sidebarOpen && (
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/60 z-40 lg:hidden" onClick={() => setSidebarOpen(false)} />
        )}
      </AnimatePresence>

      <aside className={`fixed lg:static inset-y-0 right-0 z-50 w-72 bg-[#0d1224] border-l border-[#1a2340] transform transition-transform duration-300 lg:translate-x-0 ${
        sidebarOpen ? 'translate-x-0' : 'translate-x-full lg:translate-x-0'
      }`}>
        <div className="p-5 border-b border-[#1a2340]">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-emerald-500 to-cyan-500 flex items-center justify-center">
              <TrendingUp size={22} className="text-white" />
            </div>
            <div>
              <h1 className="text-lg font-bold text-white">TradeScope</h1>
              <p className="text-xs text-gray-500">نظام إدارة التداول</p>
            </div>
          </div>
        </div>
        <nav className="p-3 overflow-y-auto h-[calc(100vh-160px)]">
          {navSections.map((section, si) => (
            <div key={si} className={si > 0 ? 'mt-4' : ''}>
              {section.title && (
                <p className="px-4 py-1.5 text-[10px] font-semibold text-gray-600 uppercase tracking-wider">{section.title}</p>
              )}
              <div className="space-y-0.5">
                {section.items.map((item: any) => {
                  const isActive = location.pathname === item.path;
                  const Icon = item.icon;
                  return (
                    <Link key={item.path} to={item.path} onClick={() => setSidebarOpen(false)}
                      className={`flex items-center gap-3 px-4 py-2.5 rounded-xl transition-all duration-200 group ${
                        isActive
                          ? 'bg-gradient-to-l from-emerald-500/20 to-cyan-500/10 text-emerald-400 border border-emerald-500/20'
                          : 'text-gray-400 hover:text-gray-200 hover:bg-[#131b35]'
                      }`}>
                      <Icon size={18} className={isActive ? 'text-emerald-400' : 'text-gray-500 group-hover:text-gray-300'} />
                      <span className="text-sm font-medium">{item.label}</span>
                      {item.badge && (
                        <span className="mr-auto px-1.5 py-0.5 rounded text-[10px] bg-purple-500/20 text-purple-400">{item.badge}</span>
                      )}
                    </Link>
                  );
                })}
              </div>
            </div>
          ))}

          <div className="mt-6 px-2">
            <button onClick={() => setPsychModalOpen(true)}
              className="w-full flex items-center justify-center gap-2 px-4 py-3 rounded-xl bg-gradient-to-l from-red-900/40 to-orange-900/30 border border-red-500/20 text-red-400 hover:text-red-300 hover:border-red-500/40 transition-all group">
              <AlertTriangle size={18} className="group-hover:animate-pulse" />
              <span className="text-sm font-semibold">حالة الطوارئ النفسية</span>
            </button>
          </div>
        </nav>
      </aside>

      <div className="flex-1 flex flex-col min-h-screen overflow-x-hidden">
        <header className="sticky top-0 z-30 bg-[#0a0e1a]/80 backdrop-blur-xl border-b border-[#1a2340] px-4 lg:px-8 py-4">
          <div className="flex items-center justify-between">
            <button onClick={() => setSidebarOpen(true)} className="lg:hidden p-2 rounded-lg bg-[#131b35] text-gray-400 hover:text-white">
              {sidebarOpen ? <X size={20} /> : <Menu size={20} />}
            </button>
            <div className="flex items-center gap-3">
              <button onClick={() => setPsychModalOpen(true)}
                className="lg:hidden p-2 rounded-lg bg-red-500/10 text-red-400 hover:bg-red-500/20">
                <AlertTriangle size={18} />
              </button>
              <div className="text-sm text-gray-500">
                {new Date().toLocaleDateString('ar-EG', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' })}
              </div>
            </div>
          </div>
        </header>
        <main className="flex-1 p-4 lg:p-8">
          <motion.div key={location.pathname} initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.3 }}>
            {children}
          </motion.div>
        </main>
      </div>

      <PsychEmergencyModal isOpen={psychModalOpen} onClose={() => setPsychModalOpen(false)} />
    </div>
  );
}
