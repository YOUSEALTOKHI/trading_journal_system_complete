import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { X, Sparkles } from 'lucide-react';
import { api } from '../lib/api';

export default function DailyAffirmation() {
  const [affirmation, setAffirmation] = useState<any>(null);
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    // Check if already shown today
    const today = new Date().toISOString().split('T')[0];
    const lastShown = localStorage.getItem('affirmation_last_shown');
    if (lastShown === today) return;

    // Fetch beliefs and quotes for affirmations
    const fetchAffirmation = async () => {
      try {
        const [beliefs, quotes] = await Promise.all([
          api.getTraderContent({ category: 'beliefs' }),
          api.getTraderContent({ category: 'quotes' }),
        ]);
        const all = [...beliefs, ...quotes];
        if (all.length > 0) {
          const random = all[Math.floor(Math.random() * all.length)];
          setAffirmation(random);
          setVisible(true);
          localStorage.setItem('affirmation_last_shown', today);
        }
      } catch (err) { console.error(err); }
    };

    // Show after a short delay
    const timer = setTimeout(fetchAffirmation, 1500);
    return () => clearTimeout(timer);
  }, []);

  if (!visible || !affirmation) return null;

  return (
    <AnimatePresence>
      <motion.div
        initial={{ opacity: 0, y: -20, scale: 0.95 }}
        animate={{ opacity: 1, y: 0, scale: 1 }}
        exit={{ opacity: 0, y: -20, scale: 0.95 }}
        className="fixed top-20 left-1/2 -translate-x-1/2 z-50 w-full max-w-md mx-auto px-4"
      >
        <div className="bg-gradient-to-br from-[#0d1224] to-[#111833] border border-amber-500/20 rounded-2xl p-6 shadow-2xl shadow-amber-500/5">
          <div className="flex items-start justify-between mb-3">
            <div className="flex items-center gap-2">
              <Sparkles size={18} className="text-amber-400" />
              <span className="text-xs text-amber-400 font-medium">\u062a\u0623\u0643\u064a\u062f \u064a\u0648\u0645\u064a</span>
            </div>
            <button onClick={() => setVisible(false)} className="p-1 rounded-lg hover:bg-white/5 text-gray-500 hover:text-white">
              <X size={16} />
            </button>
          </div>
          <div className="text-center">
            <span className="text-3xl mb-3 block">{affirmation.icon || '\u2728'}</span>
            <h3 className="text-white font-semibold mb-2">{affirmation.title}</h3>
            <p className="text-sm text-gray-400 leading-relaxed">{affirmation.content}</p>
          </div>
          <button onClick={() => setVisible(false)}
            className="mt-4 w-full py-2 bg-amber-500/10 hover:bg-amber-500/20 border border-amber-500/20 rounded-xl text-amber-400 text-sm font-medium transition-colors">
            \u0628\u0633\u0645 \u0627\u0644\u0644\u0647 \u0646\u0628\u062f\u0623 \u0627\u0644\u064a\u0648\u0645 \u2728
          </button>
        </div>
      </motion.div>
    </AnimatePresence>
  );
}
