import { useEffect, useRef } from 'react';

interface ChartProps {
  type: 'line' | 'bar' | 'doughnut';
  data: { labels: string[]; datasets: { label: string; data: number[]; color: string }[] };
  height?: number;
  title?: string;
}

export default function Chart({ type, data, height = 250, title }: ChartProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const dpr = window.devicePixelRatio || 1;
    const rect = canvas.getBoundingClientRect();
    canvas.width = rect.width * dpr;
    canvas.height = height * dpr;
    canvas.style.height = `${height}px`;
    ctx.scale(dpr, dpr);

    const w = rect.width;
    const h = height;
    const padding = { top: 40, right: 20, bottom: 40, left: 60 };
    const chartW = w - padding.left - padding.right;
    const chartH = h - padding.top - padding.bottom;

    ctx.clearRect(0, 0, w, h);

    if (title) {
      ctx.fillStyle = '#9ca3af';
      ctx.font = '13px system-ui';
      ctx.textAlign = 'center';
      ctx.fillText(title, w / 2, 20);
    }

    if (!data.datasets.length || !data.labels.length) {
      ctx.fillStyle = '#4b5563';
      ctx.font = '14px system-ui';
      ctx.textAlign = 'center';
      ctx.fillText('لا توجد بيانات', w / 2, h / 2);
      return;
    }

    if (type === 'doughnut') {
      const dataset = data.datasets[0];
      const total = dataset.data.reduce((a, b) => a + b, 0);
      if (total === 0) return;
      const cx = w / 2;
      const cy = h / 2;
      const radius = Math.min(chartW, chartH) / 2.5;
      const colors = ['#10b981', '#ef4444', '#3b82f6', '#f59e0b', '#8b5cf6', '#06b6d4', '#ec4899', '#84cc16'];
      let startAngle = -Math.PI / 2;
      dataset.data.forEach((val, i) => {
        const sliceAngle = (val / total) * 2 * Math.PI;
        ctx.beginPath();
        ctx.moveTo(cx, cy);
        ctx.arc(cx, cy, radius, startAngle, startAngle + sliceAngle);
        ctx.fillStyle = colors[i % colors.length];
        ctx.fill();
        // Label
        const midAngle = startAngle + sliceAngle / 2;
        const lx = cx + Math.cos(midAngle) * (radius * 0.65);
        const ly = cy + Math.sin(midAngle) * (radius * 0.65);
        ctx.fillStyle = '#fff';
        ctx.font = '11px system-ui';
        ctx.textAlign = 'center';
        if (val / total > 0.05) {
          ctx.fillText(`${Math.round(val / total * 100)}%`, lx, ly);
        }
        startAngle += sliceAngle;
      });
      // Inner circle for donut
      ctx.beginPath();
      ctx.arc(cx, cy, radius * 0.5, 0, 2 * Math.PI);
      ctx.fillStyle = '#0d1224';
      ctx.fill();
      // Legend
      const legendY = h - 15;
      const legendSpacing = chartW / data.labels.length;
      data.labels.forEach((label, i) => {
        const lx = padding.left + i * legendSpacing + legendSpacing / 2;
        ctx.fillStyle = colors[i % colors.length];
        ctx.fillRect(lx - 20, legendY - 5, 8, 8);
        ctx.fillStyle = '#9ca3af';
        ctx.font = '10px system-ui';
        ctx.textAlign = 'start';
        ctx.fillText(label, lx - 8, legendY + 2);
      });
      return;
    }

    const allValues = data.datasets.flatMap(d => d.data);
    const minVal = Math.min(0, ...allValues);
    const maxVal = Math.max(...allValues);
    const range = maxVal - minVal || 1;

    // Grid lines
    const gridLines = 5;
    for (let i = 0; i <= gridLines; i++) {
      const y = padding.top + (chartH / gridLines) * i;
      ctx.strokeStyle = '#1a2340';
      ctx.lineWidth = 1;
      ctx.beginPath();
      ctx.moveTo(padding.left, y);
      ctx.lineTo(w - padding.right, y);
      ctx.stroke();
      const val = maxVal - (range / gridLines) * i;
      ctx.fillStyle = '#4b5563';
      ctx.font = '10px system-ui';
      ctx.textAlign = 'end';
      ctx.fillText(val.toFixed(val > 100 ? 0 : 2), padding.left - 8, y + 4);
    }

    // Zero line
    if (minVal < 0 && maxVal > 0) {
      const zeroY = padding.top + ((maxVal - 0) / range) * chartH;
      ctx.strokeStyle = '#374151';
      ctx.lineWidth = 1;
      ctx.setLineDash([4, 4]);
      ctx.beginPath();
      ctx.moveTo(padding.left, zeroY);
      ctx.lineTo(w - padding.right, zeroY);
      ctx.stroke();
      ctx.setLineDash([]);
    }

    // X labels
    const step = Math.max(1, Math.floor(data.labels.length / 10));
    data.labels.forEach((label, i) => {
      if (i % step !== 0 && i !== data.labels.length - 1) return;
      const x = padding.left + (i / (data.labels.length - 1 || 1)) * chartW;
      ctx.fillStyle = '#4b5563';
      ctx.font = '10px system-ui';
      ctx.textAlign = 'center';
      ctx.fillText(label.slice(5), x, h - padding.bottom + 20);
    });

    data.datasets.forEach((dataset) => {
      const color = dataset.color;
      if (type === 'line') {
        ctx.beginPath();
        dataset.data.forEach((val, i) => {
          const x = padding.left + (i / (data.labels.length - 1 || 1)) * chartW;
          const y = padding.top + ((maxVal - val) / range) * chartH;
          if (i === 0) ctx.moveTo(x, y);
          else ctx.lineTo(x, y);
        });
        ctx.strokeStyle = color;
        ctx.lineWidth = 2.5;
        ctx.stroke();
        // Fill area
        const lastX = padding.left + ((data.labels.length - 1) / (data.labels.length - 1 || 1)) * chartW;
        const zeroY = padding.top + ((maxVal - Math.max(0, minVal)) / range) * chartH;
        ctx.lineTo(lastX, zeroY);
        ctx.lineTo(padding.left, zeroY);
        ctx.closePath();
        const gradient = ctx.createLinearGradient(0, padding.top, 0, h - padding.bottom);
        gradient.addColorStop(0, color + '30');
        gradient.addColorStop(1, color + '05');
        ctx.fillStyle = gradient;
        ctx.fill();
      } else if (type === 'bar') {
        const barWidth = (chartW / data.labels.length) * 0.6;
        const zeroY = padding.top + ((maxVal - 0) / range) * chartH;
        dataset.data.forEach((val, i) => {
          const x = padding.left + (i / (data.labels.length || 1)) * chartW + (chartW / data.labels.length) * 0.2;
          const y = padding.top + ((maxVal - val) / range) * chartH;
          const barH = Math.abs(y - zeroY);
          ctx.fillStyle = val >= 0 ? '#10b981' : '#ef4444';
          ctx.fillRect(x, val >= 0 ? y : zeroY, barWidth, barH || 1);
        });
      }
    });
  }, [type, data, height, title]);

  return (
    <div className="bg-[#0d1224] rounded-2xl border border-[#1a2340] p-4">
      <canvas ref={canvasRef} className="w-full" style={{ height }} />
    </div>
  );
}
