import { BrowserRouter, Routes, Route } from 'react-router-dom';
import Layout from './components/Layout';
import DailyAffirmation from './components/DailyAffirmation';
import HomePage from './pages/HomePage';
import TradesPage from './pages/TradesPage';
import AddTradePage from './pages/AddTradePage';
import ImportPage from './pages/ImportPage';
import DebriefingPage from './pages/DebriefingPage';
import CoachInsightsPage from './pages/CoachInsightsPage';
import DailyDashboard from './pages/DailyDashboard';
import WeeklyDashboard from './pages/WeeklyDashboard';
import MonthlyDashboard from './pages/MonthlyDashboard';
import ReportsPage from './pages/ReportsPage';
import JournalPage from './pages/JournalPage';
import ChatPage from './pages/ChatPage';
import TraderHubPage from './pages/TraderHubPage';
import RoadmapPage from './pages/RoadmapPage';

export default function App() {
  return (
    <BrowserRouter>
      <Layout>
        <DailyAffirmation />
        <Routes>
          <Route path="/" element={<HomePage />} />
          <Route path="/trades" element={<TradesPage />} />
          <Route path="/add-trade" element={<AddTradePage />} />
          <Route path="/import" element={<ImportPage />} />
          <Route path="/debriefing" element={<DebriefingPage />} />
          <Route path="/coach" element={<CoachInsightsPage />} />
          <Route path="/dashboard/daily" element={<DailyDashboard />} />
          <Route path="/dashboard/weekly" element={<WeeklyDashboard />} />
          <Route path="/dashboard/monthly" element={<MonthlyDashboard />} />
          <Route path="/reports" element={<ReportsPage />} />
          <Route path="/journal" element={<JournalPage />} />
          <Route path="/chat" element={<ChatPage />} />
          <Route path="/hub" element={<TraderHubPage />} />
          <Route path="/roadmap" element={<RoadmapPage />} />
        </Routes>
      </Layout>
    </BrowserRouter>
  );
}
