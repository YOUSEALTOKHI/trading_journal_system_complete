import { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { BookOpen, Calendar, ChevronLeft, ChevronRight, CheckCircle, XCircle } from 'lucide-react';
import LoadingSpinner from '../components/LoadingSpinner';
import { api } from '../lib/api';
import { TEN_PRINCIPLES } from '../lib/types';

export default function JournalPage() {
  const [date, setDate] = useState(new Date().toISOString().split('T')[0]);
  const [trades, setTrades] = useState<any[]>([]);
  const [debriefing, setDebriefing] = useState<any>(null);
  const [loading, setLoading] = useState(true);

  const fetchData = async () => {
    setLoading(true);
    try {
      const [tradesData, debriefings] = await Promise.all([
        api.getTrades({ date }),
        api.getDebriefings({ date }),
      ]);
      setTrades(tradesData);
      setDebriefing(debriefings.length > 0 ? debriefings[0] : null);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { fetchData(); }, [date]);

  const changeDate = (days: number) => {
    const d = new Date(date);
    d.setDate(d.getDate() + days);
    setDate(d.toISOString().split('T')[0]);
  };

  let principles: {checked: boolean; why: string}[] = [];
  try {
    if (debriefing?.ten_principles) {
      principles = JSON.parse(debriefing.ten_principles);
    }
  } catch {}

  const totalProfit = trades.reduce((s, t) => s + (t.profit || 0), 0);

  return (
    <div className="max-w-4xl mx-auto space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-bold text-white">يوميات التداول</h1>
        <div className="flex items-center gap-2">
          <button onClick={() => changeDate(-1)} className="p-2 rounded-lg bg-[#0d1224] border border-[#1a2340] text-gray-400 hover:text-white">
            <ChevronRight size={16} />
          </button>
          <input type="date" value={date} onChange={e => setDate(e.target.value)}
            className="bg-[#0d1224] border border-[#1a2340] rounded-xl px-4 py-2 text-sm text-gray-200 focus:border-emerald-500/50 focus:outline-none" />
          <button onClick={() => changeDate(1)} className="p-2 rounded-lg bg-[#0d1224] border border-[#1a2340] text-gray-400 hover:text-white">
            <ChevronLeft size={16} />
          </button>
        </div>
      </div>

      {loading ? <LoadingSpinner /> : (
        <div className="space-y-6">
          {/* Day Summary */}
          <div className="bg-[#0d1224] rounded-2xl border border-[#1a2340] p-6">
            <div className="flex items-center gap-3 mb-4">
              <BookOpen size={20} className="text-emerald-400" />
              <h2 className="text-lg font-semibold text-white">
                {new Date(date).toLocaleDateString('ar-EG', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' })}
              </h2>
            </div>
            <div className="grid grid-cols-3 gap-4 text-center">
              <div className="bg-[#0a0e1a] rounded-xl p-4">
                <p className="text-xs text-gray-500 mb-1">عدد الصفقات</p>
                <p className="text-xl font-bold text-white">{trades.length}</p>
              </div>
              <div className="bg-[#0a0e1a] rounded-xl p-4">
                <p className="text-xs text-gray-500 mb-1">صافي الربح</p>
                <p className={`text-xl font-bold ${totalProfit >= 0 ? 'text-emerald-400' : 'text-red-400'}`}>${totalProfit.toFixed(2)}</p>
              </div>
              <div className="bg-[#0a0e1a] rounded-xl p-4">
                <p className="text-xs text-gray-500 mb-1">التقييم</p>
                <p className={`text-xl font-bold ${
                  (debriefing?.overall_score || 0) >= 7 ? 'text-emerald-400' :
                  (debriefing?.overall_score || 0) >= 4 ? 'text-amber-400' : 'text-red-400'
                }`}>{debriefing?.overall_score || '-'}/10</p>
              </div>
            </div>
          </div>

          {/* Trades */}
          {trades.length > 0 && (
            <div className="bg-[#0d1224] rounded-2xl border border-[#1a2340] p-6">
              <h3 className="text-sm font-semibold text-white mb-4">الصفقات</h3>
              <div className="space-y-3">
                {trades.map((t, i) => (
                  <motion.div
                    key={t.id}
                    initial={{ opacity: 0, x: 20 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: i * 0.05 }}
                    className="bg-[#0a0e1a] rounded-xl p-4"
                  >
                    <div className="flex items-center justify-between mb-2">
                      <div className="flex items-center gap-2">
                        <span className="text-white font-medium">{t.symbol}</span>
                        <span className={`px-2 py-0.5 rounded text-xs ${t.trade_type === 'buy' ? 'bg-emerald-500/20 text-emerald-400' : 'bg-red-500/20 text-red-400'}`}>
                          {t.trade_type === 'buy' ? 'شراء' : 'بيع'}
                        </span>
                        <span className="text-xs text-gray-500">{t.lot_size} lot</span>
                      </div>
                      <span className={`font-semibold ${t.profit >= 0 ? 'text-emerald-400' : 'text-red-400'}`}>${t.profit?.toFixed(2)}</span>
                    </div>
                    {(t.entry_reason || t.psychological_state || t.thoughts_at_entry || t.trading_notes) && (
                      <div className="mt-2 pt-2 border-t border-[#1a2340] space-y-1 text-xs">
                        {t.entry_reason && <p className="text-gray-400"><span className="text-gray-600">سبب الدخول:</span> {t.entry_reason}</p>}
                        {t.psychological_state && <p className="text-gray-400"><span className="text-gray-600">الحالة النفسية:</span> {t.psychological_state}</p>}
                        {t.thoughts_at_entry && <p className="text-gray-400"><span className="text-gray-600">الأفكار:</span> {t.thoughts_at_entry}</p>}
                        {t.trading_notes && <p className="text-gray-400"><span className="text-gray-600">ملاحظات:</span> {t.trading_notes}</p>}
                      </div>
                    )}
                  </motion.div>
                ))}
              </div>
            </div>
          )}

          {/* Debriefing */}
          {debriefing && (
            <div className="bg-[#0d1224] rounded-2xl border border-[#1a2340] p-6 space-y-4">
              <h3 className="text-sm font-semibold text-white">الديلي دبريفنج</h3>
              {debriefing.error_analysis && (
                <div>
                  <p className="text-xs text-gray-500 mb-1">تحليل الأخطاء</p>
                  <p className="text-sm text-gray-300">{debriefing.error_analysis}</p>
                </div>
              )}
              {debriefing.root_causes && (
                <div>
                  <p className="text-xs text-gray-500 mb-1">الأسباب الجذرية</p>
                  <p className="text-sm text-gray-300">{debriefing.root_causes}</p>
                </div>
              )}
              {debriefing.improvements && (
                <div>
                  <p className="text-xs text-gray-500 mb-1">خطة التحسين</p>
                  <p className="text-sm text-gray-300">{debriefing.improvements}</p>
                </div>
              )}

              {/* Principles */}
              {principles.length === 10 && (
                <div>
                  <p className="text-xs text-gray-500 mb-2">المبادئ العشرة</p>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                    {TEN_PRINCIPLES.map((p, i) => (
                      <div key={i} className="flex items-center gap-2 text-xs">
                        {principles[i].checked
                          ? <CheckCircle size={14} className="text-emerald-400 flex-shrink-0" />
                          : <XCircle size={14} className="text-red-400 flex-shrink-0" />
                        }
                        <span className="text-gray-400">{p}</span>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          )}

          {trades.length === 0 && !debriefing && (
            <div className="bg-[#0d1224] rounded-2xl border border-[#1a2340] p-10 text-center">
              <BookOpen size={40} className="mx-auto mb-3 text-gray-700" />
              <p className="text-gray-500">لا توجد بيانات لهذا اليوم</p>
            </div>
          )}
        </div>
      )}
    </div>
  );
}
