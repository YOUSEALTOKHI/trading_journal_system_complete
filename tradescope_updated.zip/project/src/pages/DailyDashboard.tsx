import { useState, useEffect } from 'react';
import { useSearchParams } from 'react-router-dom';
import { Calendar, TrendingUp, TrendingDown, Target, Activity, Award, AlertTriangle } from 'lucide-react';
import StatsCard from '../components/StatsCard';
import Chart from '../components/Chart';
import LoadingSpinner from '../components/LoadingSpinner';
import { api } from '../lib/api';

export default function DailyDashboard() {
  const [searchParams] = useSearchParams();
  const initialDate = searchParams.get('date') || new Date().toISOString().split('T')[0];
  const [date, setDate] = useState(initialDate);
  const [stats, setStats] = useState<any>(null);
  const [trades, setTrades] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  const fetchData = async () => {
    setLoading(true);
    try {
      const [statsData, tradesData] = await Promise.all([
        api.getStats({ period: 'daily', date }),
        api.getTrades({ date }),
      ]);
      setStats(statsData);
      setTrades(tradesData);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { fetchData(); }, [date]);

  if (loading) return <LoadingSpinner />;

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-bold text-white">لوحة التحكم اليومية</h1>
        <div className="flex items-center gap-2">
          <Calendar size={16} className="text-gray-500" />
          <input type="date" value={date} onChange={e => setDate(e.target.value)}
            className="bg-[#0d1224] border border-[#1a2340] rounded-xl px-4 py-2 text-sm text-gray-200 focus:border-emerald-500/50 focus:outline-none" />
        </div>
      </div>

      {stats && (
        <>
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
            <StatsCard title="عدد الصفقات" value={stats.totalTrades} icon={Activity} color="blue" delay={0.1} />
            <StatsCard title="صافي الربح" value={`$${stats.totalProfit}`} icon={stats.totalProfit >= 0 ? TrendingUp : TrendingDown} color={stats.totalProfit >= 0 ? 'emerald' : 'red'} delay={0.2} />
            <StatsCard title="نسبة الفوز" value={`${stats.winRate}%`} icon={Target} color="amber" delay={0.3} />
            <StatsCard title="أكبر ربح" value={`$${stats.largestWin}`} icon={Award} color="purple" delay={0.4} />
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <Chart
              type="bar"
              title="الربح/الخسارة لكل صفقة"
              data={{
                labels: trades.map(t => t.ticket || t.symbol),
                datasets: [{ label: 'الربح', data: trades.map(t => t.profit), color: '#10b981' }]
              }}
            />
            <Chart
              type="doughnut"
              title="توزيع الصفقات"
              data={{
                labels: ['رابحة', 'خاسرة', 'تعادل'],
                datasets: [{ label: 'الصفقات', data: [stats.wins, stats.losses, stats.breakeven], color: '#10b981' }]
              }}
            />
          </div>

          {stats.equityCurve.length > 0 && (
            <Chart
              type="line"
              title="منحنى الرصيد"
              data={{
                labels: stats.equityCurve.map((e: any) => e.date),
                datasets: [{ label: 'الرصيد', data: stats.equityCurve.map((e: any) => e.balance), color: '#06b6d4' }]
              }}
              height={300}
            />
          )}

          {/* Trades table */}
          <div className="bg-[#0d1224] rounded-2xl border border-[#1a2340] overflow-hidden">
            <div className="p-4 border-b border-[#1a2340]">
              <h3 className="text-sm font-semibold text-white">صفقات اليوم</h3>
            </div>
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="text-gray-500 text-xs border-b border-[#1a2340]">
                    <th className="px-4 py-2 text-right">الرمز</th>
                    <th className="px-4 py-2 text-right">النوع</th>
                    <th className="px-4 py-2 text-right">الحجم</th>
                    <th className="px-4 py-2 text-right">الربح</th>
                    <th className="px-4 py-2 text-right">الحالة</th>
                  </tr>
                </thead>
                <tbody>
                  {trades.map(t => (
                    <tr key={t.id} className="border-b border-[#1a2340]/50">
                      <td className="px-4 py-2 text-white">{t.symbol}</td>
                      <td className="px-4 py-2"><span className={`px-2 py-0.5 rounded text-xs ${t.trade_type === 'buy' ? 'bg-emerald-500/20 text-emerald-400' : 'bg-red-500/20 text-red-400'}`}>{t.trade_type === 'buy' ? 'شراء' : 'بيع'}</span></td>
                      <td className="px-4 py-2 text-gray-400">{t.lot_size}</td>
                      <td className={`px-4 py-2 font-medium ${t.profit >= 0 ? 'text-emerald-400' : 'text-red-400'}`}>${t.profit?.toFixed(2)}</td>
                      <td className="px-4 py-2 text-gray-500 text-xs">{t.psychological_state || '-'}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
            {trades.length === 0 && <div className="p-8 text-center text-gray-600">لا توجد صفقات في هذا اليوم</div>}
          </div>
        </>
      )}
    </div>
  );
}
