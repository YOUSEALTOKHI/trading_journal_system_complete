import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { PlusCircle, Upload, CheckCircle, TrendingDown } from 'lucide-react';
import { api } from '../lib/api';
import { PSYCHOLOGICAL_STATES, ENTRY_REASONS, TRADE_CLASSIFICATIONS } from '../lib/types';

export default function AddTradePage() {
  const navigate = useNavigate();
  const [mode, setMode] = useState<'manual' | 'bulk'>('manual');
  const [saving, setSaving] = useState(false);
  const [success, setSuccess] = useState(false);
  const [bulkText, setBulkText] = useState('');
  const [trade, setTrade] = useState({
    ticket: '',
    open_time: '',
    close_time: '',
    trade_type: 'buy',
    lot_size: 0.01,
    symbol: 'EURUSD',
    open_price: 0,
    close_price: 0,
    stop_loss: 0,
    take_profit: 0,
    profit: 0,
    balance_after: 0,
    trade_date: new Date().toISOString().split('T')[0],
    trade_classification: 'intraday',
    trade_drawdown: 0,
    drawdown_details: '',
    trading_notes: '',
    entry_reason: '',
    psychological_state: '',
    thoughts_at_entry: '',
  });

  const handleChange = (field: string, value: any) => {
    setTrade(prev => ({ ...prev, [field]: value }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setSaving(true);
    try {
      const payload = { ...trade };
      if (!payload.trade_drawdown) delete (payload as any).trade_drawdown;
      if (!payload.drawdown_details) delete (payload as any).drawdown_details;
      await api.createTrades([payload]);
      setSuccess(true);
      setTimeout(() => navigate('/trades'), 1500);
    } catch (err) {
      console.error(err);
      alert('\u062d\u062f\u062b \u062e\u0637\u0623 \u0641\u064a \u062d\u0641\u0638 \u0627\u0644\u0635\u0641\u0642\u0629');
    } finally {
      setSaving(false);
    }
  };

  const handleBulkImport = async () => {
    if (!bulkText.trim()) return;
    setSaving(true);
    try {
      const lines = bulkText.trim().split('\n').filter(l => l.trim());
      const trades = lines.map(line => {
        const parts = line.split(/[\t,|;]+/).map(p => p.trim());
        return {
          ticket: parts[0] || String(Date.now()),
          open_time: parts[1] || new Date().toISOString(),
          close_time: parts[2] || new Date().toISOString(),
          trade_type: (parts[3] || 'buy').toLowerCase().includes('sell') ? 'sell' : 'buy',
          lot_size: parseFloat(parts[4]) || 0.01,
          symbol: parts[5] || 'EURUSD',
          open_price: parseFloat(parts[6]) || 0,
          close_price: parseFloat(parts[7]) || 0,
          stop_loss: parseFloat(parts[8]) || null,
          take_profit: parseFloat(parts[9]) || null,
          profit: parseFloat(parts[10]) || 0,
          balance_after: parseFloat(parts[11]) || 0,
          trade_date: parts[1] ? parts[1].split(' ')[0] || parts[1].split('T')[0] : new Date().toISOString().split('T')[0],
          trade_classification: 'intraday',
        };
      });
      await api.createTrades(trades);
      setSuccess(true);
      setTimeout(() => navigate('/trades'), 1500);
    } catch (err) {
      console.error(err);
      alert('\u062d\u062f\u062b \u062e\u0637\u0623 \u0641\u064a \u0627\u0644\u0627\u0633\u062a\u064a\u0631\u0627\u062f');
    } finally {
      setSaving(false);
    }
  };

  if (success) {
    return (
      <motion.div initial={{ scale: 0.8, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} className="flex flex-col items-center justify-center py-20">
        <CheckCircle size={60} className="text-emerald-400 mb-4" />
        <h2 className="text-xl font-bold text-white">\u062a\u0645 \u0627\u0644\u062d\u0641\u0638 \u0628\u0646\u062c\u0627\u062d!</h2>
        <p className="text-gray-400 mt-2">\u062c\u0627\u0631\u064a \u0627\u0644\u062a\u062d\u0648\u064a\u0644...</p>
      </motion.div>
    );
  }

  return (
    <div className="max-w-3xl mx-auto space-y-6">
      <h1 className="text-2xl font-bold text-white">\u0625\u0636\u0627\u0641\u0629 \u0635\u0641\u0642\u0629 \u062c\u062f\u064a\u062f\u0629</h1>

      <div className="flex gap-3">
        <button onClick={() => setMode('manual')} className={`flex-1 py-3 rounded-xl text-sm font-medium transition-all ${mode === 'manual' ? 'bg-emerald-600 text-white' : 'bg-[#0d1224] border border-[#1a2340] text-gray-400 hover:text-white'}`}>
          <PlusCircle size={16} className="inline ml-2" />\u0625\u062f\u062e\u0627\u0644 \u064a\u062f\u0648\u064a
        </button>
        <button onClick={() => setMode('bulk')} className={`flex-1 py-3 rounded-xl text-sm font-medium transition-all ${mode === 'bulk' ? 'bg-emerald-600 text-white' : 'bg-[#0d1224] border border-[#1a2340] text-gray-400 hover:text-white'}`}>
          <Upload size={16} className="inline ml-2" />\u0627\u0633\u062a\u064a\u0631\u0627\u062f \u062c\u0645\u0627\u0639\u064a
        </button>
      </div>

      {mode === 'manual' ? (
        <form onSubmit={handleSubmit} className="bg-[#0d1224] rounded-2xl border border-[#1a2340] p-6 space-y-6">
          <div className="grid grid-cols-2 gap-4">
            {[
              { label: '\u0631\u0642\u0645 \u0627\u0644\u062a\u0630\u0643\u0631\u0629', field: 'ticket', type: 'text' },
              { label: '\u0627\u0644\u0631\u0645\u0632', field: 'symbol', type: 'text' },
              { label: '\u0648\u0642\u062a \u0627\u0644\u0641\u062a\u062d', field: 'open_time', type: 'datetime-local' },
              { label: '\u0648\u0642\u062a \u0627\u0644\u0625\u063a\u0644\u0627\u0642', field: 'close_time', type: 'datetime-local' },
              { label: '\u0627\u0644\u062d\u062c\u0645 (\u0644\u0648\u062a)', field: 'lot_size', type: 'number' },
              { label: '\u0633\u0639\u0631 \u0627\u0644\u062f\u062e\u0648\u0644', field: 'open_price', type: 'number' },
              { label: '\u0633\u0639\u0631 \u0627\u0644\u062e\u0631\u0648\u062c', field: 'close_price', type: 'number' },
              { label: '\u0648\u0642\u0641 \u0627\u0644\u062e\u0633\u0627\u0631\u0629', field: 'stop_loss', type: 'number' },
              { label: '\u0647\u062f\u0641 \u0627\u0644\u0631\u0628\u062d', field: 'take_profit', type: 'number' },
              { label: '\u0627\u0644\u0631\u0628\u062d/\u0627\u0644\u062e\u0633\u0627\u0631\u0629', field: 'profit', type: 'number' },
              { label: '\u0627\u0644\u0631\u0635\u064a\u062f \u0628\u0639\u062f \u0627\u0644\u0635\u0641\u0642\u0629', field: 'balance_after', type: 'number' },
              { label: '\u062a\u0627\u0631\u064a\u062e \u0627\u0644\u0635\u0641\u0642\u0629', field: 'trade_date', type: 'date' },
            ].map(({ label, field, type }) => (
              <div key={field}>
                <label className="block text-xs text-gray-400 mb-1">{label}</label>
                <input type={type} step={type === 'number' ? 'any' : undefined} value={(trade as any)[field]}
                  onChange={e => handleChange(field, type === 'number' ? parseFloat(e.target.value) || 0 : e.target.value)}
                  className="w-full bg-[#0a0e1a] border border-[#1a2340] rounded-xl px-4 py-2.5 text-sm text-gray-200 focus:border-emerald-500/50 focus:outline-none" />
              </div>
            ))}
          </div>

          {/* Trade Drawdown - NEW */}
          <div className="border-t border-[#1a2340] pt-6">
            <div className="flex items-center gap-2 mb-4">
              <TrendingDown size={18} className="text-red-400" />
              <h3 className="text-sm font-semibold text-red-400">\u062f\u0631\u0648\u0627 \u062f\u0627\u0648\u0646 \u0627\u0644\u0635\u0641\u0642\u0629 (Trade Drawdown)</h3>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-xs text-gray-400 mb-1">\u0623\u0642\u0635\u0649 \u062f\u0631\u0648\u0627 \u062f\u0627\u0648\u0646 ($)</label>
                <input type="number" step="any" value={trade.trade_drawdown}
                  onChange={e => handleChange('trade_drawdown', parseFloat(e.target.value) || 0)}
                  className="w-full bg-[#0a0e1a] border border-red-500/20 rounded-xl px-4 py-2.5 text-sm text-gray-200 focus:border-red-500/50 focus:outline-none"
                  placeholder="0.00" />
              </div>
              <div>
                <label className="block text-xs text-gray-400 mb-1">\u062a\u0641\u0627\u0635\u064a\u0644 / \u0645\u0644\u0627\u062d\u0638\u0627\u062a \u0627\u0644\u062f\u0631\u0648\u0627 \u062f\u0627\u0648\u0646</label>
                <input type="text" value={trade.drawdown_details}
                  onChange={e => handleChange('drawdown_details', e.target.value)}
                  className="w-full bg-[#0a0e1a] border border-red-500/20 rounded-xl px-4 py-2.5 text-sm text-gray-200 focus:border-red-500/50 focus:outline-none"
                  placeholder="\u0645\u062b\u0627\u0644: \u0648\u0635\u0644 \u0627\u0644\u0633\u0639\u0631 \u0644\u0640 1.0820 \u0642\u0628\u0644 \u0627\u0644\u0627\u0631\u062a\u062f\u0627\u062f" />
              </div>
            </div>
            <p className="text-[11px] text-gray-600 mt-2">\u0623\u062f\u062e\u0644 \u0623\u0642\u0635\u0649 \u062e\u0633\u0627\u0631\u0629 \u0639\u0627\u0626\u0645\u0629 \u0648\u0635\u0644\u062a \u0644\u0647\u0627 \u0627\u0644\u0635\u0641\u0642\u0629 \u0642\u0628\u0644 \u0627\u0644\u0625\u063a\u0644\u0627\u0642 (\u064a\u062f\u0648\u064a\u0627\u064b) \u0623\u0648 \u0627\u062a\u0631\u0643\u0647 \u0641\u0627\u0631\u063a\u0627\u064b \u0644\u062d\u0633\u0627\u0628\u0647 \u062a\u0644\u0642\u0627\u0626\u064a\u0627\u064b \u0628\u0627\u0644\u0630\u0643\u0627\u0621 \u0627\u0644\u0627\u0635\u0637\u0646\u0627\u0639\u064a</p>
          </div>

          {/* Trade Type */}
          <div>
            <label className="block text-xs text-gray-400 mb-2">\u0646\u0648\u0639 \u0627\u0644\u0635\u0641\u0642\u0629</label>
            <div className="flex gap-3">
              <button type="button" onClick={() => handleChange('trade_type', 'buy')}
                className={`flex-1 py-2.5 rounded-xl text-sm font-medium ${trade.trade_type === 'buy' ? 'bg-emerald-600 text-white' : 'bg-[#0a0e1a] border border-[#1a2340] text-gray-400'}`}>
                \u0634\u0631\u0627\u0621 (Buy)
              </button>
              <button type="button" onClick={() => handleChange('trade_type', 'sell')}
                className={`flex-1 py-2.5 rounded-xl text-sm font-medium ${trade.trade_type === 'sell' ? 'bg-red-600 text-white' : 'bg-[#0a0e1a] border border-[#1a2340] text-gray-400'}`}>
                \u0628\u064a\u0639 (Sell)
              </button>
            </div>
          </div>

          {/* Trade Classification */}
          <div>
            <label className="block text-xs text-gray-400 mb-2">\u062a\u0635\u0646\u064a\u0641 \u0627\u0644\u0635\u0641\u0642\u0629</label>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
              {TRADE_CLASSIFICATIONS.map(cls => (
                <button key={cls.value} type="button" onClick={() => handleChange('trade_classification', cls.value)}
                  className={`py-2.5 rounded-xl text-xs font-medium transition-all ${
                    trade.trade_classification === cls.value
                      ? `${cls.color} border border-current`
                      : 'bg-[#0a0e1a] border border-[#1a2340] text-gray-500 hover:text-gray-300'
                  }`}>
                  {cls.label}
                </button>
              ))}
            </div>
          </div>

          {/* Psychological Section */}
          <div className="border-t border-[#1a2340] pt-6">
            <h3 className="text-sm font-semibold text-emerald-400 mb-4">\u0627\u0644\u062c\u0648\u0627\u0646\u0628 \u0627\u0644\u0646\u0641\u0633\u064a\u0629</h3>
            <div className="space-y-4">
              <div>
                <label className="block text-xs text-gray-400 mb-1">\u0633\u0628\u0628 \u0627\u0644\u062f\u062e\u0648\u0644</label>
                <select value={trade.entry_reason} onChange={e => handleChange('entry_reason', e.target.value)}
                  className="w-full bg-[#0a0e1a] border border-[#1a2340] rounded-xl px-4 py-2.5 text-sm text-gray-200 focus:border-emerald-500/50 focus:outline-none">
                  <option value="">\u0627\u062e\u062a\u0631...</option>
                  {ENTRY_REASONS.map(r => <option key={r} value={r}>{r}</option>)}
                </select>
              </div>
              <div>
                <label className="block text-xs text-gray-400 mb-1">\u0627\u0644\u062d\u0627\u0644\u0629 \u0627\u0644\u0646\u0641\u0633\u064a\u0629</label>
                <select value={trade.psychological_state} onChange={e => handleChange('psychological_state', e.target.value)}
                  className="w-full bg-[#0a0e1a] border border-[#1a2340] rounded-xl px-4 py-2.5 text-sm text-gray-200 focus:border-emerald-500/50 focus:outline-none">
                  <option value="">\u0627\u062e\u062a\u0631...</option>
                  {PSYCHOLOGICAL_STATES.map(s => <option key={s} value={s}>{s}</option>)}
                </select>
              </div>
              <div>
                <label className="block text-xs text-gray-400 mb-1">\u0627\u0644\u0623\u0641\u0643\u0627\u0631 \u0639\u0646\u062f \u0627\u0644\u062f\u062e\u0648\u0644</label>
                <textarea value={trade.thoughts_at_entry} onChange={e => handleChange('thoughts_at_entry', e.target.value)}
                  className="w-full bg-[#0a0e1a] border border-[#1a2340] rounded-xl px-4 py-2.5 text-sm text-gray-200 focus:border-emerald-500/50 focus:outline-none h-20 resize-none"
                  placeholder="\u0645\u0627 \u0627\u0644\u0630\u064a \u0643\u0646\u062a \u062a\u0641\u0643\u0631 \u0641\u064a\u0647 \u0639\u0646\u062f \u0627\u0644\u062f\u062e\u0648\u0644\u061f" />
              </div>
              <div>
                <label className="block text-xs text-gray-400 mb-1">\u0645\u0644\u0627\u062d\u0638\u0627\u062a</label>
                <textarea value={trade.trading_notes} onChange={e => handleChange('trading_notes', e.target.value)}
                  className="w-full bg-[#0a0e1a] border border-[#1a2340] rounded-xl px-4 py-2.5 text-sm text-gray-200 focus:border-emerald-500/50 focus:outline-none h-20 resize-none"
                  placeholder="\u0645\u0644\u0627\u062d\u0638\u0627\u062a \u0625\u0636\u0627\u0641\u064a\u0629 \u062d\u0648\u0644 \u0627\u0644\u0635\u0641\u0642\u0629..." />
              </div>
            </div>
          </div>

          <button type="submit" disabled={saving}
            className="w-full py-3 bg-gradient-to-l from-emerald-600 to-cyan-600 hover:from-emerald-700 hover:to-cyan-700 rounded-xl text-white font-semibold disabled:opacity-50">
            {saving ? '\u062c\u0627\u0631\u064a \u0627\u0644\u062d\u0641\u0638...' : '\u062d\u0641\u0638 \u0627\u0644\u0635\u0641\u0642\u0629'}
          </button>
        </form>
      ) : (
        <div className="bg-[#0d1224] rounded-2xl border border-[#1a2340] p-6 space-y-4">
          <p className="text-sm text-gray-400">\u0627\u0644\u0635\u0642 \u0628\u064a\u0627\u0646\u0627\u062a \u0627\u0644\u0635\u0641\u0642\u0627\u062a (\u0633\u0637\u0631 \u0644\u0643\u0644 \u0635\u0641\u0642\u0629\u060c \u0645\u0641\u0635\u0648\u0644\u0629 \u0628\u062a\u0627\u0628 \u0623\u0648 \u0641\u0627\u0635\u0644\u0629):</p>
          <textarea value={bulkText} onChange={e => setBulkText(e.target.value)}
            className="w-full bg-[#0a0e1a] border border-[#1a2340] rounded-xl px-4 py-3 text-sm text-gray-200 focus:border-emerald-500/50 focus:outline-none h-48 resize-none font-mono"
            placeholder="12345\t2025-01-15 10:30\t2025-01-15 14:00\tbuy\t0.1\tEURUSD\t1.0850\t1.0900\t1.0820\t1.0920\t50\t10050" dir="ltr" />
          <button onClick={handleBulkImport} disabled={saving}
            className="w-full py-3 bg-gradient-to-l from-emerald-600 to-cyan-600 hover:from-emerald-700 hover:to-cyan-700 rounded-xl text-white font-semibold disabled:opacity-50">
            {saving ? '\u062c\u0627\u0631\u064a \u0627\u0644\u0627\u0633\u062a\u064a\u0631\u0627\u062f...' : '\u0627\u0633\u062a\u064a\u0631\u0627\u062f \u0627\u0644\u0635\u0641\u0642\u0627\u062a'}
          </button>
        </div>
      )}
    </div>
  );
}
