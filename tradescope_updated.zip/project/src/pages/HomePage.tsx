import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import {
  TrendingUp, TrendingDown, BarChart3, Target, Activity,
  Calendar, FileText, PlusCircle, ClipboardCheck, ArrowUpRight,
  Shield, Compass, Brain, Sparkles
} from 'lucide-react';
import StatsCard from '../components/StatsCard';
import LoadingSpinner from '../components/LoadingSpinner';
import { api } from '../lib/api';

export default function HomePage() {
  const [stats, setStats] = useState<any>(null);
  const [recentTrades, setRecentTrades] = useState<any[]>([]);
  const [randomBelief, setRandomBelief] = useState<any>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const today = new Date().toISOString().split('T')[0];
    const monthStr = today.slice(0, 7);
    Promise.all([
      api.getStats({ period: 'monthly', month: monthStr }),
      api.getTrades(),
      api.getTraderContent({ category: 'beliefs' }),
    ]).then(([statsData, trades, beliefs]) => {
      setStats(statsData);
      setRecentTrades(trades.slice(0, 5));
      if (beliefs.length > 0) {
        setRandomBelief(beliefs[Math.floor(Math.random() * beliefs.length)]);
      }
    }).catch(console.error).finally(() => setLoading(false));
  }, []);

  if (loading) return <LoadingSpinner />;

  const quickActions = [
    { label: '\u0625\u0636\u0627\u0641\u0629 \u0635\u0641\u0642\u0629', path: '/add-trade', icon: PlusCircle, color: 'from-emerald-500 to-cyan-500' },
    { label: '\u062f\u064a\u0644\u064a \u062f\u0628\u0631\u064a\u0641\u0646\u062c', path: '/debriefing', icon: ClipboardCheck, color: 'from-blue-500 to-purple-500' },
    { label: '\u0645\u0631\u0643\u0632 \u0627\u0644\u0645\u062a\u062f\u0627\u0648\u0644', path: '/hub', icon: Shield, color: 'from-red-500 to-orange-500' },
    { label: '\u0645\u0635\u0641\u0648\u0641\u0629 \u0627\u0644\u0646\u062c\u0627\u062d', path: '/roadmap', icon: Compass, color: 'from-amber-500 to-yellow-500' },
    { label: '\u0627\u0644\u0645\u062f\u0631\u0628 \u0627\u0644\u0630\u0643\u064a', path: '/coach', icon: Brain, color: 'from-purple-500 to-pink-500' },
    { label: '\u0644\u0648\u062d\u0629 \u064a\u0648\u0645\u064a\u0629', path: '/dashboard/daily', icon: Calendar, color: 'from-cyan-500 to-blue-500' },
  ];

  return (
    <div className="space-y-8">
      {/* Welcome + Belief */}
      <div className="flex flex-col lg:flex-row gap-6">
        <div className="flex-1">
          <h1 className="text-3xl font-bold text-white mb-2">{'\u0645\u0631\u062d\u0628\u0627\u064b \u0628\u0643 \u0641\u064a TradeScope'}</h1>
          <p className="text-gray-400">{'\u0646\u0638\u0627\u0645\u0643 \u0627\u0644\u0645\u062a\u0643\u0627\u0645\u0644 \u0644\u0625\u062f\u0627\u0631\u0629 \u064a\u0648\u0645\u064a\u0627\u062a \u0627\u0644\u062a\u062f\u0627\u0648\u0644 \u0648\u0627\u0644\u062a\u062d\u0644\u064a\u0644 \u0627\u0644\u0623\u0633\u0627\u0633\u064a'}</p>
        </div>
        {randomBelief && (
          <motion.div initial={{ opacity: 0, x: -20 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: 0.3 }}
            className="lg:max-w-sm bg-gradient-to-br from-amber-500/10 to-orange-500/5 border border-amber-500/20 rounded-2xl p-5">
            <div className="flex items-center gap-2 mb-2">
              <Sparkles size={16} className="text-amber-400" />
              <span className="text-xs text-amber-400 font-medium">{'\u062a\u0623\u0643\u064a\u062f \u0627\u0644\u064a\u0648\u0645'}</span>
            </div>
            <p className="text-sm text-gray-300 leading-relaxed">{randomBelief.content}</p>
          </motion.div>
        )}
      </div>

      {/* Quick Actions */}
      <div className="grid grid-cols-2 lg:grid-cols-3 xl:grid-cols-6 gap-3">
        {quickActions.map((action, i) => (
          <motion.div key={action.path} initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.07 }}>
            <Link to={action.path}
              className="block p-4 rounded-2xl bg-[#0d1224] border border-[#1a2340] hover:border-[#2a3560] transition-all group">
              <div className={`w-10 h-10 rounded-xl bg-gradient-to-br ${action.color} flex items-center justify-center mb-3`}>
                <action.icon size={18} className="text-white" />
              </div>
              <p className="text-xs font-medium text-gray-400 group-hover:text-white transition-colors">{action.label}</p>
            </Link>
          </motion.div>
        ))}
      </div>

      {/* Stats Grid */}
      {stats && (
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
          <StatsCard title={'\u0625\u062c\u0645\u0627\u0644\u064a \u0627\u0644\u0635\u0641\u0642\u0627\u062a'} value={stats.totalTrades} icon={Activity} color="blue" delay={0.1} />
          <StatsCard title={'\u0635\u0627\u0641\u064a \u0627\u0644\u0631\u0628\u062d'} value={`$${stats.totalProfit}`}
            icon={stats.totalProfit >= 0 ? TrendingUp : TrendingDown}
            color={stats.totalProfit >= 0 ? 'emerald' : 'red'} delay={0.2} />
          <StatsCard title={'\u0646\u0633\u0628\u0629 \u0627\u0644\u0641\u0648\u0632'} value={`${stats.winRate}%`} icon={Target} color="amber" delay={0.3} />
          <StatsCard title={'\u0639\u0627\u0645\u0644 \u0627\u0644\u0631\u0628\u062d'} value={stats.profitFactor} icon={BarChart3} color="purple" delay={0.4} />
        </div>
      )}

      {/* Recent Trades */}
      <div className="bg-[#0d1224] rounded-2xl border border-[#1a2340] overflow-hidden">
        <div className="p-5 border-b border-[#1a2340] flex items-center justify-between">
          <h2 className="text-lg font-semibold text-white">{'\u0622\u062e\u0631 \u0627\u0644\u0635\u0641\u0642\u0627\u062a'}</h2>
          <Link to="/trades" className="text-sm text-emerald-400 hover:text-emerald-300">{'\u0639\u0631\u0636 \u0627\u0644\u0643\u0644'} &larr;</Link>
        </div>
        {recentTrades.length === 0 ? (
          <div className="p-10 text-center text-gray-500">
            <Activity size={40} className="mx-auto mb-3 opacity-30" />
            <p>{'\u0644\u0627 \u062a\u0648\u062c\u062f \u0635\u0641\u0642\u0627\u062a \u0628\u0639\u062f'}</p>
            <Link to="/add-trade" className="text-emerald-400 text-sm mt-2 inline-block">{'\u0623\u0636\u0641 \u0623\u0648\u0644 \u0635\u0641\u0642\u0629'} &larr;</Link>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="text-gray-500 text-xs border-b border-[#1a2340]">
                  <th className="px-5 py-3 text-right">{'\u0627\u0644\u0631\u0645\u0632'}</th>
                  <th className="px-5 py-3 text-right">{'\u0627\u0644\u0646\u0648\u0639'}</th>
                  <th className="px-5 py-3 text-right">{'\u0627\u0644\u062d\u062c\u0645'}</th>
                  <th className="px-5 py-3 text-right">{'\u0627\u0644\u0631\u0628\u062d'}</th>
                  <th className="px-5 py-3 text-right">{'\u0627\u0644\u062a\u0627\u0631\u064a\u062e'}</th>
                </tr>
              </thead>
              <tbody>
                {recentTrades.map((t) => (
                  <tr key={t.id} className="border-b border-[#1a2340]/50 hover:bg-[#131b35]/50">
                    <td className="px-5 py-3 font-medium text-white">{t.symbol}</td>
                    <td className="px-5 py-3">
                      <span className={`px-2 py-0.5 rounded text-xs font-medium ${
                        t.trade_type === 'buy' ? 'bg-emerald-500/20 text-emerald-400' : 'bg-red-500/20 text-red-400'
                      }`}>
                        {t.trade_type === 'buy' ? '\u0634\u0631\u0627\u0621' : '\u0628\u064a\u0639'}
                      </span>
                    </td>
                    <td className="px-5 py-3 text-gray-400">{t.lot_size}</td>
                    <td className={`px-5 py-3 font-medium ${t.profit >= 0 ? 'text-emerald-400' : 'text-red-400'}`}>
                      ${t.profit?.toFixed(2)}
                    </td>
                    <td className="px-5 py-3 text-gray-500">{t.trade_date}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
}
