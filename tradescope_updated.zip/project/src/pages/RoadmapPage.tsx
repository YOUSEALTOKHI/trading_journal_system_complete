import { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Compass, DollarSign, Zap, Plus, Save, Trash2, ChevronUp, ChevronDown } from 'lucide-react';
import LoadingSpinner from '../components/LoadingSpinner';
import { api } from '../lib/api';

const PILLARS = [
  { key: 'methodology', label: '\u0627\u0644\u0645\u0646\u0647\u062c\u064a\u0629', icon: Compass, color: 'from-blue-500 to-indigo-500', desc: '\u062f\u0645\u062c \u0637\u0631\u0642 \u062a\u062f\u0627\u0648\u0644 \u0645\u0646\u062e\u0641\u0636\u0629 \u0627\u0644\u0645\u062e\u0627\u0637\u0631 \u0645\u0639 \u0627\u0644\u062d\u0643\u0645\u0629' },
  { key: 'money_management', label: '\u0627\u0644\u0625\u062f\u0627\u0631\u0629 \u0627\u0644\u0645\u0627\u0644\u064a\u0629', icon: DollarSign, color: 'from-emerald-500 to-green-500', desc: '\u062a\u0637\u0648\u064a\u0631 \u062e\u0648\u0627\u0631\u0632\u0645\u064a\u0627\u062a \u0625\u062f\u0627\u0631\u0629 \u0627\u0644\u0623\u0645\u0648\u0627\u0644' },
  { key: 'execution', label: '\u0627\u0644\u062a\u0646\u0641\u064a\u0630', icon: Zap, color: 'from-amber-500 to-orange-500', desc: '\u0635\u064a\u0627\u063a\u0629 \u062e\u0637\u0629 \u0639\u0645\u0644 \u0648\u0627\u0636\u062d\u0629 \u0648\u0642\u0627\u0628\u0644\u0629 \u0644\u0644\u062a\u062a\u0628\u0639' },
];

const STATUS_LABELS: Record<string, { label: string; color: string }> = {
  pending: { label: '\u0642\u064a\u062f \u0627\u0644\u0627\u0646\u062a\u0638\u0627\u0631', color: 'bg-gray-500/20 text-gray-400' },
  in_progress: { label: '\u062c\u0627\u0631\u064a', color: 'bg-blue-500/20 text-blue-400' },
  completed: { label: '\u0645\u0643\u062a\u0645\u0644', color: 'bg-emerald-500/20 text-emerald-400' },
};

export default function RoadmapPage() {
  const [items, setItems] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [showAdd, setShowAdd] = useState(false);
  const [form, setForm] = useState({ pillar: 'methodology', title: '', description: '', status: 'pending', progress: 0 });

  const fetchItems = async () => {
    try {
      const data = await api.getRoadmap();
      setItems(data);
    } catch (err) { console.error(err); }
    finally { setLoading(false); }
  };

  useEffect(() => { fetchItems(); }, []);

  const handleAdd = async () => {
    if (!form.title.trim()) return;
    await api.createRoadmapItem({ ...form, sort_order: items.length + 1 });
    setForm({ pillar: 'methodology', title: '', description: '', status: 'pending', progress: 0 });
    setShowAdd(false);
    fetchItems();
  };

  const handleUpdateProgress = async (id: number, progress: number, status: string) => {
    await api.updateRoadmapItem({ id, progress, status });
    fetchItems();
  };

  const handleDelete = async (id: number) => {
    if (!confirm('\u062d\u0630\u0641\u061f')) return;
    await api.deleteRoadmapItem(id);
    fetchItems();
  };

  if (loading) return <LoadingSpinner />;

  // Calc overall progress
  const overallProgress = items.length > 0 ? Math.round(items.reduce((s, i) => s + (i.progress || 0), 0) / items.length) : 0;

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-white">\u0645\u0635\u0641\u0648\u0641\u0629 \u0627\u0644\u0646\u062c\u0627\u062d</h1>
          <p className="text-sm text-gray-500 mt-1">\u062a\u0637\u0648\u064a\u0631 \u0627\u0644\u0645\u0646\u0647\u062c\u064a\u0629 - \u062e\u0627\u0631\u0637\u0629 \u0627\u0644\u0637\u0631\u064a\u0642</p>
        </div>
        <button onClick={() => setShowAdd(!showAdd)} className="flex items-center gap-2 px-5 py-2.5 bg-emerald-600 hover:bg-emerald-700 rounded-xl text-white text-sm font-medium">
          <Plus size={16} />\u0625\u0636\u0627\u0641\u0629 \u0645\u0647\u0645\u0629
        </button>
      </div>

      {/* Overall Progress */}
      <div className="bg-[#0d1224] rounded-2xl border border-[#1a2340] p-6">
        <div className="flex items-center justify-between mb-3">
          <span className="text-sm text-gray-400">\u0627\u0644\u062a\u0642\u062f\u0645 \u0627\u0644\u0639\u0627\u0645</span>
          <span className="text-lg font-bold text-white">{overallProgress}%</span>
        </div>
        <div className="w-full h-3 bg-[#1a2340] rounded-full overflow-hidden">
          <motion.div initial={{ width: 0 }} animate={{ width: `${overallProgress}%` }} transition={{ duration: 1, ease: 'easeOut' }}
            className="h-full rounded-full bg-gradient-to-l from-emerald-500 to-cyan-500" />
        </div>
      </div>

      {/* Add Form */}
      {showAdd && (
        <motion.div initial={{ opacity: 0, y: -10 }} animate={{ opacity: 1, y: 0 }} className="bg-[#0d1224] rounded-2xl border border-emerald-500/20 p-6 space-y-4">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs text-gray-400 mb-1">\u0627\u0644\u0645\u062d\u0648\u0631</label>
              <select value={form.pillar} onChange={e => setForm({...form, pillar: e.target.value})}
                className="w-full bg-[#0a0e1a] border border-[#1a2340] rounded-xl px-4 py-2.5 text-sm text-gray-200 focus:border-emerald-500/50 focus:outline-none">
                {PILLARS.map(p => <option key={p.key} value={p.key}>{p.label}</option>)}
              </select>
            </div>
            <div>
              <label className="block text-xs text-gray-400 mb-1">\u0627\u0644\u062d\u0627\u0644\u0629</label>
              <select value={form.status} onChange={e => setForm({...form, status: e.target.value})}
                className="w-full bg-[#0a0e1a] border border-[#1a2340] rounded-xl px-4 py-2.5 text-sm text-gray-200 focus:border-emerald-500/50 focus:outline-none">
                <option value="pending">\u0642\u064a\u062f \u0627\u0644\u0627\u0646\u062a\u0638\u0627\u0631</option>
                <option value="in_progress">\u062c\u0627\u0631\u064a</option>
                <option value="completed">\u0645\u0643\u062a\u0645\u0644</option>
              </select>
            </div>
          </div>
          <div>
            <label className="block text-xs text-gray-400 mb-1">\u0627\u0644\u0639\u0646\u0648\u0627\u0646</label>
            <input type="text" value={form.title} onChange={e => setForm({...form, title: e.target.value})}
              className="w-full bg-[#0a0e1a] border border-[#1a2340] rounded-xl px-4 py-2.5 text-sm text-gray-200 focus:border-emerald-500/50 focus:outline-none" />
          </div>
          <div>
            <label className="block text-xs text-gray-400 mb-1">\u0627\u0644\u0648\u0635\u0641</label>
            <textarea value={form.description} onChange={e => setForm({...form, description: e.target.value})}
              className="w-full bg-[#0a0e1a] border border-[#1a2340] rounded-xl px-4 py-3 text-sm text-gray-200 focus:border-emerald-500/50 focus:outline-none h-20 resize-none" />
          </div>
          <button onClick={handleAdd} className="px-6 py-2.5 bg-emerald-600 hover:bg-emerald-700 rounded-xl text-white text-sm font-medium">\u062d\u0641\u0638</button>
        </motion.div>
      )}

      {/* Pillars */}
      <div className="space-y-8">
        {PILLARS.map(pillar => {
          const Icon = pillar.icon;
          const pillarItems = items.filter(i => i.pillar === pillar.key);
          const pillarProgress = pillarItems.length > 0 ? Math.round(pillarItems.reduce((s, i) => s + (i.progress || 0), 0) / pillarItems.length) : 0;
          return (
            <div key={pillar.key}>
              <div className="flex items-center gap-3 mb-4">
                <div className={`w-10 h-10 rounded-xl bg-gradient-to-br ${pillar.color} flex items-center justify-center`}>
                  <Icon size={20} className="text-white" />
                </div>
                <div className="flex-1">
                  <div className="flex items-center justify-between">
                    <h2 className="text-lg font-semibold text-white">{pillar.label}</h2>
                    <span className="text-sm font-bold text-gray-400">{pillarProgress}%</span>
                  </div>
                  <p className="text-xs text-gray-500">{pillar.desc}</p>
                </div>
              </div>
              <div className="space-y-3 mr-6">
                {pillarItems.map((item, i) => {
                  const st = STATUS_LABELS[item.status] || STATUS_LABELS.pending;
                  return (
                    <motion.div key={item.id} initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: i * 0.05 }}
                      className="bg-[#0d1224] rounded-xl border border-[#1a2340] p-4 group">
                      <div className="flex items-start justify-between mb-3">
                        <div>
                          <h3 className="text-sm font-medium text-white">{item.title}</h3>
                          {item.description && <p className="text-xs text-gray-500 mt-1">{item.description}</p>}
                        </div>
                        <div className="flex items-center gap-2">
                          <span className={`px-2 py-0.5 rounded-lg text-xs font-medium ${st.color}`}>{st.label}</span>
                          <button onClick={() => handleDelete(item.id)} className="p-1 rounded hover:bg-red-500/10 text-gray-600 hover:text-red-400 opacity-0 group-hover:opacity-100 transition-opacity"><Trash2 size={14} /></button>
                        </div>
                      </div>
                      <div className="flex items-center gap-3">
                        <div className="flex-1 h-2 bg-[#1a2340] rounded-full overflow-hidden">
                          <div className={`h-full rounded-full bg-gradient-to-l ${pillar.color} transition-all duration-500`} style={{ width: `${item.progress}%` }} />
                        </div>
                        <span className="text-xs text-gray-400 w-10 text-left">{item.progress}%</span>
                        <div className="flex gap-1">
                          <button onClick={() => handleUpdateProgress(item.id, Math.max(0, (item.progress || 0) - 10), (item.progress || 0) - 10 <= 0 ? 'pending' : 'in_progress')}
                            className="p-1 rounded hover:bg-[#1a2340] text-gray-600 hover:text-white"><ChevronDown size={14} /></button>
                          <button onClick={() => handleUpdateProgress(item.id, Math.min(100, (item.progress || 0) + 10), (item.progress || 0) + 10 >= 100 ? 'completed' : 'in_progress')}
                            className="p-1 rounded hover:bg-[#1a2340] text-gray-600 hover:text-white"><ChevronUp size={14} /></button>
                        </div>
                      </div>
                    </motion.div>
                  );
                })}
                {pillarItems.length === 0 && (
                  <div className="text-center py-6 text-gray-600 text-sm">\u0644\u0627 \u062a\u0648\u062c\u062f \u0645\u0647\u0627\u0645 \u0628\u0639\u062f</div>
                )}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
