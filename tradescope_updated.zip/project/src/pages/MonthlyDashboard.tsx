import { useState, useEffect } from 'react';
import { Calendar, TrendingUp, TrendingDown, Target, Activity, BarChart3, Save, AlertTriangle } from 'lucide-react';
import StatsCard from '../components/StatsCard';
import Chart from '../components/Chart';
import LoadingSpinner from '../components/LoadingSpinner';
import { api } from '../lib/api';

export default function MonthlyDashboard() {
  const [month, setMonth] = useState(new Date().toISOString().slice(0, 7));
  const [stats, setStats] = useState<any>(null);
  const [summary, setSummary] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [review, setReview] = useState('');
  const [plans, setPlans] = useState('');
  const [bestTrades, setBestTrades] = useState('');
  const [worstTrades, setWorstTrades] = useState('');

  const fetchData = async () => {
    setLoading(true);
    try {
      const [statsData, summaries] = await Promise.all([
        api.getStats({ period: 'monthly', month }),
        api.getMonthlySummaries({ month }),
      ]);
      setStats(statsData);
      if (summaries.length > 0) {
        const s = summaries[0];
        setSummary(s);
        setReview(s.comprehensive_review || '');
        setPlans(s.development_plans || '');
        setBestTrades(s.best_trades || '');
        setWorstTrades(s.worst_trades || '');
      } else {
        setSummary(null);
        setReview(''); setPlans(''); setBestTrades(''); setWorstTrades('');
      }
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { fetchData(); }, [month]);

  const handleSave = async () => {
    setSaving(true);
    try {
      const payload = {
        month,
        total_trades: stats?.totalTrades || 0,
        total_profit: stats?.totalProfit || 0,
        win_rate: stats?.winRate || 0,
        comprehensive_review: review,
        development_plans: plans,
        best_trades: bestTrades,
        worst_trades: worstTrades,
      };
      if (summary) {
        await api.updateMonthlySummary({ id: summary.id, ...payload });
      } else {
        await api.createMonthlySummary(payload);
      }
      await fetchData();
      alert('تم الحفظ!');
    } catch (err) {
      console.error(err);
    } finally {
      setSaving(false);
    }
  };

  if (loading) return <LoadingSpinner />;

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-bold text-white">لوحة التحكم الشهرية</h1>
        <div className="flex items-center gap-2">
          <Calendar size={16} className="text-gray-500" />
          <input type="month" value={month} onChange={e => setMonth(e.target.value)}
            className="bg-[#0d1224] border border-[#1a2340] rounded-xl px-4 py-2 text-sm text-gray-200 focus:border-emerald-500/50 focus:outline-none" />
        </div>
      </div>

      {stats && (
        <>
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
            <StatsCard title="عدد الصفقات" value={stats.totalTrades} icon={Activity} color="blue" />
            <StatsCard title="صافي الربح" value={`$${stats.totalProfit}`} icon={stats.totalProfit >= 0 ? TrendingUp : TrendingDown} color={stats.totalProfit >= 0 ? 'emerald' : 'red'} />
            <StatsCard title="نسبة الفوز" value={`${stats.winRate}%`} icon={Target} color="amber" />
            <StatsCard title="أقصى تراجع" value={`$${stats.maxDrawdown}`} icon={AlertTriangle} color="red" />
          </div>

          <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
            <StatsCard title="عامل الربح" value={stats.profitFactor} icon={BarChart3} color="purple" />
            <StatsCard title="متوسط الربح" value={`$${stats.avgWin}`} icon={TrendingUp} color="emerald" />
            <StatsCard title="متوسط الخسارة" value={`$${stats.avgLoss}`} icon={TrendingDown} color="red" />
            <StatsCard title="نسبة ربح/خسارة" value={stats.riskRewardRatio} icon={Target} color="cyan" />
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {stats.equityCurve.length > 0 && (
              <Chart type="line" title="منحنى الرصيد الشهري" data={{ labels: stats.equityCurve.map((e: any) => e.date), datasets: [{ label: 'الرصيد', data: stats.equityCurve.map((e: any) => e.balance), color: '#06b6d4' }] }} height={300} />
            )}
            <Chart type="doughnut" title="توزيع الأزواج" data={{ labels: Object.keys(stats.bySymbol), datasets: [{ label: 'الصفقات', data: Object.values(stats.bySymbol).map((s: any) => s.trades), color: '#10b981' }] }} />
          </div>

          {Object.keys(stats.byDay).length > 0 && (
            <Chart type="bar" title="الربح حسب أيام الأسبوع" data={{ labels: Object.keys(stats.byDay), datasets: [{ label: 'الربح', data: Object.values(stats.byDay).map((d: any) => d.profit), color: '#10b981' }] }} />
          )}
        </>
      )}

      {/* Monthly Review Form */}
      <div className="bg-[#0d1224] rounded-2xl border border-[#1a2340] p-6 space-y-4">
        <h2 className="text-lg font-semibold text-white">المراجعة الشهرية الشاملة</h2>
        <div>
          <label className="block text-xs text-gray-400 mb-1">مراجعة شاملة للأداء</label>
          <textarea value={review} onChange={e => setReview(e.target.value)} className="w-full bg-[#0a0e1a] border border-[#1a2340] rounded-xl px-4 py-3 text-sm text-gray-200 focus:border-emerald-500/50 focus:outline-none h-32 resize-none" />
        </div>
        <div>
          <label className="block text-xs text-gray-400 mb-1">خطط التطوير المستقبلية</label>
          <textarea value={plans} onChange={e => setPlans(e.target.value)} className="w-full bg-[#0a0e1a] border border-[#1a2340] rounded-xl px-4 py-3 text-sm text-gray-200 focus:border-emerald-500/50 focus:outline-none h-28 resize-none" />
        </div>
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
          <div>
            <label className="block text-xs text-gray-400 mb-1">أفضل الصفقات</label>
            <textarea value={bestTrades} onChange={e => setBestTrades(e.target.value)} className="w-full bg-[#0a0e1a] border border-[#1a2340] rounded-xl px-4 py-3 text-sm text-gray-200 focus:border-emerald-500/50 focus:outline-none h-28 resize-none" />
          </div>
          <div>
            <label className="block text-xs text-gray-400 mb-1">أسوأ الصفقات</label>
            <textarea value={worstTrades} onChange={e => setWorstTrades(e.target.value)} className="w-full bg-[#0a0e1a] border border-[#1a2340] rounded-xl px-4 py-3 text-sm text-gray-200 focus:border-emerald-500/50 focus:outline-none h-28 resize-none" />
          </div>
        </div>
        <button onClick={handleSave} disabled={saving} className="w-full py-3 bg-gradient-to-l from-emerald-600 to-cyan-600 rounded-xl text-white font-semibold flex items-center justify-center gap-2 disabled:opacity-50">
          <Save size={18} />{saving ? 'جاري الحفظ...' : 'حفظ الملخص الشهري'}
        </button>
      </div>
    </div>
  );
}
