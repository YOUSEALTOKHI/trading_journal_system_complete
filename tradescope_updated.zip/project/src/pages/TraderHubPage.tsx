import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Shield, Target, ClipboardList, Quote, Heart, Plus, Trash2, Edit3, Save, X, ChevronDown } from 'lucide-react';
import LoadingSpinner from '../components/LoadingSpinner';
import { api } from '../lib/api';

const CATEGORIES = [
  { key: 'rules', label: '\u0642\u0648\u0627\u0639\u062f\u064a (My Rules)', icon: Shield, color: 'from-red-500 to-orange-500', border: 'border-red-500/20', bg: 'bg-red-500/5' },
  { key: 'strategies', label: '\u0627\u0633\u062a\u0631\u0627\u062a\u064a\u062c\u064a\u0627\u062a\u064a', icon: Target, color: 'from-blue-500 to-cyan-500', border: 'border-blue-500/20', bg: 'bg-blue-500/5' },
  { key: 'plans', label: '\u062e\u0637\u0637 \u0639\u0645\u0644\u064a', icon: ClipboardList, color: 'from-emerald-500 to-green-500', border: 'border-emerald-500/20', bg: 'bg-emerald-500/5' },
  { key: 'quotes', label: '\u0645\u0623\u062b\u0648\u0631\u0627\u062a', icon: Quote, color: 'from-amber-500 to-yellow-500', border: 'border-amber-500/20', bg: 'bg-amber-500/5' },
  { key: 'beliefs', label: '\u0645\u0639\u062a\u0642\u062f\u0627\u062a\u064a', icon: Heart, color: 'from-purple-500 to-pink-500', border: 'border-purple-500/20', bg: 'bg-purple-500/5' },
];

export default function TraderHubPage() {
  const [activeTab, setActiveTab] = useState('rules');
  const [items, setItems] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [showAdd, setShowAdd] = useState(false);
  const [editingId, setEditingId] = useState<number | null>(null);
  const [form, setForm] = useState({ title: '', content: '', icon: '\u2b50' });

  const fetchItems = async () => {
    setLoading(true);
    try {
      const data = await api.getTraderContent({ category: activeTab });
      setItems(data);
    } catch (err) { console.error(err); }
    finally { setLoading(false); }
  };

  useEffect(() => { fetchItems(); }, [activeTab]);

  const handleSave = async () => {
    if (!form.title.trim() || !form.content.trim()) return;
    try {
      if (editingId) {
        await api.updateTraderContent({ id: editingId, ...form });
      } else {
        await api.createTraderContent({ ...form, category: activeTab, sort_order: items.length + 1 });
      }
      setForm({ title: '', content: '', icon: '\u2b50' });
      setShowAdd(false);
      setEditingId(null);
      fetchItems();
    } catch (err) { console.error(err); }
  };

  const handleDelete = async (id: number) => {
    if (!confirm('\u062d\u0630\u0641 \u0647\u0630\u0627 \u0627\u0644\u0639\u0646\u0635\u0631\u061f')) return;
    await api.deleteTraderContent(id);
    fetchItems();
  };

  const startEdit = (item: any) => {
    setForm({ title: item.title, content: item.content, icon: item.icon || '\u2b50' });
    setEditingId(item.id);
    setShowAdd(true);
  };

  const activeCat = CATEGORIES.find(c => c.key === activeTab)!;

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-bold text-white">\u0645\u0631\u0643\u0632 \u0627\u0644\u0645\u062a\u062f\u0627\u0648\u0644</h1>
        <button onClick={() => { setShowAdd(!showAdd); setEditingId(null); setForm({ title: '', content: '', icon: '\u2b50' }); }}
          className="flex items-center gap-2 px-5 py-2.5 bg-emerald-600 hover:bg-emerald-700 rounded-xl text-white text-sm font-medium">
          <Plus size={16} />\u0625\u0636\u0627\u0641\u0629 \u062c\u062f\u064a\u062f
        </button>
      </div>

      {/* Category Tabs */}
      <div className="flex flex-wrap gap-2">
        {CATEGORIES.map(cat => {
          const Icon = cat.icon;
          const isActive = activeTab === cat.key;
          return (
            <button key={cat.key} onClick={() => setActiveTab(cat.key)}
              className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-sm font-medium transition-all ${
                isActive
                  ? `bg-gradient-to-l ${cat.color} text-white shadow-lg`
                  : 'bg-[#0d1224] border border-[#1a2340] text-gray-400 hover:text-white hover:border-[#2a3560]'
              }`}>
              <Icon size={16} />{cat.label}
            </button>
          );
        })}
      </div>

      {/* Add/Edit Form */}
      <AnimatePresence>
        {showAdd && (
          <motion.div initial={{ height: 0, opacity: 0 }} animate={{ height: 'auto', opacity: 1 }} exit={{ height: 0, opacity: 0 }} className="overflow-hidden">
            <div className={`bg-[#0d1224] rounded-2xl border ${activeCat.border} p-6 space-y-4`}>
              <h3 className="text-sm font-semibold text-emerald-400">{editingId ? '\u062a\u0639\u062f\u064a\u0644' : '\u0625\u0636\u0627\u0641\u0629 \u062c\u062f\u064a\u062f\u0629'}</h3>
              <div className="grid grid-cols-1 sm:grid-cols-[auto_1fr] gap-4">
                <div>
                  <label className="block text-xs text-gray-400 mb-1">\u0627\u0644\u0631\u0645\u0632</label>
                  <input type="text" value={form.icon} onChange={e => setForm({...form, icon: e.target.value})} maxLength={4}
                    className="w-16 bg-[#0a0e1a] border border-[#1a2340] rounded-xl px-3 py-2.5 text-2xl text-center focus:border-emerald-500/50 focus:outline-none" />
                </div>
                <div>
                  <label className="block text-xs text-gray-400 mb-1">\u0627\u0644\u0639\u0646\u0648\u0627\u0646</label>
                  <input type="text" value={form.title} onChange={e => setForm({...form, title: e.target.value})}
                    className="w-full bg-[#0a0e1a] border border-[#1a2340] rounded-xl px-4 py-2.5 text-sm text-gray-200 focus:border-emerald-500/50 focus:outline-none" />
                </div>
              </div>
              <div>
                <label className="block text-xs text-gray-400 mb-1">\u0627\u0644\u0645\u062d\u062a\u0648\u0649</label>
                <textarea value={form.content} onChange={e => setForm({...form, content: e.target.value})}
                  className="w-full bg-[#0a0e1a] border border-[#1a2340] rounded-xl px-4 py-3 text-sm text-gray-200 focus:border-emerald-500/50 focus:outline-none h-32 resize-none" />
              </div>
              <div className="flex gap-3">
                <button onClick={handleSave} className="flex items-center gap-2 px-6 py-2.5 bg-emerald-600 hover:bg-emerald-700 rounded-xl text-white text-sm font-medium">
                  <Save size={16} />{editingId ? '\u062a\u062d\u062f\u064a\u062b' : '\u062d\u0641\u0638'}
                </button>
                <button onClick={() => { setShowAdd(false); setEditingId(null); }} className="px-6 py-2.5 bg-[#1a2340] rounded-xl text-gray-300 text-sm">\u0625\u0644\u063a\u0627\u0621</button>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Content Cards */}
      {loading ? <LoadingSpinner /> : (
        <div className="space-y-4">
          {items.length === 0 ? (
            <div className="bg-[#0d1224] rounded-2xl border border-[#1a2340] p-10 text-center">
              <activeCat.icon size={40} className="mx-auto mb-3 text-gray-700" />
              <p className="text-gray-500">\u0644\u0627 \u062a\u0648\u062c\u062f \u0639\u0646\u0627\u0635\u0631 \u0628\u0639\u062f. \u0623\u0636\u0641 \u0623\u0648\u0644 \u0639\u0646\u0635\u0631!</p>
            </div>
          ) : (
            items.map((item, i) => (
              <motion.div key={item.id} initial={{ opacity: 0, y: 15 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.06 }}
                className={`bg-[#0d1224] rounded-2xl border ${activeCat.border} overflow-hidden group`}>
                <div className="p-5">
                  <div className="flex items-start gap-4">
                    <div className="text-3xl flex-shrink-0 mt-0.5">{item.icon || '\u2b50'}</div>
                    <div className="flex-1 min-w-0">
                      <h3 className="text-white font-semibold mb-2">{item.title}</h3>
                      <p className="text-sm text-gray-400 leading-relaxed whitespace-pre-wrap">{item.content}</p>
                    </div>
                    <div className="flex gap-1 opacity-0 group-hover:opacity-100 transition-opacity flex-shrink-0">
                      <button onClick={() => startEdit(item)} className="p-2 rounded-lg hover:bg-[#1a2340] text-gray-600 hover:text-amber-400"><Edit3 size={15} /></button>
                      <button onClick={() => handleDelete(item.id)} className="p-2 rounded-lg hover:bg-[#1a2340] text-gray-600 hover:text-red-400"><Trash2 size={15} /></button>
                    </div>
                  </div>
                </div>
              </motion.div>
            ))
          )}
        </div>
      )}
    </div>
  );
}
