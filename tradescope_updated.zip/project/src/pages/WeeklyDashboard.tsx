import { useState, useEffect } from 'react';
import { Calendar, TrendingUp, TrendingDown, Target, Activity, BarChart3, Save } from 'lucide-react';
import StatsCard from '../components/StatsCard';
import Chart from '../components/Chart';
import LoadingSpinner from '../components/LoadingSpinner';
import { api } from '../lib/api';

function getWeekStart(d: Date) {
  const day = d.getDay();
  const diff = d.getDate() - day + (day === 0 ? -6 : 1);
  return new Date(d.setDate(diff)).toISOString().split('T')[0];
}

export default function WeeklyDashboard() {
  const [weekStart, setWeekStart] = useState(getWeekStart(new Date()));
  const [stats, setStats] = useState<any>(null);
  const [summary, setSummary] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [review, setReview] = useState('');
  const [goals, setGoals] = useState('');
  const [lessons, setLessons] = useState('');

  const fetchData = async () => {
    setLoading(true);
    try {
      const [statsData, summaries] = await Promise.all([
        api.getStats({ period: 'weekly', week_start: weekStart }),
        api.getWeeklySummaries({ week_start: weekStart }),
      ]);
      setStats(statsData);
      if (summaries.length > 0) {
        const s = summaries[0];
        setSummary(s);
        setReview(s.performance_review || '');
        setGoals(s.next_week_goals || '');
        setLessons(s.key_lessons || '');
      } else {
        setSummary(null);
        setReview(''); setGoals(''); setLessons('');
      }
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { fetchData(); }, [weekStart]);

  const handleSave = async () => {
    setSaving(true);
    try {
      const weekEnd = new Date(new Date(weekStart).getTime() + 6 * 86400000).toISOString().split('T')[0];
      const payload = {
        week_start_date: weekStart,
        week_end_date: weekEnd,
        total_trades: stats?.totalTrades || 0,
        total_profit: stats?.totalProfit || 0,
        win_rate: stats?.winRate || 0,
        performance_review: review,
        next_week_goals: goals,
        key_lessons: lessons,
      };
      if (summary) {
        await api.updateWeeklySummary({ id: summary.id, ...payload });
      } else {
        await api.createWeeklySummary(payload);
      }
      await fetchData();
      alert('تم الحفظ!');
    } catch (err) {
      console.error(err);
    } finally {
      setSaving(false);
    }
  };

  if (loading) return <LoadingSpinner />;

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-bold text-white">لوحة التحكم الأسبوعية</h1>
        <div className="flex items-center gap-2">
          <Calendar size={16} className="text-gray-500" />
          <input type="date" value={weekStart} onChange={e => setWeekStart(e.target.value)}
            className="bg-[#0d1224] border border-[#1a2340] rounded-xl px-4 py-2 text-sm text-gray-200 focus:border-emerald-500/50 focus:outline-none" />
        </div>
      </div>

      {stats && (
        <>
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
            <StatsCard title="عدد الصفقات" value={stats.totalTrades} icon={Activity} color="blue" />
            <StatsCard title="صافي الربح" value={`$${stats.totalProfit}`} icon={stats.totalProfit >= 0 ? TrendingUp : TrendingDown} color={stats.totalProfit >= 0 ? 'emerald' : 'red'} />
            <StatsCard title="نسبة الفوز" value={`${stats.winRate}%`} icon={Target} color="amber" />
            <StatsCard title="عامل الربح" value={stats.profitFactor} icon={BarChart3} color="purple" />
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {stats.equityCurve.length > 0 && (
              <Chart type="line" title="منحنى الرصيد الأسبوعي" data={{ labels: stats.equityCurve.map((e: any) => e.date), datasets: [{ label: 'الرصيد', data: stats.equityCurve.map((e: any) => e.balance), color: '#06b6d4' }] }} />
            )}
            <Chart type="doughnut" title="توزيع الأزواج" data={{ labels: Object.keys(stats.bySymbol), datasets: [{ label: 'الصفقات', data: Object.values(stats.bySymbol).map((s: any) => s.trades), color: '#10b981' }] }} />
          </div>

          {Object.keys(stats.byDay).length > 0 && (
            <Chart type="bar" title="الربح حسب اليوم" data={{ labels: Object.keys(stats.byDay), datasets: [{ label: 'الربح', data: Object.values(stats.byDay).map((d: any) => d.profit), color: '#10b981' }] }} />
          )}
        </>
      )}

      {/* Weekly Review Form */}
      <div className="bg-[#0d1224] rounded-2xl border border-[#1a2340] p-6 space-y-4">
        <h2 className="text-lg font-semibold text-white">المراجعة الأسبوعية</h2>
        <div>
          <label className="block text-xs text-gray-400 mb-1">مراجعة الأداء</label>
          <textarea value={review} onChange={e => setReview(e.target.value)} className="w-full bg-[#0a0e1a] border border-[#1a2340] rounded-xl px-4 py-3 text-sm text-gray-200 focus:border-emerald-500/50 focus:outline-none h-28 resize-none" placeholder="كيف كان أداؤك هذا الأسبوع؟" />
        </div>
        <div>
          <label className="block text-xs text-gray-400 mb-1">أهداف الأسبوع القادم</label>
          <textarea value={goals} onChange={e => setGoals(e.target.value)} className="w-full bg-[#0a0e1a] border border-[#1a2340] rounded-xl px-4 py-3 text-sm text-gray-200 focus:border-emerald-500/50 focus:outline-none h-28 resize-none" placeholder="ما أهدافك للأسبوع القادم؟" />
        </div>
        <div>
          <label className="block text-xs text-gray-400 mb-1">أهم الدروس المستفادة</label>
          <textarea value={lessons} onChange={e => setLessons(e.target.value)} className="w-full bg-[#0a0e1a] border border-[#1a2340] rounded-xl px-4 py-3 text-sm text-gray-200 focus:border-emerald-500/50 focus:outline-none h-28 resize-none" />
        </div>
        <button onClick={handleSave} disabled={saving} className="w-full py-3 bg-gradient-to-l from-emerald-600 to-cyan-600 rounded-xl text-white font-semibold flex items-center justify-center gap-2 disabled:opacity-50">
          <Save size={18} />{saving ? 'جاري الحفظ...' : 'حفظ الملخص الأسبوعي'}
        </button>
      </div>
    </div>
  );
}
