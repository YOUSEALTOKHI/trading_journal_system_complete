import { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Brain, Calendar, TrendingUp, TrendingDown, ChevronLeft, ChevronRight, Award, AlertTriangle } from 'lucide-react';
import LoadingSpinner from '../components/LoadingSpinner';
import { api } from '../lib/api';

export default function CoachInsightsPage() {
  const [feedbacks, setFeedbacks] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedFeedback, setSelectedFeedback] = useState<any>(null);

  useEffect(() => {
    const fetchData = async () => {
      try {
        const data = await api.getCoachFeedback({ limit: '30' });
        setFeedbacks(data);
        if (data.length > 0) setSelectedFeedback(data[0]);
      } catch (err) {
        console.error(err);
      } finally {
        setLoading(false);
      }
    };
    fetchData();
  }, []);

  if (loading) return <LoadingSpinner />;

  const avgScore = feedbacks.length > 0
    ? (feedbacks.reduce((s, f) => s + (f.overall_ai_score || 0), 0) / feedbacks.length).toFixed(1)
    : '-';

  const trend = feedbacks.length >= 2
    ? (feedbacks[0].overall_ai_score || 0) - (feedbacks[1].overall_ai_score || 0)
    : 0;

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <Brain size={28} className="text-purple-400" />
          <h1 className="text-2xl font-bold text-white">تقييم المدرب الذكي</h1>
        </div>
      </div>

      {/* Summary Cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.1 }}
          className="rounded-2xl border bg-gradient-to-br from-purple-500/20 to-purple-600/5 border-purple-500/20 p-5">
          <p className="text-xs text-gray-400 mb-1">متوسط التقييم</p>
          <p className="text-2xl font-bold text-white">{avgScore}</p>
          <p className="text-xs text-gray-500 mt-1">من 10</p>
        </motion.div>
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.2 }}
          className={`rounded-2xl border p-5 ${trend >= 0 ? 'bg-gradient-to-br from-emerald-500/20 to-emerald-600/5 border-emerald-500/20' : 'bg-gradient-to-br from-red-500/20 to-red-600/5 border-red-500/20'}`}>
          <p className="text-xs text-gray-400 mb-1">الاتجاه</p>
          <div className="flex items-center gap-2">
            {trend >= 0 ? <TrendingUp size={20} className="text-emerald-400" /> : <TrendingDown size={20} className="text-red-400" />}
            <p className="text-2xl font-bold text-white">{trend >= 0 ? '+' : ''}{trend}</p>
          </div>
          <p className="text-xs text-gray-500 mt-1">عن آخر تقييم</p>
        </motion.div>
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.3 }}
          className="rounded-2xl border bg-gradient-to-br from-blue-500/20 to-blue-600/5 border-blue-500/20 p-5">
          <p className="text-xs text-gray-400 mb-1">عدد التقييمات</p>
          <p className="text-2xl font-bold text-white">{feedbacks.length}</p>
          <p className="text-xs text-gray-500 mt-1">يوم</p>
        </motion.div>
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.4 }}
          className="rounded-2xl border bg-gradient-to-br from-amber-500/20 to-amber-600/5 border-amber-500/20 p-5">
          <p className="text-xs text-gray-400 mb-1">تنبيهات</p>
          <p className="text-2xl font-bold text-white">{feedbacks.filter(f => f.auto_alert_triggered).length}</p>
          <p className="text-xs text-gray-500 mt-1">يوم بتنبيه</p>
        </motion.div>
      </div>

      {/* Timeline + Detail */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Timeline */}
        <div className="bg-[#0d1224] rounded-2xl border border-[#1a2340] overflow-hidden">
          <div className="p-4 border-b border-[#1a2340]">
            <h3 className="text-sm font-semibold text-white">سجل التقييمات</h3>
          </div>
          <div className="overflow-y-auto max-h-[600px]">
            {feedbacks.length === 0 ? (
              <div className="p-8 text-center text-gray-600">لا توجد تقييمات بعد</div>
            ) : (
              feedbacks.map((f, i) => (
                <button key={f.id} onClick={() => setSelectedFeedback(f)}
                  className={`w-full text-right p-4 border-b border-[#1a2340]/50 transition-all hover:bg-[#131b35] ${
                    selectedFeedback?.id === f.id ? 'bg-[#131b35] border-r-2 border-r-purple-500' : ''
                  }`}>
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <Calendar size={14} className="text-gray-500" />
                      <span className="text-sm text-gray-300">{f.feedback_date}</span>
                    </div>
                    <div className="flex items-center gap-2">
                      {f.auto_alert_triggered && <AlertTriangle size={14} className="text-amber-400" />}
                      <span className={`text-sm font-bold ${
                        (f.overall_ai_score || 0) >= 7 ? 'text-emerald-400' :
                        (f.overall_ai_score || 0) >= 4 ? 'text-amber-400' : 'text-red-400'
                      }`}>{f.overall_ai_score}/10</span>
                    </div>
                  </div>
                  <p className="text-xs text-gray-500 mt-1 truncate">{f.trades_summary}</p>
                </button>
              ))
            )}
          </div>
        </div>

        {/* Detail */}
        <div className="lg:col-span-2">
          {selectedFeedback ? (
            <motion.div key={selectedFeedback.id} initial={{ opacity: 0 }} animate={{ opacity: 1 }}
              className="bg-[#0d1224] rounded-2xl border border-[#1a2340] overflow-hidden">
              <div className="bg-gradient-to-l from-purple-600/20 to-blue-600/20 px-6 py-4 border-b border-purple-500/20">
                <div className="flex items-center justify-between">
                  <h3 className="text-white font-semibold">تقييم {selectedFeedback.feedback_date}</h3>
                  <div className={`px-3 py-1 rounded-full text-sm font-bold ${
                    (selectedFeedback.overall_ai_score || 0) >= 7 ? 'bg-emerald-500/20 text-emerald-400' :
                    (selectedFeedback.overall_ai_score || 0) >= 4 ? 'bg-amber-500/20 text-amber-400' :
                    'bg-red-500/20 text-red-400'
                  }`}>{selectedFeedback.overall_ai_score}/10</div>
                </div>
              </div>
              <div className="p-6 space-y-5 max-h-[550px] overflow-y-auto">
                {[
                  { title: '✅ نقاط القوة', content: selectedFeedback.strengths, color: 'emerald' },
                  { title: '❌ نقاط الضعف', content: selectedFeedback.weaknesses, color: 'red' },
                  { title: '⏰ التحليل الزمني', content: selectedFeedback.time_analysis, color: 'blue' },
                  { title: '📋 تحليل الالتزام', content: selectedFeedback.consistency_check, color: 'amber' },
                  { title: '🔍 الرؤية الثاقبة', content: selectedFeedback.deep_insights, color: 'cyan' },
                  { title: '📈 الصفقات المفتوحة', content: selectedFeedback.open_trades_assessment, color: 'purple' },
                  { title: '💡 التوصيات', content: selectedFeedback.recommendations, color: 'white' },
                ].filter(s => s.content).map((section, i) => (
                  <div key={i}>
                    <h4 className={`text-sm font-semibold mb-2 text-${section.color === 'white' ? 'white' : section.color + '-400'}`}>{section.title}</h4>
                    <div className={`bg-${section.color === 'white' ? 'white' : section.color + '-500'}/5 border border-${section.color === 'white' ? 'white' : section.color + '-500'}/10 rounded-xl p-4`}>
                      <p className="text-sm text-gray-300 whitespace-pre-wrap leading-relaxed">{section.content}</p>
                    </div>
                  </div>
                ))}
                {selectedFeedback.principles_deficient && (
                  <div className="bg-amber-500/10 border border-amber-500/20 rounded-xl p-4">
                    <p className="text-sm text-amber-400">⚠️ المبادئ الناقصة: {selectedFeedback.principles_deficient}</p>
                  </div>
                )}
              </div>
            </motion.div>
          ) : (
            <div className="bg-[#0d1224] rounded-2xl border border-[#1a2340] p-10 text-center">
              <Brain size={40} className="mx-auto mb-3 text-gray-700" />
              <p className="text-gray-500">اختر تقييماً لعرض التفاصيل</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
