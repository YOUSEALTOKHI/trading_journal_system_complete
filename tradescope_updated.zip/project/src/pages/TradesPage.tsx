import { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Search, Trash2, Edit3, Eye, TrendingDown, Zap, Loader2 } from 'lucide-react';
import LoadingSpinner from '../components/LoadingSpinner';
import { api } from '../lib/api';
import { PSYCHOLOGICAL_STATES, ENTRY_REASONS, TRADE_CLASSIFICATIONS } from '../lib/types';

export default function TradesPage() {
  const [trades, setTrades] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [filterType, setFilterType] = useState('');
  const [editingTrade, setEditingTrade] = useState<any>(null);
  const [viewingTrade, setViewingTrade] = useState<any>(null);
  const [calculatingDD, setCalculatingDD] = useState<number | null>(null);

  const fetchTrades = async () => {
    try {
      const data = await api.getTrades();
      setTrades(data);
    } catch (err) { console.error(err); }
    finally { setLoading(false); }
  };

  useEffect(() => { fetchTrades(); }, []);

  const handleDelete = async (id: number) => {
    if (!confirm('\u0647\u0644 \u0623\u0646\u062a \u0645\u062a\u0623\u0643\u062f \u0645\u0646 \u062d\u0630\u0641 \u0647\u0630\u0647 \u0627\u0644\u0635\u0641\u0642\u0629\u061f')) return;
    await api.deleteTrade(id);
    fetchTrades();
  };

  const handleUpdate = async () => {
    if (!editingTrade) return;
    await api.updateTrade(editingTrade);
    setEditingTrade(null);
    fetchTrades();
  };

  const handleCalcDrawdown = async (tradeId: number) => {
    setCalculatingDD(tradeId);
    try {
      await fetch('/api/trade-drawdown', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ trade_id: tradeId }),
      });
      fetchTrades();
    } catch (err) { console.error(err); }
    finally { setCalculatingDD(null); }
  };

  const filtered = trades.filter(t => {
    const matchSearch = !search || t.symbol?.toLowerCase().includes(search.toLowerCase()) || t.ticket?.includes(search);
    const matchType = !filterType || t.trade_type === filterType;
    return matchSearch && matchType;
  });

  if (loading) return <LoadingSpinner />;

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <h1 className="text-2xl font-bold text-white">\u0633\u062c\u0644 \u0627\u0644\u0635\u0641\u0642\u0627\u062a</h1>
        <div className="flex items-center gap-3 w-full sm:w-auto">
          <div className="relative flex-1 sm:flex-initial">
            <Search size={16} className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-500" />
            <input type="text" placeholder="\u0628\u062d\u062b \u0628\u0627\u0644\u0631\u0645\u0632 \u0623\u0648 \u0631\u0642\u0645 \u0627\u0644\u062a\u0630\u0643\u0631\u0629..." value={search} onChange={e => setSearch(e.target.value)}
              className="w-full sm:w-64 bg-[#0d1224] border border-[#1a2340] rounded-xl pr-10 pl-4 py-2.5 text-sm text-gray-200 placeholder-gray-600 focus:border-emerald-500/50 focus:outline-none" />
          </div>
          <select value={filterType} onChange={e => setFilterType(e.target.value)}
            className="bg-[#0d1224] border border-[#1a2340] rounded-xl px-4 py-2.5 text-sm text-gray-300 focus:border-emerald-500/50 focus:outline-none">
            <option value="">\u0627\u0644\u0643\u0644</option>
            <option value="buy">\u0634\u0631\u0627\u0621</option>
            <option value="sell">\u0628\u064a\u0639</option>
          </select>
        </div>
      </div>

      <div className="bg-[#0d1224] rounded-2xl border border-[#1a2340] overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="text-gray-500 text-xs border-b border-[#1a2340] bg-[#0a0e1a]">
                <th className="px-3 py-3 text-right">#</th>
                <th className="px-3 py-3 text-right">\u0627\u0644\u0631\u0645\u0632</th>
                <th className="px-3 py-3 text-right">\u0627\u0644\u0646\u0648\u0639</th>
                <th className="px-3 py-3 text-right">\u0627\u0644\u062d\u062c\u0645</th>
                <th className="px-3 py-3 text-right">\u0627\u0644\u0631\u0628\u062d</th>
                <th className="px-3 py-3 text-right">\u062f\u0631\u0648\u0627 \u062f\u0627\u0648\u0646</th>
                <th className="px-3 py-3 text-right">\u0627\u0644\u062a\u0627\u0631\u064a\u062e</th>
                <th className="px-3 py-3 text-center">\u0625\u062c\u0631\u0627\u0621\u0627\u062a</th>
              </tr>
            </thead>
            <tbody>
              {filtered.map((t, i) => (
                <motion.tr key={t.id} initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: i * 0.02 }}
                  className="border-b border-[#1a2340]/50 hover:bg-[#131b35]/50">
                  <td className="px-3 py-3 text-gray-500 text-xs">{t.ticket}</td>
                  <td className="px-3 py-3 font-medium text-white">{t.symbol}</td>
                  <td className="px-3 py-3">
                    <span className={`px-2 py-0.5 rounded text-xs font-medium ${t.trade_type === 'buy' ? 'bg-emerald-500/20 text-emerald-400' : 'bg-red-500/20 text-red-400'}`}>
                      {t.trade_type === 'buy' ? '\u0634\u0631\u0627\u0621' : '\u0628\u064a\u0639'}
                    </span>
                  </td>
                  <td className="px-3 py-3 text-gray-400">{t.lot_size}</td>
                  <td className={`px-3 py-3 font-semibold ${t.profit >= 0 ? 'text-emerald-400' : 'text-red-400'}`}>${t.profit?.toFixed(2)}</td>
                  <td className="px-3 py-3">
                    {t.trade_drawdown != null && t.trade_drawdown > 0 ? (
                      <span className="text-red-400 font-medium text-xs">-${t.trade_drawdown.toFixed(2)}</span>
                    ) : (
                      <button onClick={() => handleCalcDrawdown(t.id)} disabled={calculatingDD === t.id}
                        className="flex items-center gap-1 text-[11px] text-gray-600 hover:text-amber-400 transition-colors" title="\u062d\u0633\u0627\u0628 \u0628\u0627\u0644\u0630\u0643\u0627\u0621 \u0627\u0644\u0627\u0635\u0637\u0646\u0627\u0639\u064a">
                        {calculatingDD === t.id ? <Loader2 size={12} className="animate-spin" /> : <Zap size={12} />}
                        \u062d\u0633\u0627\u0628
                      </button>
                    )}
                  </td>
                  <td className="px-3 py-3 text-gray-500 text-xs">{t.trade_date}</td>
                  <td className="px-3 py-3">
                    <div className="flex items-center justify-center gap-1">
                      <button onClick={() => setViewingTrade(t)} className="p-1.5 rounded-lg hover:bg-[#1a2340] text-gray-500 hover:text-blue-400"><Eye size={14} /></button>
                      <button onClick={() => setEditingTrade({...t})} className="p-1.5 rounded-lg hover:bg-[#1a2340] text-gray-500 hover:text-amber-400"><Edit3 size={14} /></button>
                      <button onClick={() => handleDelete(t.id)} className="p-1.5 rounded-lg hover:bg-[#1a2340] text-gray-500 hover:text-red-400"><Trash2 size={14} /></button>
                    </div>
                  </td>
                </motion.tr>
              ))}
            </tbody>
          </table>
        </div>
        {filtered.length === 0 && <div className="p-10 text-center text-gray-500">\u0644\u0627 \u062a\u0648\u062c\u062f \u0635\u0641\u0642\u0627\u062a \u0645\u0637\u0627\u0628\u0642\u0629</div>}
      </div>

      {/* View Modal */}
      {viewingTrade && (
        <div className="fixed inset-0 bg-black/70 z-50 flex items-center justify-center p-4" onClick={() => setViewingTrade(null)}>
          <motion.div initial={{ scale: 0.9, opacity: 0 }} animate={{ scale: 1, opacity: 1 }}
            className="bg-[#0d1224] border border-[#1a2340] rounded-2xl p-6 w-full max-w-lg max-h-[80vh] overflow-y-auto"
            onClick={e => e.stopPropagation()}>
            <h3 className="text-lg font-bold text-white mb-4">\u062a\u0641\u0627\u0635\u064a\u0644 \u0627\u0644\u0635\u0641\u0642\u0629 #{viewingTrade.ticket}</h3>
            <div className="space-y-3 text-sm">
              {[
                ['\u0627\u0644\u0631\u0645\u0632', viewingTrade.symbol],
                ['\u0627\u0644\u0646\u0648\u0639', viewingTrade.trade_type === 'buy' ? '\u0634\u0631\u0627\u0621' : '\u0628\u064a\u0639'],
                ['\u0627\u0644\u062a\u0635\u0646\u064a\u0641', TRADE_CLASSIFICATIONS.find(c => c.value === viewingTrade.trade_classification)?.label || '-'],
                ['\u0627\u0644\u062d\u062c\u0645', viewingTrade.lot_size],
                ['\u0633\u0639\u0631 \u0627\u0644\u062f\u062e\u0648\u0644', viewingTrade.open_price],
                ['\u0633\u0639\u0631 \u0627\u0644\u062e\u0631\u0648\u062c', viewingTrade.close_price],
                ['\u0648\u0642\u0641 \u0627\u0644\u062e\u0633\u0627\u0631\u0629', viewingTrade.stop_loss || '-'],
                ['\u0647\u062f\u0641 \u0627\u0644\u0631\u0628\u062d', viewingTrade.take_profit || '-'],
                ['\u0627\u0644\u0631\u0628\u062d', `$${viewingTrade.profit?.toFixed(2)}`],
                ['\u0627\u0644\u0631\u0635\u064a\u062f', `$${viewingTrade.balance_after?.toFixed(2)}`],
              ].map(([label, value]) => (
                <div key={label as string} className="flex justify-between border-b border-[#1a2340] pb-2">
                  <span className="text-gray-400">{label}</span>
                  <span className="text-gray-200">{value}</span>
                </div>
              ))}

              {/* Drawdown section in view */}
              <div className="border-t border-red-500/20 pt-3 mt-3">
                <div className="flex items-center gap-2 mb-2">
                  <TrendingDown size={14} className="text-red-400" />
                  <span className="text-xs font-semibold text-red-400">\u062f\u0631\u0648\u0627 \u062f\u0627\u0648\u0646 \u0627\u0644\u0635\u0641\u0642\u0629</span>
                </div>
                {viewingTrade.trade_drawdown != null && viewingTrade.trade_drawdown > 0 ? (
                  <div className="bg-red-500/5 border border-red-500/10 rounded-xl p-3 space-y-1">
                    <div className="flex justify-between">
                      <span className="text-gray-400">\u0623\u0642\u0635\u0649 \u062f\u0631\u0648\u0627 \u062f\u0627\u0648\u0646</span>
                      <span className="text-red-400 font-bold">-${viewingTrade.trade_drawdown.toFixed(2)}</span>
                    </div>
                    {viewingTrade.drawdown_details && (
                      <p className="text-xs text-gray-500">{typeof viewingTrade.drawdown_details === 'string' && viewingTrade.drawdown_details.startsWith('{') ? (() => { try { const d = JSON.parse(viewingTrade.drawdown_details); return `${d.calculation_method === 'ai_estimated' ? '\u062a\u0642\u062f\u064a\u0631 AI' : '\u064a\u062f\u0648\u064a'} - ${d.notes || ''}`; } catch { return viewingTrade.drawdown_details; } })() : viewingTrade.drawdown_details}</p>
                    )}
                  </div>
                ) : (
                  <div className="flex items-center gap-2">
                    <span className="text-gray-600 text-xs">\u0644\u0645 \u064a\u062a\u0645 \u0627\u0644\u062d\u0633\u0627\u0628 \u0628\u0639\u062f</span>
                    <button onClick={() => { handleCalcDrawdown(viewingTrade.id); setViewingTrade(null); }}
                      className="text-xs text-amber-400 hover:text-amber-300 flex items-center gap-1">
                      <Zap size={12} />\u062d\u0633\u0627\u0628 \u0628\u0627\u0644\u0630\u0643\u0627\u0621 \u0627\u0644\u0627\u0635\u0637\u0646\u0627\u0639\u064a
                    </button>
                  </div>
                )}
              </div>

              {[
                ['\u0633\u0628\u0628 \u0627\u0644\u062f\u062e\u0648\u0644', viewingTrade.entry_reason || '-'],
                ['\u0627\u0644\u062d\u0627\u0644\u0629 \u0627\u0644\u0646\u0641\u0633\u064a\u0629', viewingTrade.psychological_state || '-'],
                ['\u0627\u0644\u0623\u0641\u0643\u0627\u0631', viewingTrade.thoughts_at_entry || '-'],
                ['\u0645\u0644\u0627\u062d\u0638\u0627\u062a', viewingTrade.trading_notes || '-'],
              ].map(([label, value]) => (
                <div key={label as string} className="flex justify-between border-b border-[#1a2340] pb-2">
                  <span className="text-gray-400">{label}</span>
                  <span className="text-gray-200 text-left max-w-[60%]">{value}</span>
                </div>
              ))}
            </div>
            <button onClick={() => setViewingTrade(null)} className="mt-6 w-full py-2.5 bg-[#1a2340] rounded-xl text-gray-300 hover:bg-[#243050]">\u0625\u063a\u0644\u0627\u0642</button>
          </motion.div>
        </div>
      )}

      {/* Edit Modal */}
      {editingTrade && (
        <div className="fixed inset-0 bg-black/70 z-50 flex items-center justify-center p-4" onClick={() => setEditingTrade(null)}>
          <motion.div initial={{ scale: 0.9, opacity: 0 }} animate={{ scale: 1, opacity: 1 }}
            className="bg-[#0d1224] border border-[#1a2340] rounded-2xl p-6 w-full max-w-lg max-h-[80vh] overflow-y-auto"
            onClick={e => e.stopPropagation()}>
            <h3 className="text-lg font-bold text-white mb-4">\u062a\u0639\u062f\u064a\u0644 \u0627\u0644\u0635\u0641\u0642\u0629 #{editingTrade.ticket}</h3>
            <div className="space-y-4">
              {/* Drawdown edit */}
              <div className="bg-red-500/5 border border-red-500/15 rounded-xl p-4 space-y-3">
                <div className="flex items-center gap-2">
                  <TrendingDown size={16} className="text-red-400" />
                  <span className="text-sm font-semibold text-red-400">\u062f\u0631\u0648\u0627 \u062f\u0627\u0648\u0646 \u0627\u0644\u0635\u0641\u0642\u0629</span>
                </div>
                <div>
                  <label className="block text-xs text-gray-400 mb-1">\u0623\u0642\u0635\u0649 \u062f\u0631\u0648\u0627 \u062f\u0627\u0648\u0646 ($)</label>
                  <input type="number" step="any" value={editingTrade.trade_drawdown || ''}
                    onChange={e => setEditingTrade({...editingTrade, trade_drawdown: parseFloat(e.target.value) || 0})}
                    className="w-full bg-[#0a0e1a] border border-[#1a2340] rounded-xl px-4 py-2.5 text-sm text-gray-200 focus:border-red-500/50 focus:outline-none"
                    placeholder="\u0623\u062f\u062e\u0644 \u0623\u0642\u0635\u0649 \u062e\u0633\u0627\u0631\u0629 \u0639\u0627\u0626\u0645\u0629" />
                </div>
                <div>
                  <label className="block text-xs text-gray-400 mb-1">\u062a\u0641\u0627\u0635\u064a\u0644 \u0627\u0644\u062f\u0631\u0648\u0627 \u062f\u0627\u0648\u0646</label>
                  <input type="text" value={editingTrade.drawdown_details || ''}
                    onChange={e => setEditingTrade({...editingTrade, drawdown_details: e.target.value})}
                    className="w-full bg-[#0a0e1a] border border-[#1a2340] rounded-xl px-4 py-2.5 text-sm text-gray-200 focus:border-red-500/50 focus:outline-none"
                    placeholder="\u0645\u0644\u0627\u062d\u0638\u0627\u062a \u0639\u0646 \u0627\u0644\u062f\u0631\u0648\u0627 \u062f\u0627\u0648\u0646" />
                </div>
              </div>

              <div>
                <label className="block text-xs text-gray-400 mb-1">\u062a\u0635\u0646\u064a\u0641 \u0627\u0644\u0635\u0641\u0642\u0629</label>
                <select value={editingTrade.trade_classification || 'intraday'}
                  onChange={e => setEditingTrade({...editingTrade, trade_classification: e.target.value})}
                  className="w-full bg-[#0a0e1a] border border-[#1a2340] rounded-xl px-4 py-2.5 text-sm text-gray-200 focus:border-emerald-500/50 focus:outline-none">
                  {TRADE_CLASSIFICATIONS.map(c => <option key={c.value} value={c.value}>{c.label}</option>)}
                </select>
              </div>
              <div>
                <label className="block text-xs text-gray-400 mb-1">\u0633\u0628\u0628 \u0627\u0644\u062f\u062e\u0648\u0644</label>
                <select value={editingTrade.entry_reason || ''}
                  onChange={e => setEditingTrade({...editingTrade, entry_reason: e.target.value})}
                  className="w-full bg-[#0a0e1a] border border-[#1a2340] rounded-xl px-4 py-2.5 text-sm text-gray-200 focus:border-emerald-500/50 focus:outline-none">
                  <option value="">\u0627\u062e\u062a\u0631...</option>
                  {ENTRY_REASONS.map(r => <option key={r} value={r}>{r}</option>)}
                </select>
              </div>
              <div>
                <label className="block text-xs text-gray-400 mb-1">\u0627\u0644\u062d\u0627\u0644\u0629 \u0627\u0644\u0646\u0641\u0633\u064a\u0629</label>
                <select value={editingTrade.psychological_state || ''}
                  onChange={e => setEditingTrade({...editingTrade, psychological_state: e.target.value})}
                  className="w-full bg-[#0a0e1a] border border-[#1a2340] rounded-xl px-4 py-2.5 text-sm text-gray-200 focus:border-emerald-500/50 focus:outline-none">
                  <option value="">\u0627\u062e\u062a\u0631...</option>
                  {PSYCHOLOGICAL_STATES.map(s => <option key={s} value={s}>{s}</option>)}
                </select>
              </div>
              <div>
                <label className="block text-xs text-gray-400 mb-1">\u0645\u0644\u0627\u062d\u0638\u0627\u062a</label>
                <textarea value={editingTrade.trading_notes || ''}
                  onChange={e => setEditingTrade({...editingTrade, trading_notes: e.target.value})}
                  className="w-full bg-[#0a0e1a] border border-[#1a2340] rounded-xl px-4 py-2.5 text-sm text-gray-200 focus:border-emerald-500/50 focus:outline-none h-20 resize-none" />
              </div>
              <div className="flex gap-3">
                <button onClick={handleUpdate} className="flex-1 py-2.5 bg-emerald-600 hover:bg-emerald-700 rounded-xl text-white font-medium text-sm">\u062d\u0641\u0638</button>
                <button onClick={() => setEditingTrade(null)} className="flex-1 py-2.5 bg-[#1a2340] rounded-xl text-gray-300 hover:bg-[#243050] text-sm">\u0625\u0644\u063a\u0627\u0621</button>
              </div>
            </div>
          </motion.div>
        </div>
      )}
    </div>
  );
}
