import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { FileText, Search, Plus, Trash2, ExternalLink, Globe, Calendar } from 'lucide-react';
import LoadingSpinner from '../components/LoadingSpinner';
import { api } from '../lib/api';

const SOURCES = ['Forex Factory', 'Investing.com', 'Bloomberg', 'Federal Reserve', 'Reuters', 'أخرى'];

export default function ReportsPage() {
  const [reports, setReports] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [showAdd, setShowAdd] = useState(false);
  const [search, setSearch] = useState('');
  const [filterSource, setFilterSource] = useState('');
  const [expandedId, setExpandedId] = useState<number | null>(null);
  const [saving, setSaving] = useState(false);
  const [newReport, setNewReport] = useState({
    source: 'Forex Factory',
    original_url: '',
    original_title: '',
    summary: '',
    language: 'ar',
    ai_model_used: 'manual',
    tags: '',
  });

  const fetchReports = async () => {
    try {
      const params: Record<string, string> = {};
      if (filterSource) params.source = filterSource;
      if (search) params.keyword = search;
      const data = await api.getReports(params);
      setReports(data);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { fetchReports(); }, [filterSource, search]);

  const handleAdd = async () => {
    if (!newReport.original_title || !newReport.summary) {
      alert('يرجى ملء العنوان والملخص');
      return;
    }
    setSaving(true);
    try {
      await api.createReport({
        ...newReport,
        extraction_date: new Date().toISOString().split('T')[0],
      });
      setShowAdd(false);
      setNewReport({ source: 'Forex Factory', original_url: '', original_title: '', summary: '', language: 'ar', ai_model_used: 'manual', tags: '' });
      fetchReports();
    } catch (err) {
      console.error(err);
    } finally {
      setSaving(false);
    }
  };

  const handleDelete = async (id: number) => {
    if (!confirm('حذف هذا التقرير؟')) return;
    await api.deleteReport(id);
    fetchReports();
  };

  if (loading) return <LoadingSpinner />;

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <h1 className="text-2xl font-bold text-white">تقارير التحليل الأساسي</h1>
        <button onClick={() => setShowAdd(!showAdd)} className="flex items-center gap-2 px-5 py-2.5 bg-emerald-600 hover:bg-emerald-700 rounded-xl text-white text-sm font-medium">
          <Plus size={16} />إضافة تقرير
        </button>
      </div>

      {/* Filters */}
      <div className="flex flex-col sm:flex-row gap-3">
        <div className="relative flex-1">
          <Search size={16} className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-500" />
          <input type="text" placeholder="بحث في الملخصات..." value={search} onChange={e => setSearch(e.target.value)}
            className="w-full bg-[#0d1224] border border-[#1a2340] rounded-xl pr-10 pl-4 py-2.5 text-sm text-gray-200 placeholder-gray-600 focus:border-emerald-500/50 focus:outline-none" />
        </div>
        <select value={filterSource} onChange={e => setFilterSource(e.target.value)}
          className="bg-[#0d1224] border border-[#1a2340] rounded-xl px-4 py-2.5 text-sm text-gray-300 focus:border-emerald-500/50 focus:outline-none">
          <option value="">كل المصادر</option>
          {SOURCES.map(s => <option key={s} value={s}>{s}</option>)}
        </select>
      </div>

      {/* Add Form */}
      <AnimatePresence>
        {showAdd && (
          <motion.div initial={{ height: 0, opacity: 0 }} animate={{ height: 'auto', opacity: 1 }} exit={{ height: 0, opacity: 0 }} className="overflow-hidden">
            <div className="bg-[#0d1224] rounded-2xl border border-emerald-500/20 p-6 space-y-4">
              <h3 className="text-sm font-semibold text-emerald-400">إضافة تقرير جديد</h3>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs text-gray-400 mb-1">المصدر</label>
                  <select value={newReport.source} onChange={e => setNewReport({...newReport, source: e.target.value})}
                    className="w-full bg-[#0a0e1a] border border-[#1a2340] rounded-xl px-4 py-2.5 text-sm text-gray-200 focus:border-emerald-500/50 focus:outline-none">
                    {SOURCES.map(s => <option key={s} value={s}>{s}</option>)}
                  </select>
                </div>
                <div>
                  <label className="block text-xs text-gray-400 mb-1">اللغة</label>
                  <select value={newReport.language} onChange={e => setNewReport({...newReport, language: e.target.value})}
                    className="w-full bg-[#0a0e1a] border border-[#1a2340] rounded-xl px-4 py-2.5 text-sm text-gray-200 focus:border-emerald-500/50 focus:outline-none">
                    <option value="ar">عربي</option>
                    <option value="en">English</option>
                  </select>
                </div>
              </div>
              <div>
                <label className="block text-xs text-gray-400 mb-1">العنوان الأصلي</label>
                <input type="text" value={newReport.original_title} onChange={e => setNewReport({...newReport, original_title: e.target.value})}
                  className="w-full bg-[#0a0e1a] border border-[#1a2340] rounded-xl px-4 py-2.5 text-sm text-gray-200 focus:border-emerald-500/50 focus:outline-none" />
              </div>
              <div>
                <label className="block text-xs text-gray-400 mb-1">الرابط الأصلي</label>
                <input type="url" dir="ltr" value={newReport.original_url} onChange={e => setNewReport({...newReport, original_url: e.target.value})}
                  className="w-full bg-[#0a0e1a] border border-[#1a2340] rounded-xl px-4 py-2.5 text-sm text-gray-200 focus:border-emerald-500/50 focus:outline-none" />
              </div>
              <div>
                <label className="block text-xs text-gray-400 mb-1">الملخص</label>
                <textarea value={newReport.summary} onChange={e => setNewReport({...newReport, summary: e.target.value})}
                  className="w-full bg-[#0a0e1a] border border-[#1a2340] rounded-xl px-4 py-3 text-sm text-gray-200 focus:border-emerald-500/50 focus:outline-none h-32 resize-none" />
              </div>
              <div>
                <label className="block text-xs text-gray-400 mb-1">الكلمات المفتاحية (مفصولة بفواصل)</label>
                <input type="text" value={newReport.tags} onChange={e => setNewReport({...newReport, tags: e.target.value})}
                  className="w-full bg-[#0a0e1a] border border-[#1a2340] rounded-xl px-4 py-2.5 text-sm text-gray-200 focus:border-emerald-500/50 focus:outline-none"
                  placeholder="فائدة, تضخم, الفيدرالي" />
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs text-gray-400 mb-1">نموذج AI المستخدم</label>
                  <select value={newReport.ai_model_used} onChange={e => setNewReport({...newReport, ai_model_used: e.target.value})}
                    className="w-full bg-[#0a0e1a] border border-[#1a2340] rounded-xl px-4 py-2.5 text-sm text-gray-200 focus:border-emerald-500/50 focus:outline-none">
                    <option value="manual">يدوي</option>
                    <option value="gpt-4.1-mini">GPT-4.1 Mini</option>
                    <option value="gemini-2.5-flash">Gemini 2.5 Flash</option>
                    <option value="claude-sonnet">Claude Sonnet</option>
                  </select>
                </div>
              </div>
              <div className="flex gap-3">
                <button onClick={handleAdd} disabled={saving} className="flex-1 py-2.5 bg-emerald-600 hover:bg-emerald-700 rounded-xl text-white font-medium text-sm disabled:opacity-50">
                  {saving ? 'جاري الحفظ...' : 'حفظ التقرير'}
                </button>
                <button onClick={() => setShowAdd(false)} className="px-6 py-2.5 bg-[#1a2340] rounded-xl text-gray-300 text-sm">إلغاء</button>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Reports List */}
      <div className="space-y-4">
        {reports.length === 0 ? (
          <div className="bg-[#0d1224] rounded-2xl border border-[#1a2340] p-10 text-center">
            <FileText size={40} className="mx-auto mb-3 text-gray-700" />
            <p className="text-gray-500">لا توجد تقارير بعد</p>
          </div>
        ) : (
          reports.map((r, i) => (
            <motion.div
              key={r.id}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: i * 0.05 }}
              className="bg-[#0d1224] rounded-2xl border border-[#1a2340] overflow-hidden"
            >
              <div className="p-5 cursor-pointer" onClick={() => setExpandedId(expandedId === r.id ? null : r.id)}>
                <div className="flex items-start justify-between">
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-2">
                      <span className="px-2 py-0.5 rounded-lg bg-blue-500/20 text-blue-400 text-xs">{r.source}</span>
                      <span className="px-2 py-0.5 rounded-lg bg-purple-500/20 text-purple-400 text-xs">{r.language === 'ar' ? 'عربي' : 'English'}</span>
                      {r.ai_model_used && r.ai_model_used !== 'manual' && (
                        <span className="px-2 py-0.5 rounded-lg bg-amber-500/20 text-amber-400 text-xs">{r.ai_model_used}</span>
                      )}
                    </div>
                    <h3 className="text-white font-medium mb-1">{r.original_title}</h3>
                    <div className="flex items-center gap-3 text-xs text-gray-500">
                      <span className="flex items-center gap-1"><Calendar size={12} />{r.extraction_date}</span>
                      {r.original_url && <a href={r.original_url} target="_blank" rel="noopener noreferrer" className="flex items-center gap-1 text-emerald-500 hover:text-emerald-400" onClick={e => e.stopPropagation()}><ExternalLink size={12} />المصدر</a>}
                    </div>
                  </div>
                  <button onClick={e => { e.stopPropagation(); handleDelete(r.id); }} className="p-2 rounded-lg hover:bg-red-500/10 text-gray-600 hover:text-red-400">
                    <Trash2 size={16} />
                  </button>
                </div>
              </div>
              <AnimatePresence>
                {expandedId === r.id && (
                  <motion.div initial={{ height: 0 }} animate={{ height: 'auto' }} exit={{ height: 0 }} className="overflow-hidden">
                    <div className="px-5 pb-5 border-t border-[#1a2340] pt-4">
                      <p className="text-sm text-gray-300 leading-relaxed whitespace-pre-wrap">{r.summary}</p>
                      {r.tags && (
                        <div className="flex flex-wrap gap-2 mt-3">
                          {r.tags.split(',').map((tag: string, ti: number) => (
                            <span key={ti} className="px-2 py-0.5 rounded bg-[#1a2340] text-gray-400 text-xs">{tag.trim()}</span>
                          ))}
                        </div>
                      )}
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>
            </motion.div>
          ))
        )}
      </div>
    </div>
  );
}
