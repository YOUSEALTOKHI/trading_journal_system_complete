import { useState, useRef, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Send, Bot, User, Loader2 } from 'lucide-react';
import { api } from '../lib/api';

interface Message {
  role: 'user' | 'assistant';
  content: string;
  timestamp: Date;
}

const COMMANDS = [
  { cmd: 'أداء اليوم', desc: 'عرض إحصائيات اليوم' },
  { cmd: 'أداء الأسبوع', desc: 'عرض إحصائيات الأسبوع' },
  { cmd: 'أداء الشهر', desc: 'عرض إحصائيات الشهر' },
  { cmd: 'آخر الصفقات', desc: 'عرض آخر 5 صفقات' },
  { cmd: 'آخر التقارير', desc: 'عرض آخر التقارير الأساسية' },
  { cmd: 'مساعدة', desc: 'عرض الأوامر المتاحة' },
];

export default function ChatPage() {
  const [messages, setMessages] = useState<Message[]>([
    { role: 'assistant', content: 'مرحباً! أنا مساعدك الذكي لإدارة التداول. يمكنك سؤالي عن أدائك أو طلب تقارير. اكتب "مساعدة" لعرض الأوامر المتاحة.', timestamp: new Date() },
  ]);
  const [input, setInput] = useState('');
  const [processing, setProcessing] = useState(false);
  const chatEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    chatEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  const processCommand = async (text: string): Promise<string> => {
    const lower = text.trim();

    if (lower.includes('مساعدة') || lower.includes('help')) {
      return '📚 **الأوامر المتاحة:**\n\n' + COMMANDS.map(c => `• **${c.cmd}** - ${c.desc}`).join('\n');
    }

    if (lower.includes('أداء اليوم') || lower.includes('اليوم')) {
      const today = new Date().toISOString().split('T')[0];
      const stats = await api.getStats({ period: 'daily', date: today });
      return `📈 **أداء اليوم (${today}):**\n\n` +
        `• عدد الصفقات: ${stats.totalTrades}\n` +
        `• صافي الربح: $${stats.totalProfit}\n` +
        `• نسبة الفوز: ${stats.winRate}%\n` +
        `• عامل الربح: ${stats.profitFactor}\n` +
        `• أكبر ربح: $${stats.largestWin}\n` +
        `• أكبر خسارة: $${stats.largestLoss}`;
    }

    if (lower.includes('أداء الأسبوع') || lower.includes('الأسبوع')) {
      const d = new Date();
      const day = d.getDay();
      const diff = d.getDate() - day + (day === 0 ? -6 : 1);
      const weekStart = new Date(d.setDate(diff)).toISOString().split('T')[0];
      const stats = await api.getStats({ period: 'weekly', week_start: weekStart });
      return `📅 **أداء الأسبوع (من ${weekStart}):**\n\n` +
        `• عدد الصفقات: ${stats.totalTrades}\n` +
        `• صافي الربح: $${stats.totalProfit}\n` +
        `• نسبة الفوز: ${stats.winRate}%\n` +
        `• أقصى تراجع: $${stats.maxDrawdown}\n` +
        `• أكبر سلسلة ربح: ${stats.maxConsecutiveWins}\n` +
        `• أكبر سلسلة خسارة: ${stats.maxConsecutiveLosses}`;
    }

    if (lower.includes('أداء الشهر') || lower.includes('الشهر')) {
      const month = new Date().toISOString().slice(0, 7);
      const stats = await api.getStats({ period: 'monthly', month });
      return `🗓️ **أداء الشهر (${month}):**\n\n` +
        `• عدد الصفقات: ${stats.totalTrades}\n` +
        `• صافي الربح: $${stats.totalProfit}\n` +
        `• نسبة الفوز: ${stats.winRate}%\n` +
        `• عامل الربح: ${stats.profitFactor}\n` +
        `• متوسط الربح: $${stats.avgWin}\n` +
        `• متوسط الخسارة: $${stats.avgLoss}\n` +
        `• نسبة ربح/خسارة: ${stats.riskRewardRatio}`;
    }

    if (lower.includes('آخر الصفقات') || lower.includes('الصفقات')) {
      const trades = await api.getTrades();
      const recent = trades.slice(0, 5);
      if (recent.length === 0) return 'لا توجد صفقات مسجلة بعد.';
      return `📊 **آخر ${recent.length} صفقات:**\n\n` +
        recent.map(t => `• ${t.symbol} | ${t.trade_type === 'buy' ? 'شراء' : 'بيع'} | ${t.lot_size} lot | **$${t.profit?.toFixed(2)}** | ${t.trade_date}`).join('\n');
    }

    if (lower.includes('آخر التقارير') || lower.includes('تقارير')) {
      const reports = await api.getReports();
      const recent = reports.slice(0, 5);
      if (recent.length === 0) return 'لا توجد تقارير مخزنة بعد.';
      return `📰 **آخر ${recent.length} تقارير:**\n\n` +
        recent.map(r => `• **${r.original_title}** (${r.source}) - ${r.extraction_date}`).join('\n');
    }

    return 'عذراً، لم أفهم طلبك. اكتب "مساعدة" لعرض الأوامر المتاحة.';
  };

  const handleSend = async () => {
    if (!input.trim() || processing) return;
    const userMsg: Message = { role: 'user', content: input.trim(), timestamp: new Date() };
    setMessages(prev => [...prev, userMsg]);
    setInput('');
    setProcessing(true);

    try {
      const response = await processCommand(userMsg.content);
      setMessages(prev => [...prev, { role: 'assistant', content: response, timestamp: new Date() }]);
    } catch (err) {
      setMessages(prev => [...prev, { role: 'assistant', content: 'حدث خطأ في معالجة طلبك. حاول مرة أخرى.', timestamp: new Date() }]);
    } finally {
      setProcessing(false);
    }
  };

  return (
    <div className="flex flex-col h-[calc(100vh-140px)] max-w-3xl mx-auto">
      <h1 className="text-2xl font-bold text-white mb-4">المساعد الذكي</h1>

      {/* Quick Commands */}
      <div className="flex flex-wrap gap-2 mb-4">
        {COMMANDS.filter(c => c.cmd !== 'مساعدة').map(c => (
          <button
            key={c.cmd}
            onClick={() => { setInput(c.cmd); }}
            className="px-3 py-1.5 rounded-lg bg-[#0d1224] border border-[#1a2340] text-xs text-gray-400 hover:text-emerald-400 hover:border-emerald-500/30 transition-all"
          >
            {c.cmd}
          </button>
        ))}
      </div>

      {/* Messages */}
      <div className="flex-1 overflow-y-auto space-y-4 mb-4 px-1">
        {messages.map((msg, i) => (
          <motion.div
            key={i}
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            className={`flex gap-3 ${msg.role === 'user' ? 'flex-row-reverse' : ''}`}
          >
            <div className={`w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0 ${
              msg.role === 'user' ? 'bg-emerald-500/20' : 'bg-blue-500/20'
            }`}>
              {msg.role === 'user' ? <User size={16} className="text-emerald-400" /> : <Bot size={16} className="text-blue-400" />}
            </div>
            <div className={`max-w-[80%] rounded-2xl p-4 text-sm leading-relaxed ${
              msg.role === 'user'
                ? 'bg-emerald-600/20 text-gray-200 rounded-tr-sm'
                : 'bg-[#0d1224] border border-[#1a2340] text-gray-300 rounded-tl-sm'
            }`}>
              {msg.content.split('\n').map((line, li) => (
                <p key={li} className={li > 0 ? 'mt-1' : ''}>
                  {line.split('**').map((part, pi) =>
                    pi % 2 === 1 ? <strong key={pi} className="text-white">{part}</strong> : part
                  )}
                </p>
              ))}
              <p className="text-[10px] text-gray-600 mt-2">
                {msg.timestamp.toLocaleTimeString('ar-EG', { hour: '2-digit', minute: '2-digit' })}
              </p>
            </div>
          </motion.div>
        ))}
        {processing && (
          <div className="flex gap-3">
            <div className="w-8 h-8 rounded-full bg-blue-500/20 flex items-center justify-center">
              <Bot size={16} className="text-blue-400" />
            </div>
            <div className="bg-[#0d1224] border border-[#1a2340] rounded-2xl rounded-tl-sm p-4">
              <Loader2 size={18} className="text-blue-400 animate-spin" />
            </div>
          </div>
        )}
        <div ref={chatEndRef} />
      </div>

      {/* Input */}
      <div className="flex gap-3">
        <input
          type="text"
          value={input}
          onChange={e => setInput(e.target.value)}
          onKeyDown={e => e.key === 'Enter' && handleSend()}
          placeholder="اكتب رسالتك هنا..."
          className="flex-1 bg-[#0d1224] border border-[#1a2340] rounded-xl px-5 py-3 text-sm text-gray-200 placeholder-gray-600 focus:border-emerald-500/50 focus:outline-none"
        />
        <button
          onClick={handleSend}
          disabled={!input.trim() || processing}
          className="px-5 py-3 bg-emerald-600 hover:bg-emerald-700 disabled:opacity-50 rounded-xl text-white transition-colors"
        >
          <Send size={18} />
        </button>
      </div>
    </div>
  );
}
