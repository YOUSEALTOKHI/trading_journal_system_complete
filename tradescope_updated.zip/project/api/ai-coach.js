import supabase from './_supabase.js';

const SYSTEM_PROMPT = `أنت مدرب تداول محترف ومحلل نفسي متخصص في أسواق الفوركس والذهب. مهمتك تقييم أداء المتداول اليومي بناءً على بياناته.

يجب أن يتضمن تحليلك الأقسام التالية بالضبط (استخدم هذه العناوين):

## نقاط القوة
- حدد ما أجاده المتداول اليوم

## نقاط الضعف
- حدد الأخطاء والمشاكل

## التحليل الزمني
- حلل العلاقة بين وقت دخول الصفقة ونسب النجاح
- هل صفقات نهاية اليوم أو بداية الشهر تخسر دائماً؟
- حدد الأوقات المثلى للتداول

## تحليل الالتزام
- قارن بين ما ذكره المستخدم في الـ Debrief وبين خطة العمل الأساسية
- حدد أي انحراف عن الخطة (Deviation)
- قيم مدى الالتزام بالمبادئ العشرة

## الرؤية الثاقبة
- لا تكتفِ بسرد النتائج، بل ابحث عن الأسباب الجوهرية
- هل الخسارة بسبب التعب (نهاية اليوم)؟ أم بسبب تقلبات السوق (بداية الشهر)؟
- حلل العلاقة بين الحالة النفسية والنتائج

## تقييم الصفقات المفتوحة
- عند تقييم اليوم، ضع في اعتبارك الصفقات المفتوحة (Short-term/Swing)
- لا تحكم عليها كخسارة إلا بعد إغلاقها
- لكن قيم سلوك المتداول أثناء انتظارها

## التوصيات
- قدم توصيات محددة وعملية للتحسين
- ركز على الجانب النفسي والسلوكي

## التقييم العام
- أعطِ تقييماً من 1 إلى 10
- اذكر المبادئ التي لم يلتزم بها المتداول

كن صريحاً ومباشراً. لا تجامل. هدفك مساعدة المتداول على التحسن الحقيقي.`;

export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');
  if (req.method === 'OPTIONS') return res.status(204).end();

  try {
    if (req.method === 'GET') {
      const { date, limit: lim } = req.query;
      let query = supabase.from('ai_coach_feedback').select('*').order('feedback_date', { ascending: false });
      if (date) query = query.eq('feedback_date', date);
      const { data, error } = await query.limit(parseInt(lim) || 30);
      if (error) throw error;
      return res.status(200).json(data);
    }

    if (req.method === 'POST') {
      const { date, action_plan, plan_adherence } = req.body;
      if (!date) return res.status(400).json({ error: 'date is required' });

      // Gather trades for the date
      const { data: trades } = await supabase.from('trades').select('*').eq('trade_date', date).order('open_time', { ascending: true });

      // Gather debriefing for the date
      const { data: debriefings } = await supabase.from('daily_debriefings').select('*').eq('debrief_date', date);
      const debrief = debriefings && debriefings.length > 0 ? debriefings[0] : null;

      // Check for previous day's feedback for context
      const prevDate = new Date(new Date(date).getTime() - 86400000).toISOString().split('T')[0];
      const { data: prevFeedback } = await supabase.from('ai_coach_feedback').select('recommendations,principles_deficient').eq('feedback_date', prevDate).limit(1);

      // Build the user message
      let userMessage = `## بيانات يوم ${date}\n\n`;

      if (trades && trades.length > 0) {
        userMessage += `### الصفقات (${trades.length} صفقة):\n`;
        trades.forEach((t, i) => {
          userMessage += `${i+1}. ${t.symbol} | ${t.trade_type === 'buy' ? 'شراء' : 'بيع'} | ${t.lot_size} lot | دخول: ${t.open_price} | خروج: ${t.close_price} | الربح: $${t.profit} | الوقت: ${t.open_time} - ${t.close_time} | التصنيف: ${t.trade_classification || 'غير محدد'} | الحالة النفسية: ${t.psychological_state || 'غير محدد'} | سبب الدخول: ${t.entry_reason || 'غير محدد'} | الأفكار: ${t.thoughts_at_entry || 'لا يوجد'} | ملاحظات: ${t.trading_notes || 'لا يوجد'}\n`;
        });
        const totalProfit = trades.reduce((s, t) => s + (t.profit || 0), 0);
        const wins = trades.filter(t => t.profit > 0).length;
        userMessage += `\nالإجمالي: ربح $${totalProfit.toFixed(2)} | نسبة الفوز: ${(wins/trades.length*100).toFixed(1)}%\n`;
      } else {
        userMessage += `لا توجد صفقات مسجلة لهذا اليوم.\n`;
      }

      if (debrief) {
        userMessage += `\n### الديلي دبريفنج:\n`;
        userMessage += `- تحليل الأخطاء: ${debrief.error_analysis || 'لم يُملأ'}\n`;
        userMessage += `- الأسباب الجذرية: ${debrief.root_causes || 'لم يُملأ'}\n`;
        userMessage += `- خطة التحسين: ${debrief.improvements || 'لم يُملأ'}\n`;
        userMessage += `- التقييم الذاتي: ${debrief.overall_score || 'لم يُملأ'}/10\n`;
        userMessage += `- ملاحظات: ${debrief.notes || 'لا يوجد'}\n`;
        try {
          const principles = JSON.parse(debrief.ten_principles || '[]');
          if (Array.isArray(principles) && principles.length === 10) {
            const violated = principles.map((p, i) => !p.checked ? `المبدأ ${i+1}${p.why ? ': ' + p.why : ''}` : null).filter(Boolean);
            userMessage += `- المبادئ المنتهكة: ${violated.length > 0 ? violated.join(', ') : 'لا يوجد'}\n`;
          }
        } catch {}
      }

      if (action_plan) {
        userMessage += `\n### خطة العمل المحددة مسبقاً:\n${action_plan}\n`;
      }
      if (plan_adherence) {
        userMessage += `\n### تقييم المتداول لالتزامه بالخطة:\n${plan_adherence}\n`;
      }

      if (prevFeedback && prevFeedback.length > 0) {
        userMessage += `\n### توصيات اليوم السابق:\n${prevFeedback[0].recommendations || 'لا يوجد'}\n`;
        if (prevFeedback[0].principles_deficient) {
          userMessage += `المبادئ الناقصة بالأمس: ${prevFeedback[0].principles_deficient}\n`;
        }
      }

      // Call AI (simulated analysis since we don't have API keys)
      // Build a comprehensive analysis based on the data
      const analysis = generateAnalysis(trades || [], debrief, action_plan, plan_adherence, prevFeedback?.[0]);

      // Store feedback
      const feedbackData = {
        feedback_date: date,
        trades_summary: trades ? `${trades.length} صفقات، ربح إجمالي: $${trades.reduce((s,t) => s + (t.profit||0), 0).toFixed(2)}` : 'لا توجد صفقات',
        debrief_summary: debrief ? `تقييم ذاتي: ${debrief.overall_score}/10` : 'لم يتم تعبئة الدبريفنج',
        action_plan: action_plan || null,
        action_plan_adherence: plan_adherence || null,
        strengths: analysis.strengths,
        weaknesses: analysis.weaknesses,
        recommendations: analysis.recommendations,
        time_analysis: analysis.timeAnalysis,
        consistency_check: analysis.consistencyCheck,
        deep_insights: analysis.deepInsights,
        open_trades_assessment: analysis.openTradesAssessment,
        overall_ai_score: analysis.score,
        ai_model_used: 'built-in-analyzer',
        raw_response: JSON.stringify(analysis),
        principles_deficient: analysis.principlesDeficient,
        auto_alert_triggered: analysis.alertTriggered,
      };

      const { data: saved, error } = await supabase.from('ai_coach_feedback').insert(feedbackData).select().single();
      if (error) throw error;

      return res.status(201).json(saved);
    }

    res.status(405).json({ error: 'Method not allowed' });
  } catch (err) {
    console.error('AI Coach error:', err);
    res.status(500).json({ error: err.message });
  }
}

function generateAnalysis(trades, debrief, actionPlan, planAdherence, prevFeedback) {
  const totalTrades = trades.length;
  const wins = trades.filter(t => t.profit > 0);
  const losses = trades.filter(t => t.profit < 0);
  const totalProfit = trades.reduce((s, t) => s + (t.profit || 0), 0);
  const winRate = totalTrades > 0 ? (wins.length / totalTrades * 100) : 0;

  // Time analysis
  const hourBuckets = {};
  trades.forEach(t => {
    const hour = t.open_time ? parseInt(t.open_time.split(' ')[1]?.split(':')[0] || '0') : 0;
    const bucket = hour < 10 ? 'صباحاً (قبل 10)' : hour < 14 ? 'ظهراً (10-14)' : hour < 18 ? 'عصراً (14-18)' : 'مساءً (بعد 18)';
    if (!hourBuckets[bucket]) hourBuckets[bucket] = { trades: 0, profit: 0, wins: 0 };
    hourBuckets[bucket].trades++;
    hourBuckets[bucket].profit += (t.profit || 0);
    if (t.profit > 0) hourBuckets[bucket].wins++;
  });

  let timeAnalysis = '';
  if (totalTrades > 0) {
    timeAnalysis = Object.entries(hourBuckets).map(([period, data]) => {
      const wr = data.trades > 0 ? (data.wins / data.trades * 100).toFixed(0) : 0;
      return `• ${period}: ${data.trades} صفقات، ربح $${data.profit.toFixed(2)}، نسبة فوز ${wr}%`;
    }).join('\n');
    const bestPeriod = Object.entries(hourBuckets).sort((a, b) => b[1].profit - a[1].profit)[0];
    const worstPeriod = Object.entries(hourBuckets).sort((a, b) => a[1].profit - b[1].profit)[0];
    if (bestPeriod) timeAnalysis += `\n\n✅ أفضل فترة: ${bestPeriod[0]}`;
    if (worstPeriod && worstPeriod[1].profit < 0) timeAnalysis += `\n❌ أسوأ فترة: ${worstPeriod[0]}`;
  } else {
    timeAnalysis = 'لا توجد صفقات لتحليلها زمنياً.';
  }

  // Psychological analysis
  const psyStates = {};
  trades.forEach(t => {
    const state = t.psychological_state || 'غير محدد';
    if (!psyStates[state]) psyStates[state] = { trades: 0, profit: 0, wins: 0 };
    psyStates[state].trades++;
    psyStates[state].profit += (t.profit || 0);
    if (t.profit > 0) psyStates[state].wins++;
  });

  // Strengths
  let strengths = '';
  if (winRate >= 60) strengths += '• نسبة فوز جيدة (' + winRate.toFixed(0) + '%)\n';
  if (totalProfit > 0) strengths += '• يوم مربح بإجمالي $' + totalProfit.toFixed(2) + '\n';
  if (debrief && debrief.overall_score >= 7) strengths += '• وعي ذاتي جيد (تقييم ' + debrief.overall_score + '/10)\n';
  if (debrief && debrief.error_analysis) strengths += '• قام بتحليل أخطائه\n';
  const disciplinedTrades = trades.filter(t => t.psychological_state === 'منضبط' || t.psychological_state === 'هادئ ومركز');
  if (disciplinedTrades.length > totalTrades * 0.5) strengths += '• أغلب الصفقات تمت بحالة نفسية جيدة\n';
  if (trades.every(t => t.stop_loss)) strengths += '• التزام بوضع وقف الخسارة في جميع الصفقات\n';
  if (!strengths) strengths = '• قم بتسجيل المزيد من البيانات لتحليل نقاط القوة';

  // Weaknesses
  let weaknesses = '';
  if (winRate < 50 && totalTrades > 0) weaknesses += '• نسبة فوز منخفضة (' + winRate.toFixed(0) + '%)\n';
  if (totalProfit < 0) weaknesses += '• يوم خاسر بإجمالي $' + totalProfit.toFixed(2) + '\n';
  const impulsiveTrades = trades.filter(t => t.psychological_state === 'مندفع' || t.psychological_state === 'طمّاع');
  if (impulsiveTrades.length > 0) weaknesses += '• ' + impulsiveTrades.length + ' صفقات بحالة نفسية سلبية (اندفاع/طمع)\n';
  const revengeTrades = trades.filter(t => t.trading_notes?.includes('انتقام'));
  if (revengeTrades.length > 0) weaknesses += '• تداول انتقامي مُكتشف!\n';
  if (!debrief) weaknesses += '• لم يتم تعبئة الديلي دبريفنج\n';
  const noSLTrades = trades.filter(t => !t.stop_loss);
  if (noSLTrades.length > 0) weaknesses += '• ' + noSLTrades.length + ' صفقات بدون وقف خسارة\n';
  if (!weaknesses) weaknesses = '• أداء جيد بدون نقاط ضعف واضحة';

  // Consistency check
  let consistencyCheck = '';
  if (actionPlan && planAdherence) {
    consistencyCheck = `خطة العمل: ${actionPlan}\n\nتقييم الالتزام: ${planAdherence}`;
  } else if (actionPlan) {
    consistencyCheck = `خطة العمل موجودة لكن لم يتم تقييم الالتزام بها.\nالخطة: ${actionPlan}`;
  } else {
    consistencyCheck = 'لا توجد خطة عمل محددة لهذا اليوم. يُنصح بوضع خطة واضحة قبل بدء التداول.';
  }

  if (prevFeedback?.recommendations) {
    consistencyCheck += `\n\n📋 توصيات الأمس: ${prevFeedback.recommendations}`;
  }

  // Deep insights
  let deepInsights = '';
  if (totalTrades > 0) {
    // Correlation between psychology and results
    Object.entries(psyStates).forEach(([state, data]) => {
      const wr = data.trades > 0 ? (data.wins / data.trades * 100).toFixed(0) : 0;
      deepInsights += `• عند حالة "${state}": ${data.trades} صفقات، نسبة فوز ${wr}%، ربح $${data.profit.toFixed(2)}\n`;
    });

    // Classification analysis
    const classifications = {};
    trades.forEach(t => {
      const cls = t.trade_classification || 'غير محدد';
      if (!classifications[cls]) classifications[cls] = { count: 0, profit: 0 };
      classifications[cls].count++;
      classifications[cls].profit += (t.profit || 0);
    });
    deepInsights += '\nتحليل حسب التصنيف:\n';
    Object.entries(classifications).forEach(([cls, data]) => {
      deepInsights += `• ${cls}: ${data.count} صفقات، ربح $${data.profit.toFixed(2)}\n`;
    });
  } else {
    deepInsights = 'لا توجد بيانات كافية للتحليل العميق.';
  }

  // Open trades assessment
  const openTrades = trades.filter(t => t.trade_classification === 'swing' || t.trade_classification === 'short-term');
  let openTradesAssessment = '';
  if (openTrades.length > 0) {
    openTradesAssessment = `يوجد ${openTrades.length} صفقات قد تكون مفتوحة (swing/short-term). لا يتم الحكم عليها كخسارة حتى الإغلاق، لكن يجب مراقبة سلوك المتداول أثناء الانتظار.`;
  } else {
    openTradesAssessment = 'جميع الصفقات يومية أو خاطفة - تم إغلاقها في نفس اليوم.';
  }

  // Recommendations
  let recommendations = '';
  if (impulsiveTrades.length > 0) recommendations += '• خذ استراحة 30 دقيقة بعد كل خسارة قبل الدخول في صفقة جديدة\n';
  if (winRate < 50 && totalTrades > 0) recommendations += '• ركز على جودة الإشارات وليس كمية الصفقات\n';
  if (!debrief) recommendations += '• احرص على تعبئة الديلي دبريفنج يومياً - هذا أساس التطور\n';
  if (noSLTrades.length > 0) recommendations += '• لا تدخل أي صفقة بدون وقف خسارة محدد مسبقاً\n';
  if (revengeTrades.length > 0) recommendations += '• ⚠️ التداول الانتقامي هو أخطر عدو - توقف فوراً عند الشعور بالرغبة في التعويض\n';
  recommendations += '• راجع خطة التداول قبل بدء كل جلسة\n';
  recommendations += '• حدد أهدافاً واقعية لكل يوم والتزم بها\n';

  // Score
  let score = 5;
  if (totalProfit > 0) score += 1;
  if (winRate >= 60) score += 1;
  if (debrief && debrief.overall_score >= 7) score += 1;
  if (impulsiveTrades.length === 0 && totalTrades > 0) score += 1;
  if (noSLTrades.length === 0 && totalTrades > 0) score += 1;
  if (totalProfit < 0) score -= 1;
  if (revengeTrades.length > 0) score -= 2;
  if (!debrief) score -= 1;
  score = Math.max(1, Math.min(10, score));

  // Principles deficient
  let principlesDeficient = '';
  if (debrief?.ten_principles) {
    try {
      const p = JSON.parse(debrief.ten_principles);
      const deficient = p.map((pr, i) => !pr.checked ? (i + 1) : null).filter(Boolean);
      if (deficient.length > 0) principlesDeficient = `المبادئ: ${deficient.join(', ')}`;
    } catch {}
  }

  const alertTriggered = principlesDeficient.length > 0 || score <= 4;

  return {
    strengths,
    weaknesses,
    recommendations,
    timeAnalysis,
    consistencyCheck,
    deepInsights,
    openTradesAssessment,
    score,
    principlesDeficient,
    alertTriggered,
  };
}
