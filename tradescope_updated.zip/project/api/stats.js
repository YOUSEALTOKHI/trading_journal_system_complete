import supabase from './_supabase.js';

export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
  if (req.method === 'OPTIONS') return res.status(204).end();

  try {
    const { period, date, week_start, month } = req.query;

    let query = supabase.from('trades').select('*');
    if (period === 'daily' && date) {
      query = query.eq('trade_date', date);
    } else if (period === 'weekly' && week_start) {
      const weekEnd = new Date(new Date(week_start).getTime() + 6 * 86400000).toISOString().split('T')[0];
      query = query.gte('trade_date', week_start).lte('trade_date', weekEnd);
    } else if (period === 'monthly' && month) {
      query = query.like('trade_date', `${month}%`);
    }

    const { data: trades, error } = await query.order('open_time', { ascending: true });
    if (error) throw error;

    const totalTrades = trades.length;
    const wins = trades.filter(t => t.profit > 0);
    const losses = trades.filter(t => t.profit < 0);
    const breakeven = trades.filter(t => t.profit === 0);
    const totalProfit = trades.reduce((s, t) => s + (t.profit || 0), 0);
    const totalWinAmount = wins.reduce((s, t) => s + t.profit, 0);
    const totalLossAmount = Math.abs(losses.reduce((s, t) => s + t.profit, 0));
    const winRate = totalTrades > 0 ? (wins.length / totalTrades * 100) : 0;
    const avgWin = wins.length > 0 ? totalWinAmount / wins.length : 0;
    const avgLoss = losses.length > 0 ? totalLossAmount / losses.length : 0;
    const profitFactor = totalLossAmount > 0 ? totalWinAmount / totalLossAmount : totalWinAmount > 0 ? Infinity : 0;
    const riskRewardRatio = avgLoss > 0 ? avgWin / avgLoss : 0;

    // Equity curve
    let runningBalance = trades.length > 0 ? (trades[0].balance_after - trades[0].profit) : 10000;
    const equityCurve = trades.map(t => {
      runningBalance += (t.profit || 0);
      return { date: t.trade_date, balance: runningBalance, profit: t.profit };
    });

    // By symbol
    const bySymbol = {};
    trades.forEach(t => {
      if (!bySymbol[t.symbol]) bySymbol[t.symbol] = { trades: 0, profit: 0, wins: 0 };
      bySymbol[t.symbol].trades++;
      bySymbol[t.symbol].profit += (t.profit || 0);
      if (t.profit > 0) bySymbol[t.symbol].wins++;
    });

    // By day of week
    const byDay = {};
    trades.forEach(t => {
      const day = new Date(t.trade_date).toLocaleDateString('en-US', { weekday: 'long' });
      if (!byDay[day]) byDay[day] = { trades: 0, profit: 0, wins: 0 };
      byDay[day].trades++;
      byDay[day].profit += (t.profit || 0);
      if (t.profit > 0) byDay[day].wins++;
    });

    // Max drawdown
    let peak = 0;
    let maxDrawdown = 0;
    let runBal = 0;
    trades.forEach(t => {
      runBal += (t.profit || 0);
      if (runBal > peak) peak = runBal;
      const dd = peak - runBal;
      if (dd > maxDrawdown) maxDrawdown = dd;
    });

    // Consecutive wins/losses
    let maxConsWins = 0, maxConsLosses = 0, consWins = 0, consLosses = 0;
    trades.forEach(t => {
      if (t.profit > 0) { consWins++; consLosses = 0; }
      else if (t.profit < 0) { consLosses++; consWins = 0; }
      else { consWins = 0; consLosses = 0; }
      if (consWins > maxConsWins) maxConsWins = consWins;
      if (consLosses > maxConsLosses) maxConsLosses = consLosses;
    });

    return res.status(200).json({
      totalTrades,
      wins: wins.length,
      losses: losses.length,
      breakeven: breakeven.length,
      totalProfit: Math.round(totalProfit * 100) / 100,
      winRate: Math.round(winRate * 100) / 100,
      avgWin: Math.round(avgWin * 100) / 100,
      avgLoss: Math.round(avgLoss * 100) / 100,
      profitFactor: profitFactor === Infinity ? 999 : Math.round(profitFactor * 100) / 100,
      riskRewardRatio: Math.round(riskRewardRatio * 100) / 100,
      maxDrawdown: Math.round(maxDrawdown * 100) / 100,
      maxConsecutiveWins: maxConsWins,
      maxConsecutiveLosses: maxConsLosses,
      equityCurve,
      bySymbol,
      byDay,
      largestWin: wins.length > 0 ? Math.max(...wins.map(t => t.profit)) : 0,
      largestLoss: losses.length > 0 ? Math.min(...losses.map(t => t.profit)) : 0,
      // Trade-level drawdown stats
      avgTradeDrawdown: (() => {
        const withDD = trades.filter(t => t.trade_drawdown != null && t.trade_drawdown > 0);
        return withDD.length > 0 ? Math.round(withDD.reduce((s, t) => s + t.trade_drawdown, 0) / withDD.length * 100) / 100 : 0;
      })(),
      maxTradeDrawdown: (() => {
        const withDD = trades.filter(t => t.trade_drawdown != null && t.trade_drawdown > 0);
        return withDD.length > 0 ? Math.round(Math.max(...withDD.map(t => t.trade_drawdown)) * 100) / 100 : 0;
      })(),
      tradesWithDrawdown: trades.filter(t => t.trade_drawdown != null && t.trade_drawdown > 0).length,
    });
  } catch (err) {
    console.error('API error:', err);
    res.status(500).json({ error: err.message });
  }
}
