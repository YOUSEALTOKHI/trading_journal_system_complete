import supabase from './_supabase.js';

// Parse MT4/MT5 statement data from various formats
function parseStatement(rawData, format) {
  const trades = [];
  
  if (format === 'csv' || format === 'tsv') {
    const separator = format === 'tsv' ? '\t' : ',';
    const lines = rawData.trim().split('\n');
    if (lines.length < 2) return trades;
    
    // Parse header to find column indices
    const header = lines[0].split(separator).map(h => h.trim().toLowerCase().replace(/["']/g, ''));
    
    // Map common MT4/MT5 column names
    const colMap = {};
    header.forEach((h, i) => {
      if (h.includes('ticket') || h.includes('order') || h === '#') colMap.ticket = i;
      if (h.includes('open time') || h.includes('open date') || h === 'time') colMap.open_time = i;
      if (h.includes('close time') || h.includes('close date')) colMap.close_time = i;
      if (h.includes('type') || h.includes('direction')) colMap.trade_type = i;
      if (h.includes('lot') || h.includes('volume') || h.includes('size')) colMap.lot_size = i;
      if (h.includes('symbol') || h.includes('pair') || h.includes('item')) colMap.symbol = i;
      if (h.includes('open price') || h === 'price') colMap.open_price = i;
      if (h.includes('close price') || h.includes('price.1')) colMap.close_price = i;
      if (h.includes('s/l') || h.includes('stop loss') || h.includes('sl')) colMap.stop_loss = i;
      if (h.includes('t/p') || h.includes('take profit') || h.includes('tp')) colMap.take_profit = i;
      if (h.includes('profit') || h.includes('p/l') || h.includes('pnl')) colMap.profit = i;
      if (h.includes('balance')) colMap.balance_after = i;
      if (h.includes('swap')) colMap.swap = i;
      if (h.includes('commission')) colMap.commission = i;
    });
    
    for (let i = 1; i < lines.length; i++) {
      const cols = lines[i].split(separator).map(c => c.trim().replace(/["']/g, ''));
      if (cols.length < 3) continue;
      
      // Skip non-trade rows (balance, credit, etc.)
      const typeVal = cols[colMap.trade_type]?.toLowerCase() || '';
      if (!typeVal.includes('buy') && !typeVal.includes('sell') && typeVal !== '0' && typeVal !== '1') continue;
      
      const trade_type = (typeVal.includes('sell') || typeVal === '1') ? 'sell' : 'buy';
      const openTime = cols[colMap.open_time] || '';
      
      trades.push({
        ticket: cols[colMap.ticket] || String(Date.now() + i),
        open_time: openTime,
        close_time: cols[colMap.close_time] || openTime,
        trade_type,
        lot_size: parseFloat(cols[colMap.lot_size]) || 0.01,
        symbol: (cols[colMap.symbol] || 'UNKNOWN').replace(/[^A-Za-z0-9]/g, ''),
        open_price: parseFloat(cols[colMap.open_price]) || 0,
        close_price: parseFloat(cols[colMap.close_price]) || 0,
        stop_loss: parseFloat(cols[colMap.stop_loss]) || null,
        take_profit: parseFloat(cols[colMap.take_profit]) || null,
        profit: parseFloat(cols[colMap.profit]) || 0,
        balance_after: parseFloat(cols[colMap.balance_after]) || 0,
        trade_date: openTime ? openTime.split(' ')[0].split('T')[0] : new Date().toISOString().split('T')[0],
        trade_classification: 'intraday',
      });
    }
  } else if (format === 'json') {
    const arr = JSON.parse(rawData);
    const items = Array.isArray(arr) ? arr : (arr.trades || arr.data || [arr]);
    items.forEach((item, i) => {
      const t = item;
      trades.push({
        ticket: t.ticket || t.order || t['#'] || String(Date.now() + i),
        open_time: t.open_time || t.openTime || t.time || '',
        close_time: t.close_time || t.closeTime || '',
        trade_type: (t.type || t.trade_type || t.direction || 'buy').toLowerCase().includes('sell') ? 'sell' : 'buy',
        lot_size: parseFloat(t.lot_size || t.lots || t.volume || t.size) || 0.01,
        symbol: t.symbol || t.pair || t.item || 'UNKNOWN',
        open_price: parseFloat(t.open_price || t.openPrice || t.price) || 0,
        close_price: parseFloat(t.close_price || t.closePrice) || 0,
        stop_loss: parseFloat(t.stop_loss || t.sl) || null,
        take_profit: parseFloat(t.take_profit || t.tp) || null,
        profit: parseFloat(t.profit || t.pnl) || 0,
        balance_after: parseFloat(t.balance || t.balance_after) || 0,
        trade_date: (t.open_time || t.openTime || t.time || '').split(' ')[0].split('T')[0] || new Date().toISOString().split('T')[0],
        trade_classification: 'intraday',
      });
    });
  }
  
  return trades;
}

// Convert trades to Google Sheets format
function tradesToSheetRows(trades) {
  const headers = [
    'Ticket', 'Open Time', 'Close Time', 'Type', 'Lots', 'Symbol',
    'Open Price', 'Close Price', 'S/L', 'T/P', 'Profit', 'Balance',
    'Date', 'Classification', 'Entry Reason', 'Psychological State',
    'Thoughts', 'Notes', 'Trade Drawdown'
  ];
  const rows = trades.map(t => [
    t.ticket, t.open_time, t.close_time, t.trade_type, t.lot_size, t.symbol,
    t.open_price, t.close_price, t.stop_loss || '', t.take_profit || '',
    t.profit, t.balance_after, t.trade_date, t.trade_classification || 'intraday',
    t.entry_reason || '', t.psychological_state || '',
    t.thoughts_at_entry || '', t.trading_notes || '', t.trade_drawdown || ''
  ]);
  return { headers, rows };
}

export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');
  if (req.method === 'OPTIONS') return res.status(204).end();

  try {
    if (req.method === 'POST') {
      const { raw_data, format, google_sheet_url, action } = req.body;
      
      // Action: parse statement and import
      if (action === 'import') {
        if (!raw_data) return res.status(400).json({ error: 'raw_data is required' });
        
        const detectedFormat = format || (raw_data.trim().startsWith('{') || raw_data.trim().startsWith('[') ? 'json' : raw_data.includes('\t') ? 'tsv' : 'csv');
        const trades = parseStatement(raw_data, detectedFormat);
        
        if (trades.length === 0) {
          return res.status(400).json({ error: 'No trades found in the data. Check the format.' });
        }
        
        // Save to database
        const { data: saved, error } = await supabase.from('trades').insert(trades).select();
        if (error) throw error;
        
        // Generate sheet data
        const sheetData = tradesToSheetRows(saved);
        
        return res.status(201).json({
          imported: saved.length,
          trades: saved,
          sheet_data: sheetData,
          missing_columns: [
            'Entry Reason - \u0633\u0628\u0628 \u0627\u0644\u062f\u062e\u0648\u0644',
            'Psychological State - \u0627\u0644\u062d\u0627\u0644\u0629 \u0627\u0644\u0646\u0641\u0633\u064a\u0629',
            'Thoughts at Entry - \u0627\u0644\u0623\u0641\u0643\u0627\u0631 \u0639\u0646\u062f \u0627\u0644\u062f\u062e\u0648\u0644',
            'Trading Notes - \u0645\u0644\u0627\u062d\u0638\u0627\u062a',
            'Trade Drawdown - \u062f\u0631\u0648\u0627 \u062f\u0627\u0648\u0646 \u0627\u0644\u0635\u0641\u0642\u0629',
            'Trade Classification - \u062a\u0635\u0646\u064a\u0641 \u0627\u0644\u0635\u0641\u0642\u0629',
          ],
        });
      }
      
      // Action: export to sheet format
      if (action === 'export') {
        const { date } = req.body;
        let query = supabase.from('trades').select('*').order('open_time', { ascending: true });
        if (date) query = query.eq('trade_date', date);
        const { data: trades, error } = await query.limit(500);
        if (error) throw error;
        
        const sheetData = tradesToSheetRows(trades || []);
        return res.status(200).json({ trades: trades?.length || 0, sheet_data: sheetData });
      }
      
      // Action: import from Google Sheet URL (public sheet)
      if (action === 'import_sheet') {
        if (!google_sheet_url) return res.status(400).json({ error: 'google_sheet_url is required' });
        
        // Extract sheet ID and convert to CSV export URL
        let sheetId = '';
        const match = google_sheet_url.match(/\/d\/([a-zA-Z0-9-_]+)/);
        if (match) sheetId = match[1];
        else return res.status(400).json({ error: 'Invalid Google Sheets URL' });
        
        const csvUrl = `https://docs.google.com/spreadsheets/d/${sheetId}/export?format=csv`;
        
        try {
          const response = await fetch(csvUrl);
          if (!response.ok) throw new Error('Cannot access sheet. Make sure it is shared publicly.');
          const csvText = await response.text();
          
          const trades = parseStatement(csvText, 'csv');
          if (trades.length === 0) {
            return res.status(400).json({ error: 'No trades found in the sheet' });
          }
          
          const { data: saved, error } = await supabase.from('trades').insert(trades).select();
          if (error) throw error;
          
          return res.status(201).json({
            imported: saved.length,
            trades: saved,
            source: 'google_sheets',
          });
        } catch (fetchErr) {
          return res.status(400).json({ error: `Failed to fetch sheet: ${fetchErr.message}` });
        }
      }
      
      return res.status(400).json({ error: 'Invalid action. Use: import, export, or import_sheet' });
    }
    
    // GET: Return export template
    if (req.method === 'GET') {
      return res.status(200).json({
        template_headers: [
          'Ticket', 'Open Time', 'Close Time', 'Type', 'Lots', 'Symbol',
          'Open Price', 'Close Price', 'S/L', 'T/P', 'Profit', 'Balance'
        ],
        additional_columns: [
          'Date', 'Classification', 'Entry Reason', 'Psychological State',
          'Thoughts', 'Notes', 'Trade Drawdown'
        ],
        supported_formats: ['csv', 'tsv', 'json'],
        google_sheets_instructions: {
          step1: 'Create a Google Sheet with the template headers above',
          step2: 'Paste your MT4/MT5 statement data',
          step3: 'Share the sheet (Anyone with the link can view)',
          step4: 'Paste the sheet URL in the import form',
        }
      });
    }
    
    res.status(405).json({ error: 'Method not allowed' });
  } catch (err) {
    console.error('Import API error:', err);
    res.status(500).json({ error: err.message });
  }
}
