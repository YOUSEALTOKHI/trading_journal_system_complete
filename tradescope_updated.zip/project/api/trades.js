import supabase from './_supabase.js';

export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
  if (req.method === 'OPTIONS') return res.status(204).end();

  try {
    if (req.method === 'GET') {
      const { date, week_start, month, symbol } = req.query;
      let query = supabase.from('trades').select('*').order('open_time', { ascending: false });
      if (date) query = query.eq('trade_date', date);
      if (week_start) query = query.gte('trade_date', week_start);
      if (month) query = query.like('trade_date', `${month}%`);
      if (symbol) query = query.eq('symbol', symbol);
      const { data, error } = await query.limit(500);
      if (error) throw error;
      return res.status(200).json(data);
    }
    if (req.method === 'POST') {
      const trades = Array.isArray(req.body) ? req.body : [req.body];
      const { data, error } = await supabase.from('trades').insert(trades).select();
      if (error) throw error;
      return res.status(201).json(data);
    }
    if (req.method === 'PUT') {
      const { id, ...updates } = req.body;
      if (!id) return res.status(400).json({ error: 'id is required' });
      const { data, error } = await supabase.from('trades').update(updates).eq('id', id).select().single();
      if (error) throw error;
      return res.status(200).json(data);
    }
    if (req.method === 'DELETE') {
      const { id } = req.body;
      if (!id) return res.status(400).json({ error: 'id is required' });
      const { error } = await supabase.from('trades').delete().eq('id', id);
      if (error) throw error;
      return res.status(200).json({ ok: true });
    }
    res.status(405).json({ error: 'Method not allowed' });
  } catch (err) {
    console.error('API error:', err);
    res.status(500).json({ error: err.message });
  }
}
