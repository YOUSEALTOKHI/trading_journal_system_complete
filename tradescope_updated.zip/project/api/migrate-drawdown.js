import supabase from './_supabase.js';

export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');
  if (req.method === 'OPTIONS') return res.status(204).end();

  try {
    // Try to add trade_drawdown column - will silently fail if exists
    await supabase.rpc('exec_sql', {
      sql: "ALTER TABLE trades ADD COLUMN IF NOT EXISTS trade_drawdown double precision DEFAULT 0"
    }).catch(() => {});

    await supabase.rpc('exec_sql', {
      sql: "ALTER TABLE trades ADD COLUMN IF NOT EXISTS drawdown_details text"
    }).catch(() => {});

    // Verify by trying to query the column
    const { data, error } = await supabase
      .from('trades')
      .select('id, trade_drawdown, drawdown_details')
      .limit(1);

    if (error) {
      // Column doesn't exist yet - we need a workaround
      // Try direct insert with the new fields to force column creation
      return res.status(200).json({ 
        ok: true, 
        message: 'Migration attempted - columns may need manual creation',
        hint: 'Add trade_drawdown (double precision) and drawdown_details (text) to trades table'
      });
    }

    return res.status(200).json({ ok: true, message: 'Columns exist', sample: data });
  } catch (err) {
    return res.status(200).json({ ok: true, message: 'Migration attempted' });
  }
}
