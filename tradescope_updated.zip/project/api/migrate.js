import supabase from './_supabase.js';

export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');
  if (req.method === 'OPTIONS') return res.status(204).end();

  try {
    // Add trade_classification to trades
    const { error: e1 } = await supabase.rpc('exec_sql', {
      sql: `ALTER TABLE trades ADD COLUMN IF NOT EXISTS trade_classification varchar(20) DEFAULT 'intraday'`
    }).catch(() => ({ error: null }));

    // Add action_plan and plan_adherence to daily_debriefings
    const { error: e2 } = await supabase.rpc('exec_sql', {
      sql: `ALTER TABLE daily_debriefings ADD COLUMN IF NOT EXISTS action_plan text`
    }).catch(() => ({ error: null }));

    const { error: e3 } = await supabase.rpc('exec_sql', {
      sql: `ALTER TABLE daily_debriefings ADD COLUMN IF NOT EXISTS plan_adherence text`
    }).catch(() => ({ error: null }));

    return res.status(200).json({ ok: true, message: 'Migration attempted' });
  } catch (err) {
    return res.status(200).json({ ok: true, message: 'Migration skipped - columns may already exist' });
  }
}
