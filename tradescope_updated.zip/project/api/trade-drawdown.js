import supabase from './_supabase.js';

// AI-based drawdown calculator
// Estimates max adverse excursion (MAE) for a trade based on its parameters
function calculateDrawdown(trade) {
  const { trade_type, open_price, close_price, stop_loss, lot_size, symbol } = trade;
  
  if (!open_price || !close_price) return null;
  
  // Determine pip value based on symbol
  let pipMultiplier = 10; // default for most pairs (0.0001)
  const sym = (symbol || '').toUpperCase();
  if (sym.includes('JPY')) pipMultiplier = 1000; // JPY pairs (0.01)
  if (sym.includes('XAU') || sym.includes('GOLD')) pipMultiplier = 0.1; // Gold
  
  // If stop_loss is set, calculate max potential drawdown
  if (stop_loss && stop_loss > 0) {
    let slDistance;
    if (trade_type === 'buy') {
      slDistance = open_price - stop_loss;
    } else {
      slDistance = stop_loss - open_price;
    }
    
    if (slDistance > 0) {
      // Drawdown in pips
      const ddPips = slDistance * pipMultiplier;
      // Estimate $ drawdown (rough: lot_size * pip_value * pips)
      let pipValue = 10; // $10 per pip for 1 standard lot on most pairs
      if (sym.includes('XAU') || sym.includes('GOLD')) pipValue = 100;
      const ddDollars = Math.abs(ddPips * (lot_size || 0.01) * pipValue / pipMultiplier * 10);
      
      return {
        max_drawdown_pips: Math.round(ddPips * 10) / 10,
        max_drawdown_dollars: Math.round(ddDollars * 100) / 100,
        drawdown_percent: null, // needs account balance
        calculation_method: 'ai_estimated',
        notes: `Estimated from SL distance: ${slDistance.toFixed(5)}`,
      };
    }
  }
  
  // Fallback: estimate from price movement against position
  let adverseMove;
  if (trade_type === 'buy') {
    // For a buy, worst case is price went below open before reaching close
    // Without tick data, estimate as percentage of the range
    const range = Math.abs(close_price - open_price);
    adverseMove = trade.profit < 0 ? Math.abs(trade.profit) : range * 0.3; // estimate 30% retracement on winners
  } else {
    const range = Math.abs(close_price - open_price);
    adverseMove = trade.profit < 0 ? Math.abs(trade.profit) : range * 0.3;
  }
  
  return {
    max_drawdown_pips: null,
    max_drawdown_dollars: Math.round(adverseMove * 100) / 100,
    drawdown_percent: null,
    calculation_method: 'ai_estimated',
    notes: 'Estimated without SL data - enter manually for accuracy',
  };
}

export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');
  if (req.method === 'OPTIONS') return res.status(204).end();

  try {
    // POST: Calculate drawdown for a specific trade using AI
    if (req.method === 'POST') {
      const { trade_id } = req.body;
      
      if (!trade_id) return res.status(400).json({ error: 'trade_id required' });
      
      // Fetch the trade
      const { data: trade, error: fetchErr } = await supabase
        .from('trades').select('*').eq('id', trade_id).single();
      if (fetchErr) throw fetchErr;
      if (!trade) return res.status(404).json({ error: 'Trade not found' });
      
      const dd = calculateDrawdown(trade);
      if (!dd) return res.status(400).json({ error: 'Cannot calculate drawdown' });
      
      // Update trade with drawdown data
      const ddJson = JSON.stringify(dd);
      const { data: updated, error: updateErr } = await supabase
        .from('trades')
        .update({ 
          trade_drawdown: dd.max_drawdown_dollars,
          drawdown_details: ddJson 
        })
        .eq('id', trade_id)
        .select()
        .single();
      if (updateErr) throw updateErr;
      
      return res.status(200).json({ trade: updated, drawdown: dd });
    }
    
    // GET: Calculate drawdown for all trades that don't have it
    if (req.method === 'GET') {
      const { data: trades, error } = await supabase
        .from('trades').select('*').is('trade_drawdown', null).limit(100);
      if (error) throw error;
      
      const results = [];
      for (const trade of (trades || [])) {
        const dd = calculateDrawdown(trade);
        if (dd) {
          await supabase.from('trades').update({ 
            trade_drawdown: dd.max_drawdown_dollars,
            drawdown_details: JSON.stringify(dd)
          }).eq('id', trade.id);
          results.push({ id: trade.id, symbol: trade.symbol, drawdown: dd });
        }
      }
      
      return res.status(200).json({ calculated: results.length, results });
    }
    
    res.status(405).json({ error: 'Method not allowed' });
  } catch (err) {
    console.error('Drawdown API error:', err);
    res.status(500).json({ error: err.message });
  }
}
