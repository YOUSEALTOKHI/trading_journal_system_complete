import { useState, useEffect, useCallback } from 'react';
import { motion } from 'framer-motion';
import { CheckCircle, XCircle, Save, Calendar, Volume2, VolumeX, Brain, Loader2 } from 'lucide-react';
import LoadingSpinner from '../components/LoadingSpinner';
import { api } from '../lib/api';
import { TEN_PRINCIPLES } from '../lib/types';
import { speakPrinciplesSequentially, stopSpeaking, isTTSAvailable, initTTS } from '../lib/tts';

export default function DebriefingPage() {
  const [date, setDate] = useState(new Date().toISOString().split('T')[0]);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [existing, setExisting] = useState<any>(null);
  const [form, setForm] = useState({
    error_analysis: '',
    root_causes: '',
    improvements: '',
    chart_images: '',
    notes: '',
    overall_score: 5,
    action_plan: '',
    plan_adherence: '',
  });
  const [principles, setPrinciples] = useState<{checked: boolean; why: string}[]>(
    TEN_PRINCIPLES.map(() => ({ checked: false, why: '' }))
  );
  const [isPlayingAudio, setIsPlayingAudio] = useState(false);
  const [currentPrincipleIndex, setCurrentPrincipleIndex] = useState(-1);
  const [requestingAI, setRequestingAI] = useState(false);
  const [aiResult, setAiResult] = useState<any>(null);
  const [ttsAvailable, setTtsAvailable] = useState(false);

  useEffect(() => {
    initTTS();
    setTtsAvailable(isTTSAvailable());
  }, []);

  const fetchDebriefing = useCallback(async () => {
    setLoading(true);
    try {
      const [debriefData, aiData] = await Promise.all([
        api.getDebriefings({ date }),
        api.getCoachFeedback({ date }),
      ]);
      if (debriefData.length > 0) {
        const d = debriefData[0];
        setExisting(d);
        setForm({
          error_analysis: d.error_analysis || '',
          root_causes: d.root_causes || '',
          improvements: d.improvements || '',
          chart_images: d.chart_images || '',
          notes: d.notes || '',
          overall_score: d.overall_score || 5,
          action_plan: d.action_plan || '',
          plan_adherence: d.plan_adherence || '',
        });
        try {
          const p = JSON.parse(d.ten_principles || '[]');
          if (Array.isArray(p) && p.length === 10) setPrinciples(p);
        } catch {}
      } else {
        setExisting(null);
        setForm({ error_analysis: '', root_causes: '', improvements: '', chart_images: '', notes: '', overall_score: 5, action_plan: '', plan_adherence: '' });
        setPrinciples(TEN_PRINCIPLES.map(() => ({ checked: false, why: '' })));
      }
      setAiResult(aiData.length > 0 ? aiData[0] : null);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  }, [date]);

  useEffect(() => { fetchDebriefing(); }, [fetchDebriefing]);

  // Check for auto-alert from previous day
  useEffect(() => {
    const checkPrevDayAlert = async () => {
      const yesterday = new Date(new Date(date).getTime() - 86400000).toISOString().split('T')[0];
      try {
        const prevFeedback = await api.getCoachFeedback({ date: yesterday });
        if (prevFeedback.length > 0 && prevFeedback[0].auto_alert_triggered && ttsAvailable) {
          // Auto-play principles if previous day had deficiencies
          setTimeout(() => {
            if (confirm('⚠️ المدرب الذكي ينبهك: كان هناك تقصير في المبادئ بالأمس. هل تريد مراجعة المبادئ العشرة صوتياً؟')) {
              handlePlayPrinciples();
            }
          }, 1500);
        }
      } catch {}
    };
    if (date === new Date().toISOString().split('T')[0]) {
      checkPrevDayAlert();
    }
  }, [date, ttsAvailable]);

  const handleSave = async () => {
    setSaving(true);
    try {
      const payload = {
        debrief_date: date,
        ...form,
        ten_principles: JSON.stringify(principles),
      };
      if (existing) {
        await api.updateDebriefing({ id: existing.id, ...payload });
      } else {
        await api.createDebriefing(payload);
      }
      await fetchDebriefing();
      alert('تم الحفظ بنجاح!');
    } catch (err) {
      console.error(err);
      alert('حدث خطأ');
    } finally {
      setSaving(false);
    }
  };

  const handleRequestAI = async () => {
    setRequestingAI(true);
    try {
      const result = await api.requestCoachAnalysis({
        date,
        action_plan: form.action_plan,
        plan_adherence: form.plan_adherence,
      });
      setAiResult(result);
    } catch (err) {
      console.error(err);
      alert('حدث خطأ في طلب تحليل المدرب الذكي');
    } finally {
      setRequestingAI(false);
    }
  };

  const handlePlayPrinciples = () => {
    if (isPlayingAudio) {
      stopSpeaking();
      setIsPlayingAudio(false);
      setCurrentPrincipleIndex(-1);
      return;
    }
    setIsPlayingAudio(true);
    speakPrinciplesSequentially(
      principles.map((p, i) => ({ text: TEN_PRINCIPLES[i], checked: p.checked, why: p.why })),
      (index) => setCurrentPrincipleIndex(index),
      () => { setIsPlayingAudio(false); setCurrentPrincipleIndex(-1); }
    );
  };

  const principlesScore = principles.filter(p => p.checked).length;

  return (
    <div className="max-w-4xl mx-auto space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-bold text-white">الديلي دبريفنج</h1>
        <div className="flex items-center gap-2">
          <Calendar size={16} className="text-gray-500" />
          <input type="date" value={date} onChange={e => setDate(e.target.value)}
            className="bg-[#0d1224] border border-[#1a2340] rounded-xl px-4 py-2 text-sm text-gray-200 focus:border-emerald-500/50 focus:outline-none" />
        </div>
      </div>

      {loading ? <LoadingSpinner /> : (
        <div className="space-y-6">
          {/* Action Plan Section - NEW */}
          <div className="bg-[#0d1224] rounded-2xl border border-amber-500/20 p-6 space-y-4">
            <h2 className="text-lg font-semibold text-amber-400">📋 خطة العمل</h2>
            <div>
              <label className="block text-xs text-gray-400 mb-1">خطة العمل لهذا اليوم</label>
              <textarea value={form.action_plan} onChange={e => setForm({...form, action_plan: e.target.value})}
                className="w-full bg-[#0a0e1a] border border-[#1a2340] rounded-xl px-4 py-3 text-sm text-gray-200 focus:border-amber-500/50 focus:outline-none h-28 resize-none"
                placeholder="ما خطتك للتداول اليوم؟ الأزواج، الاستراتيجيات، حدود المخاطرة..." />
            </div>
            <div>
              <label className="block text-xs text-gray-400 mb-1">مدى الالتزام بالخطة</label>
              <textarea value={form.plan_adherence} onChange={e => setForm({...form, plan_adherence: e.target.value})}
                className="w-full bg-[#0a0e1a] border border-[#1a2340] rounded-xl px-4 py-3 text-sm text-gray-200 focus:border-amber-500/50 focus:outline-none h-28 resize-none"
                placeholder="هل التزمت بالخطة؟ ماذا تغير؟ لماذا؟" />
            </div>
          </div>

          {/* Ten Principles with Audio */}
          <div className="bg-[#0d1224] rounded-2xl border border-[#1a2340] p-6">
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-lg font-semibold text-white">المبادئ العشرة للتداول</h2>
              <div className="flex items-center gap-3">
                {ttsAvailable && (
                  <button onClick={handlePlayPrinciples}
                    className={`flex items-center gap-2 px-4 py-2 rounded-xl text-sm font-medium transition-all ${
                      isPlayingAudio
                        ? 'bg-red-500/20 text-red-400 border border-red-500/30'
                        : 'bg-blue-500/20 text-blue-400 border border-blue-500/30 hover:bg-blue-500/30'
                    }`}>
                    {isPlayingAudio ? <><VolumeX size={16} />إيقاف</> : <><Volume2 size={16} />تشغيل المهام العشر</>}
                  </button>
                )}
                <div className={`px-3 py-1 rounded-full text-sm font-medium ${
                  principlesScore >= 8 ? 'bg-emerald-500/20 text-emerald-400' :
                  principlesScore >= 5 ? 'bg-amber-500/20 text-amber-400' :
                  'bg-red-500/20 text-red-400'
                }`}>
                  {principlesScore}/10
                </div>
              </div>
            </div>
            <div className="space-y-3">
              {TEN_PRINCIPLES.map((principle, i) => (
                <motion.div key={i} initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: i * 0.05 }}
                  className={`rounded-xl border p-4 transition-all ${
                    currentPrincipleIndex === i
                      ? 'border-blue-500/50 bg-blue-500/10 ring-2 ring-blue-500/30'
                      : principles[i].checked
                        ? 'border-emerald-500/30 bg-emerald-500/5'
                        : 'border-[#1a2340] bg-[#0a0e1a]'
                  }`}>
                  <div className="flex items-start gap-3">
                    <button onClick={() => {
                      const updated = [...principles];
                      updated[i] = { ...updated[i], checked: !updated[i].checked };
                      setPrinciples(updated);
                    }} className="mt-0.5 flex-shrink-0">
                      {principles[i].checked
                        ? <CheckCircle size={22} className="text-emerald-400" />
                        : <XCircle size={22} className="text-gray-600" />
                      }
                    </button>
                    <div className="flex-1">
                      <p className="text-sm text-gray-200 mb-2">
                        {currentPrincipleIndex === i && <span className="inline-block w-2 h-2 rounded-full bg-blue-400 animate-pulse ml-2" />}
                        {i + 1}. {principle}
                      </p>
                      <input type="text" placeholder="لماذا؟ (اختياري)" value={principles[i].why}
                        onChange={e => {
                          const updated = [...principles];
                          updated[i] = { ...updated[i], why: e.target.value };
                          setPrinciples(updated);
                        }}
                        className="w-full bg-transparent border-b border-[#1a2340] px-0 py-1 text-xs text-gray-400 focus:border-emerald-500/50 focus:outline-none placeholder-gray-700" />
                    </div>
                  </div>
                </motion.div>
              ))}
            </div>
          </div>

          {/* Error Analysis */}
          <div className="bg-[#0d1224] rounded-2xl border border-[#1a2340] p-6 space-y-4">
            <h2 className="text-lg font-semibold text-white">تحليل الأخطاء والمراجعة</h2>
            <div>
              <label className="block text-xs text-gray-400 mb-1">تحليل الأخطاء</label>
              <textarea value={form.error_analysis} onChange={e => setForm({...form, error_analysis: e.target.value})}
                className="w-full bg-[#0a0e1a] border border-[#1a2340] rounded-xl px-4 py-3 text-sm text-gray-200 focus:border-emerald-500/50 focus:outline-none h-28 resize-none"
                placeholder="ما الأخطاء التي ارتكبتها اليوم؟" />
            </div>
            <div>
              <label className="block text-xs text-gray-400 mb-1">الأسباب الجذرية</label>
              <textarea value={form.root_causes} onChange={e => setForm({...form, root_causes: e.target.value})}
                className="w-full bg-[#0a0e1a] border border-[#1a2340] rounded-xl px-4 py-3 text-sm text-gray-200 focus:border-emerald-500/50 focus:outline-none h-28 resize-none"
                placeholder="ما الأسباب الحقيقية وراء هذه الأخطاء؟" />
            </div>
            <div>
              <label className="block text-xs text-gray-400 mb-1">خطة التحسين</label>
              <textarea value={form.improvements} onChange={e => setForm({...form, improvements: e.target.value})}
                className="w-full bg-[#0a0e1a] border border-[#1a2340] rounded-xl px-4 py-3 text-sm text-gray-200 focus:border-emerald-500/50 focus:outline-none h-28 resize-none"
                placeholder="كيف ستتجنب هذه الأخطاء مستقبلاً؟" />
            </div>
            <div>
              <label className="block text-xs text-gray-400 mb-1">روابط صور الشارتات</label>
              <textarea value={form.chart_images} onChange={e => setForm({...form, chart_images: e.target.value})}
                className="w-full bg-[#0a0e1a] border border-[#1a2340] rounded-xl px-4 py-3 text-sm text-gray-200 focus:border-emerald-500/50 focus:outline-none h-20 resize-none font-mono text-xs"
                placeholder="https://example.com/chart1.png" dir="ltr" />
            </div>
            <div>
              <label className="block text-xs text-gray-400 mb-1">التقييم العام (1-10)</label>
              <div className="flex items-center gap-2">
                <input type="range" min="1" max="10" value={form.overall_score}
                  onChange={e => setForm({...form, overall_score: parseInt(e.target.value)})}
                  className="flex-1 accent-emerald-500" />
                <span className={`text-lg font-bold ${
                  form.overall_score >= 7 ? 'text-emerald-400' :
                  form.overall_score >= 4 ? 'text-amber-400' : 'text-red-400'
                }`}>{form.overall_score}</span>
              </div>
            </div>
            <div>
              <label className="block text-xs text-gray-400 mb-1">ملاحظات إضافية</label>
              <textarea value={form.notes} onChange={e => setForm({...form, notes: e.target.value})}
                className="w-full bg-[#0a0e1a] border border-[#1a2340] rounded-xl px-4 py-3 text-sm text-gray-200 focus:border-emerald-500/50 focus:outline-none h-20 resize-none" />
            </div>
          </div>

          {/* Save + AI Buttons */}
          <div className="flex gap-3">
            <button onClick={handleSave} disabled={saving}
              className="flex-1 py-3 bg-gradient-to-l from-emerald-600 to-cyan-600 hover:from-emerald-700 hover:to-cyan-700 rounded-xl text-white font-semibold flex items-center justify-center gap-2 disabled:opacity-50">
              <Save size={18} />
              {saving ? 'جاري الحفظ...' : existing ? 'تحديث الدبريفنج' : 'حفظ الدبريفنج'}
            </button>
            <button onClick={handleRequestAI} disabled={requestingAI}
              className="px-6 py-3 bg-gradient-to-l from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700 rounded-xl text-white font-semibold flex items-center justify-center gap-2 disabled:opacity-50">
              {requestingAI ? <Loader2 size={18} className="animate-spin" /> : <Brain size={18} />}
              {requestingAI ? 'جاري التحليل...' : 'تقييم المدرب'}
            </button>
          </div>

          {/* AI Coach Feedback - NEW */}
          {aiResult && (
            <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }}
              className="bg-[#0d1224] rounded-2xl border border-purple-500/30 overflow-hidden">
              <div className="bg-gradient-to-l from-purple-600/20 to-blue-600/20 px-6 py-4 border-b border-purple-500/20">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <Brain size={22} className="text-purple-400" />
                    <h2 className="text-lg font-semibold text-white">تقييم المدرب الذكي</h2>
                  </div>
                  <div className={`px-3 py-1 rounded-full text-sm font-bold ${
                    (aiResult.overall_ai_score || 0) >= 7 ? 'bg-emerald-500/20 text-emerald-400' :
                    (aiResult.overall_ai_score || 0) >= 4 ? 'bg-amber-500/20 text-amber-400' :
                    'bg-red-500/20 text-red-400'
                  }`}>
                    {aiResult.overall_ai_score}/10
                  </div>
                </div>
              </div>
              <div className="p-6 space-y-5">
                {/* Strengths */}
                {aiResult.strengths && (
                  <div>
                    <h3 className="text-sm font-semibold text-emerald-400 mb-2 flex items-center gap-2">
                      ✅ نقاط القوة
                    </h3>
                    <div className="bg-emerald-500/5 border border-emerald-500/10 rounded-xl p-4">
                      <p className="text-sm text-gray-300 whitespace-pre-wrap leading-relaxed">{aiResult.strengths}</p>
                    </div>
                  </div>
                )}
                {/* Weaknesses */}
                {aiResult.weaknesses && (
                  <div>
                    <h3 className="text-sm font-semibold text-red-400 mb-2 flex items-center gap-2">
                      ❌ نقاط الضعف
                    </h3>
                    <div className="bg-red-500/5 border border-red-500/10 rounded-xl p-4">
                      <p className="text-sm text-gray-300 whitespace-pre-wrap leading-relaxed">{aiResult.weaknesses}</p>
                    </div>
                  </div>
                )}
                {/* Time Analysis */}
                {aiResult.time_analysis && (
                  <div>
                    <h3 className="text-sm font-semibold text-blue-400 mb-2">⏰ التحليل الزمني</h3>
                    <div className="bg-blue-500/5 border border-blue-500/10 rounded-xl p-4">
                      <p className="text-sm text-gray-300 whitespace-pre-wrap leading-relaxed">{aiResult.time_analysis}</p>
                    </div>
                  </div>
                )}
                {/* Consistency Check */}
                {aiResult.consistency_check && (
                  <div>
                    <h3 className="text-sm font-semibold text-amber-400 mb-2">📋 تحليل الالتزام</h3>
                    <div className="bg-amber-500/5 border border-amber-500/10 rounded-xl p-4">
                      <p className="text-sm text-gray-300 whitespace-pre-wrap leading-relaxed">{aiResult.consistency_check}</p>
                    </div>
                  </div>
                )}
                {/* Deep Insights */}
                {aiResult.deep_insights && (
                  <div>
                    <h3 className="text-sm font-semibold text-cyan-400 mb-2">🔍 الرؤية الثاقبة</h3>
                    <div className="bg-cyan-500/5 border border-cyan-500/10 rounded-xl p-4">
                      <p className="text-sm text-gray-300 whitespace-pre-wrap leading-relaxed">{aiResult.deep_insights}</p>
                    </div>
                  </div>
                )}
                {/* Open Trades */}
                {aiResult.open_trades_assessment && (
                  <div>
                    <h3 className="text-sm font-semibold text-purple-400 mb-2">📈 الصفقات المفتوحة</h3>
                    <div className="bg-purple-500/5 border border-purple-500/10 rounded-xl p-4">
                      <p className="text-sm text-gray-300 whitespace-pre-wrap leading-relaxed">{aiResult.open_trades_assessment}</p>
                    </div>
                  </div>
                )}
                {/* Recommendations */}
                {aiResult.recommendations && (
                  <div>
                    <h3 className="text-sm font-semibold text-white mb-2">💡 التوصيات</h3>
                    <div className="bg-white/5 border border-white/10 rounded-xl p-4">
                      <p className="text-sm text-gray-300 whitespace-pre-wrap leading-relaxed">{aiResult.recommendations}</p>
                    </div>
                  </div>
                )}
                {/* Alert info */}
                {aiResult.auto_alert_triggered && (
                  <div className="bg-red-500/10 border border-red-500/20 rounded-xl p-4">
                    <p className="text-sm text-red-400 font-medium">⚠️ تنبيه: سيتم تفعيل التنبيه الصوتي عند فتح الدبريفنج غداً لمراجعة المبادئ الناقصة.</p>
                  </div>
                )}
              </div>
            </motion.div>
          )}
        </div>
      )}
    </div>
  );
}
