import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import {
  Upload, FileSpreadsheet, Link2, ArrowLeft, CheckCircle, AlertCircle,
  Loader2, Download, Copy, Table, Zap, ChevronDown, ChevronUp, Edit3,
  ArrowRight, ExternalLink
} from 'lucide-react';
import { api } from '../lib/api';
import { PSYCHOLOGICAL_STATES, ENTRY_REASONS, TRADE_CLASSIFICATIONS } from '../lib/types';

type Step = 'source' | 'paste' | 'sheet' | 'review' | 'enrich' | 'done';

export default function ImportPage() {
  const navigate = useNavigate();
  const [step, setStep] = useState<Step>('source');
  const [rawData, setRawData] = useState('');
  const [sheetUrl, setSheetUrl] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [importedTrades, setImportedTrades] = useState<any[]>([]);
  const [sheetData, setSheetData] = useState<any>(null);
  const [missingCols, setMissingCols] = useState<string[]>([]);
  const [enrichIndex, setEnrichIndex] = useState(0);
  const [enrichData, setEnrichData] = useState<Record<number, any>>({});
  const [savingEnrich, setSavingEnrich] = useState(false);
  const [expandedTrade, setExpandedTrade] = useState<number | null>(null);

  // Step 1: Import from paste
  const handleImportPaste = async () => {
    if (!rawData.trim()) { setError('\u0627\u0644\u0635\u0642 \u0628\u064a\u0627\u0646\u0627\u062a \u0627\u0644\u0640 Statement'); return; }
    setLoading(true); setError('');
    try {
      const res = await fetch('/api/import-statement', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ raw_data: rawData, action: 'import' }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error);
      setImportedTrades(data.trades);
      setSheetData(data.sheet_data);
      setMissingCols(data.missing_columns || []);
      setStep('review');
    } catch (err: any) {
      setError(err.message);
    } finally { setLoading(false); }
  };

  // Step 1b: Import from Google Sheet
  const handleImportSheet = async () => {
    if (!sheetUrl.trim()) { setError('\u0623\u062f\u062e\u0644 \u0631\u0627\u0628\u0637 Google Sheet'); return; }
    setLoading(true); setError('');
    try {
      const res = await fetch('/api/import-statement', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ google_sheet_url: sheetUrl, action: 'import_sheet' }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error);
      setImportedTrades(data.trades);
      setMissingCols([
        'Entry Reason', 'Psychological State', 'Thoughts at Entry',
        'Trading Notes', 'Trade Drawdown', 'Trade Classification'
      ]);
      setStep('review');
    } catch (err: any) {
      setError(err.message);
    } finally { setLoading(false); }
  };

  // Copy sheet data to clipboard
  const copySheetData = () => {
    if (!sheetData) return;
    const text = sheetData.headers.join('\t') + '\n' + sheetData.rows.map((r: any[]) => r.join('\t')).join('\n');
    navigator.clipboard.writeText(text);
  };

  // Save enrichment data for a trade
  const handleSaveEnrich = async (tradeId: number) => {
    const data = enrichData[tradeId];
    if (!data) return;
    setSavingEnrich(true);
    try {
      await api.updateTrade({ id: tradeId, ...data });
      // Update local state
      setImportedTrades(prev => prev.map(t => t.id === tradeId ? { ...t, ...data } : t));
    } catch (err) { console.error(err); }
    finally { setSavingEnrich(false); }
  };

  // Save all enrichments and go to dashboard
  const handleFinishAndDashboard = async () => {
    setSavingEnrich(true);
    try {
      // Save any unsaved enrichments
      for (const [idStr, data] of Object.entries(enrichData)) {
        const id = parseInt(idStr);
        if (data && Object.keys(data).length > 0) {
          await api.updateTrade({ id, ...data });
        }
      }
      setStep('done');
      // Navigate to daily dashboard after short delay
      setTimeout(() => {
        const today = importedTrades[0]?.trade_date || new Date().toISOString().split('T')[0];
        navigate(`/dashboard/daily?date=${today}`);
      }, 2000);
    } catch (err) { console.error(err); }
    finally { setSavingEnrich(false); }
  };

  const updateEnrich = (tradeId: number, field: string, value: any) => {
    setEnrichData(prev => ({
      ...prev,
      [tradeId]: { ...(prev[tradeId] || {}), [field]: value }
    }));
  };

  const totalProfit = importedTrades.reduce((s, t) => s + (t.profit || 0), 0);
  const wins = importedTrades.filter(t => t.profit > 0).length;

  return (
    <div className="max-w-4xl mx-auto space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-white">\u0627\u0633\u062a\u064a\u0631\u0627\u062f Statement</h1>
          <p className="text-sm text-gray-500 mt-1">\u0627\u0633\u062a\u064a\u0631\u062f \u0645\u0646 MT4/MT5 \u0623\u0648 Google Sheets \u2192 \u0623\u0643\u0645\u0644 \u0627\u0644\u0623\u0639\u0645\u062f\u0629 \u0627\u0644\u0646\u0627\u0642\u0635\u0629 \u2192 \u0627\u0644\u062f\u0627\u0634\u0628\u0648\u0631\u062f</p>
        </div>
      </div>

      {/* Progress Steps */}
      <div className="flex items-center gap-2 overflow-x-auto pb-2">
        {[
          { key: 'source', label: '\u0627\u0644\u0645\u0635\u062f\u0631' },
          { key: 'review', label: '\u0645\u0631\u0627\u062c\u0639\u0629' },
          { key: 'enrich', label: '\u0625\u0643\u0645\u0627\u0644 \u0627\u0644\u0628\u064a\u0627\u0646\u0627\u062a' },
          { key: 'done', label: '\u0627\u0644\u062f\u0627\u0634\u0628\u0648\u0631\u062f' },
        ].map((s, i) => {
          const steps: Step[] = ['source', 'paste', 'sheet', 'review', 'enrich', 'done'];
          const currentIdx = steps.indexOf(step);
          const thisIdx = steps.indexOf(s.key as Step);
          const isActive = step === s.key || (s.key === 'source' && (step === 'paste' || step === 'sheet'));
          const isPast = thisIdx < currentIdx || (s.key === 'source' && currentIdx > 2);
          return (
            <div key={s.key} className="flex items-center gap-2 flex-shrink-0">
              <div className={`w-8 h-8 rounded-full flex items-center justify-center text-xs font-bold ${
                isActive ? 'bg-emerald-500 text-white' :
                isPast ? 'bg-emerald-500/20 text-emerald-400' :
                'bg-[#1a2340] text-gray-600'
              }`}>{isPast ? '\u2713' : i + 1}</div>
              <span className={`text-xs font-medium ${isActive ? 'text-white' : 'text-gray-500'}`}>{s.label}</span>
              {i < 3 && <ArrowLeft size={14} className="text-gray-700 mx-1" />}
            </div>
          );
        })}
      </div>

      {/* Error */}
      {error && (
        <motion.div initial={{ opacity: 0, y: -10 }} animate={{ opacity: 1, y: 0 }}
          className="bg-red-500/10 border border-red-500/20 rounded-xl p-4 flex items-center gap-3">
          <AlertCircle size={18} className="text-red-400 flex-shrink-0" />
          <p className="text-sm text-red-400">{error}</p>
        </motion.div>
      )}

      {/* Step: Source Selection */}
      {step === 'source' && (
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
          <motion.button initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.1 }}
            onClick={() => setStep('paste')}
            className="p-6 bg-[#0d1224] border border-[#1a2340] rounded-2xl hover:border-emerald-500/30 transition-all text-right group">
            <Upload size={28} className="text-emerald-400 mb-3" />
            <h3 className="text-white font-semibold mb-1">\u0644\u0635\u0642 Statement</h3>
            <p className="text-xs text-gray-500">\u0627\u0644\u0635\u0642 \u0628\u064a\u0627\u0646\u0627\u062a MT4/MT5 \u0645\u0628\u0627\u0634\u0631\u0629 (CSV/TSV/JSON)</p>
          </motion.button>

          <motion.button initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.2 }}
            onClick={() => setStep('sheet')}
            className="p-6 bg-[#0d1224] border border-[#1a2340] rounded-2xl hover:border-green-500/30 transition-all text-right group">
            <FileSpreadsheet size={28} className="text-green-400 mb-3" />
            <h3 className="text-white font-semibold mb-1">Google Sheets</h3>
            <p className="text-xs text-gray-500">\u0627\u0633\u062a\u064a\u0631\u0627\u062f \u0645\u0646 \u062c\u062f\u0648\u0644 Google Sheets \u0645\u0628\u0627\u0634\u0631\u0629</p>
          </motion.button>

          <motion.button initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.3 }}
            onClick={() => navigate('/add-trade')}
            className="p-6 bg-[#0d1224] border border-[#1a2340] rounded-2xl hover:border-blue-500/30 transition-all text-right group">
            <Edit3 size={28} className="text-blue-400 mb-3" />
            <h3 className="text-white font-semibold mb-1">\u0625\u062f\u062e\u0627\u0644 \u064a\u062f\u0648\u064a</h3>
            <p className="text-xs text-gray-500">\u0623\u0636\u0641 \u0627\u0644\u0635\u0641\u0642\u0627\u062a \u0648\u0627\u062d\u062f\u0629 \u0628\u0648\u0627\u062d\u062f\u0629</p>
          </motion.button>
        </div>
      )}

      {/* Step: Paste Data */}
      {step === 'paste' && (
        <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="space-y-4">
          <div className="bg-[#0d1224] rounded-2xl border border-[#1a2340] p-6 space-y-4">
            <div className="flex items-center justify-between">
              <h2 className="text-lg font-semibold text-white">\u0627\u0644\u0635\u0642 \u0628\u064a\u0627\u0646\u0627\u062a \u0627\u0644\u0640 Statement</h2>
              <button onClick={() => setStep('source')} className="text-xs text-gray-500 hover:text-white">\u2190 \u0631\u062c\u0648\u0639</button>
            </div>
            <p className="text-xs text-gray-500">\u0627\u0646\u0633\u062e \u0628\u064a\u0627\u0646\u0627\u062a \u0627\u0644\u0640 Statement \u0645\u0646 MT4/MT5 \u0648\u0627\u0644\u0635\u0642\u0647\u0627 \u0647\u0646\u0627. \u064a\u062f\u0639\u0645 CSV, TSV, JSON</p>
            <textarea value={rawData} onChange={e => setRawData(e.target.value)}
              className="w-full bg-[#0a0e1a] border border-[#1a2340] rounded-xl px-4 py-3 text-sm text-gray-200 focus:border-emerald-500/50 focus:outline-none h-64 resize-none font-mono text-xs"
              dir="ltr"
              placeholder="Ticket,Open Time,Close Time,Type,Lots,Symbol,Open Price,Close Price,S/L,T/P,Profit,Balance\n12345,2025-07-14 09:30,2025-07-14 11:45,buy,0.1,EURUSD,1.0852,1.0891,1.082,1.091,39.00,10039" />
            
            {/* Sample format helper */}
            <div className="bg-[#0a0e1a] rounded-xl p-4 border border-[#1a2340]">
              <p className="text-xs text-gray-500 mb-2">\u0627\u0644\u0623\u0639\u0645\u062f\u0629 \u0627\u0644\u0645\u0637\u0644\u0648\u0628\u0629 \u0641\u064a \u0627\u0644\u0640 Statement:</p>
              <div className="flex flex-wrap gap-1.5">
                {['Ticket', 'Open Time', 'Close Time', 'Type', 'Lots', 'Symbol', 'Open Price', 'Close Price', 'S/L', 'T/P', 'Profit', 'Balance'].map(col => (
                  <span key={col} className="px-2 py-0.5 rounded bg-emerald-500/10 text-emerald-400 text-[10px] font-mono">{col}</span>
                ))}
              </div>
            </div>

            <button onClick={handleImportPaste} disabled={loading}
              className="w-full py-3 bg-gradient-to-l from-emerald-600 to-cyan-600 hover:from-emerald-700 hover:to-cyan-700 rounded-xl text-white font-semibold disabled:opacity-50 flex items-center justify-center gap-2">
              {loading ? <><Loader2 size={18} className="animate-spin" />\u062c\u0627\u0631\u064a \u0627\u0644\u0627\u0633\u062a\u064a\u0631\u0627\u062f...</> : <><Zap size={18} />\u0627\u0633\u062a\u064a\u0631\u0627\u062f \u0648\u062a\u062d\u0644\u064a\u0644</>}
            </button>
          </div>
        </motion.div>
      )}

      {/* Step: Google Sheets */}
      {step === 'sheet' && (
        <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="space-y-4">
          <div className="bg-[#0d1224] rounded-2xl border border-green-500/20 p-6 space-y-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <FileSpreadsheet size={20} className="text-green-400" />
                <h2 className="text-lg font-semibold text-white">\u0627\u0633\u062a\u064a\u0631\u0627\u062f \u0645\u0646 Google Sheets</h2>
              </div>
              <button onClick={() => setStep('source')} className="text-xs text-gray-500 hover:text-white">\u2190 \u0631\u062c\u0648\u0639</button>
            </div>

            {/* Instructions */}
            <div className="bg-[#0a0e1a] rounded-xl p-4 border border-[#1a2340] space-y-3">
              <p className="text-xs font-semibold text-green-400">\u062e\u0637\u0648\u0627\u062a \u0627\u0644\u0631\u0628\u0637:</p>
              <div className="space-y-2 text-xs text-gray-400">
                <p>1\ufe0f\u20e3 \u0627\u0641\u062a\u062d Google Sheets \u0648\u0623\u0646\u0634\u0626 \u062c\u062f\u0648\u0644 \u062c\u062f\u064a\u062f</p>
                <p>2\ufe0f\u20e3 \u0627\u0644\u0635\u0642 \u0628\u064a\u0627\u0646\u0627\u062a \u0627\u0644\u0640 Statement \u0645\u0646 MT4/MT5</p>
                <p>3\ufe0f\u20e3 \u062a\u0623\u0643\u062f \u0623\u0646 \u0627\u0644\u0633\u0637\u0631 \u0627\u0644\u0623\u0648\u0644 \u064a\u062d\u062a\u0648\u064a \u0639\u0644\u0649 \u0639\u0646\u0627\u0648\u064a\u0646 \u0627\u0644\u0623\u0639\u0645\u062f\u0629</p>
                <p>4\ufe0f\u20e3 \u0634\u0627\u0631\u0643 \u0627\u0644\u062c\u062f\u0648\u0644: <span className="text-green-400">File \u2192 Share \u2192 Anyone with the link</span></p>
                <p>5\ufe0f\u20e3 \u0627\u0644\u0635\u0642 \u0627\u0644\u0631\u0627\u0628\u0637 \u0647\u0646\u0627 \u0628\u0627\u0644\u0623\u0633\u0641\u0644</p>
              </div>
            </div>

            <div>
              <label className="block text-xs text-gray-400 mb-1">\u0631\u0627\u0628\u0637 Google Sheet</label>
              <div className="flex gap-2">
                <input type="url" dir="ltr" value={sheetUrl} onChange={e => setSheetUrl(e.target.value)}
                  className="flex-1 bg-[#0a0e1a] border border-[#1a2340] rounded-xl px-4 py-2.5 text-sm text-gray-200 focus:border-green-500/50 focus:outline-none"
                  placeholder="https://docs.google.com/spreadsheets/d/..." />
              </div>
            </div>

            <button onClick={handleImportSheet} disabled={loading}
              className="w-full py-3 bg-gradient-to-l from-green-600 to-emerald-600 hover:from-green-700 hover:to-emerald-700 rounded-xl text-white font-semibold disabled:opacity-50 flex items-center justify-center gap-2">
              {loading ? <><Loader2 size={18} className="animate-spin" />\u062c\u0627\u0631\u064a \u0627\u0644\u0627\u0633\u062a\u064a\u0631\u0627\u062f...</> : <><FileSpreadsheet size={18} />\u0627\u0633\u062a\u064a\u0631\u0627\u062f \u0645\u0646 \u0627\u0644\u0634\u064a\u062a</>}
            </button>
          </div>
        </motion.div>
      )}

      {/* Step: Review Imported Data */}
      {step === 'review' && (
        <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="space-y-4">
          {/* Summary */}
          <div className="bg-[#0d1224] rounded-2xl border border-emerald-500/20 p-6">
            <div className="flex items-center gap-3 mb-4">
              <CheckCircle size={24} className="text-emerald-400" />
              <h2 className="text-lg font-semibold text-white">\u062a\u0645 \u0627\u0644\u0627\u0633\u062a\u064a\u0631\u0627\u062f \u0628\u0646\u062c\u0627\u062d!</h2>
            </div>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
              <div className="bg-[#0a0e1a] rounded-xl p-3 text-center">
                <p className="text-xs text-gray-500">\u0639\u062f\u062f \u0627\u0644\u0635\u0641\u0642\u0627\u062a</p>
                <p className="text-xl font-bold text-white">{importedTrades.length}</p>
              </div>
              <div className="bg-[#0a0e1a] rounded-xl p-3 text-center">
                <p className="text-xs text-gray-500">\u0635\u0627\u0641\u064a \u0627\u0644\u0631\u0628\u062d</p>
                <p className={`text-xl font-bold ${totalProfit >= 0 ? 'text-emerald-400' : 'text-red-400'}`}>${totalProfit.toFixed(2)}</p>
              </div>
              <div className="bg-[#0a0e1a] rounded-xl p-3 text-center">
                <p className="text-xs text-gray-500">\u0631\u0627\u0628\u062d\u0629</p>
                <p className="text-xl font-bold text-emerald-400">{wins}</p>
              </div>
              <div className="bg-[#0a0e1a] rounded-xl p-3 text-center">
                <p className="text-xs text-gray-500">\u062e\u0627\u0633\u0631\u0629</p>
                <p className="text-xl font-bold text-red-400">{importedTrades.length - wins}</p>
              </div>
            </div>
          </div>

          {/* Missing Columns Alert */}
          <div className="bg-amber-500/5 border border-amber-500/20 rounded-2xl p-5">
            <div className="flex items-center gap-2 mb-3">
              <AlertCircle size={18} className="text-amber-400" />
              <h3 className="text-sm font-semibold text-amber-400">\u0627\u0644\u0623\u0639\u0645\u062f\u0629 \u0627\u0644\u0646\u0627\u0642\u0635\u0629 - \u0623\u0643\u0645\u0644\u0647\u0627 \u0644\u062a\u062d\u0644\u064a\u0644 \u0623\u0641\u0636\u0644</h3>
            </div>
            <div className="flex flex-wrap gap-2">
              {missingCols.map(col => (
                <span key={col} className="px-3 py-1 rounded-lg bg-amber-500/10 text-amber-300 text-xs">{col}</span>
              ))}
            </div>
            <p className="text-xs text-gray-500 mt-3">\u064a\u0645\u0643\u0646\u0643 \u0625\u0643\u0645\u0627\u0644 \u0647\u0630\u0647 \u0627\u0644\u0628\u064a\u0627\u0646\u0627\u062a \u0627\u0644\u0622\u0646 \u0623\u0648 \u0644\u0627\u062d\u0642\u0627\u064b \u0645\u0646 \u0635\u0641\u062d\u0629 \u0627\u0644\u0635\u0641\u0642\u0627\u062a</p>
          </div>

          {/* Trades Table */}
          <div className="bg-[#0d1224] rounded-2xl border border-[#1a2340] overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="text-gray-500 text-xs border-b border-[#1a2340] bg-[#0a0e1a]">
                    <th className="px-3 py-2 text-right">#</th>
                    <th className="px-3 py-2 text-right">\u0627\u0644\u0631\u0645\u0632</th>
                    <th className="px-3 py-2 text-right">\u0627\u0644\u0646\u0648\u0639</th>
                    <th className="px-3 py-2 text-right">\u0627\u0644\u062d\u062c\u0645</th>
                    <th className="px-3 py-2 text-right">\u0627\u0644\u0631\u0628\u062d</th>
                    <th className="px-3 py-2 text-right">\u0627\u0644\u062a\u0627\u0631\u064a\u062e</th>
                  </tr>
                </thead>
                <tbody>
                  {importedTrades.map(t => (
                    <tr key={t.id} className="border-b border-[#1a2340]/50">
                      <td className="px-3 py-2 text-gray-500 text-xs">{t.ticket}</td>
                      <td className="px-3 py-2 font-medium text-white">{t.symbol}</td>
                      <td className="px-3 py-2">
                        <span className={`px-2 py-0.5 rounded text-xs ${t.trade_type === 'buy' ? 'bg-emerald-500/20 text-emerald-400' : 'bg-red-500/20 text-red-400'}`}>
                          {t.trade_type === 'buy' ? '\u0634\u0631\u0627\u0621' : '\u0628\u064a\u0639'}
                        </span>
                      </td>
                      <td className="px-3 py-2 text-gray-400">{t.lot_size}</td>
                      <td className={`px-3 py-2 font-semibold ${t.profit >= 0 ? 'text-emerald-400' : 'text-red-400'}`}>${t.profit?.toFixed(2)}</td>
                      <td className="px-3 py-2 text-gray-500 text-xs">{t.trade_date}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

          {/* Copy for Google Sheets */}
          {sheetData && (
            <button onClick={copySheetData}
              className="w-full py-3 bg-[#0d1224] border border-green-500/20 rounded-xl text-green-400 font-medium text-sm flex items-center justify-center gap-2 hover:bg-green-500/5">
              <Copy size={16} />\u0646\u0633\u062e \u0627\u0644\u0628\u064a\u0627\u0646\u0627\u062a \u0644\u0640 Google Sheets (\u0628\u0627\u0644\u0623\u0639\u0645\u062f\u0629 \u0627\u0644\u0643\u0627\u0645\u0644\u0629)
            </button>
          )}

          {/* Action Buttons */}
          <div className="flex gap-3">
            <button onClick={() => setStep('enrich')}
              className="flex-1 py-3 bg-gradient-to-l from-amber-600 to-orange-600 hover:from-amber-700 hover:to-orange-700 rounded-xl text-white font-semibold flex items-center justify-center gap-2">
              <Edit3 size={18} />\u0625\u0643\u0645\u0627\u0644 \u0627\u0644\u0623\u0639\u0645\u062f\u0629 \u0627\u0644\u0646\u0627\u0642\u0635\u0629
            </button>
            <button onClick={handleFinishAndDashboard} disabled={savingEnrich}
              className="flex-1 py-3 bg-gradient-to-l from-emerald-600 to-cyan-600 hover:from-emerald-700 hover:to-cyan-700 rounded-xl text-white font-semibold flex items-center justify-center gap-2 disabled:opacity-50">
              <ArrowRight size={18} />\u0627\u0644\u0630\u0647\u0627\u0628 \u0644\u0644\u062f\u0627\u0634\u0628\u0648\u0631\u062f
            </button>
          </div>
        </motion.div>
      )}

      {/* Step: Enrich Missing Data */}
      {step === 'enrich' && (
        <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="space-y-4">
          <div className="flex items-center justify-between">
            <h2 className="text-lg font-semibold text-white">\u0625\u0643\u0645\u0627\u0644 \u0627\u0644\u0628\u064a\u0627\u0646\u0627\u062a \u0627\u0644\u0646\u0627\u0642\u0635\u0629</h2>
            <button onClick={() => setStep('review')} className="text-xs text-gray-500 hover:text-white">\u2190 \u0631\u062c\u0648\u0639</button>
          </div>
          <p className="text-xs text-gray-500">\u0623\u0643\u0645\u0644 \u0627\u0644\u0628\u064a\u0627\u0646\u0627\u062a \u0644\u0643\u0644 \u0635\u0641\u0642\u0629 \u062b\u0645 \u0627\u0636\u063a\u0637 "\u0627\u0644\u062f\u0627\u0634\u0628\u0648\u0631\u062f" \u0644\u0639\u0631\u0636 \u0627\u0644\u062a\u062d\u0644\u064a\u0644</p>

          <div className="space-y-3">
            {importedTrades.map((t, idx) => {
              const isExpanded = expandedTrade === t.id;
              const ed = enrichData[t.id] || {};
              return (
                <div key={t.id} className="bg-[#0d1224] rounded-xl border border-[#1a2340] overflow-hidden">
                  <button onClick={() => setExpandedTrade(isExpanded ? null : t.id)}
                    className="w-full flex items-center justify-between p-4 text-right hover:bg-[#131b35]/50">
                    <div className="flex items-center gap-3">
                      <span className={`w-2 h-2 rounded-full ${t.profit >= 0 ? 'bg-emerald-400' : 'bg-red-400'}`} />
                      <span className="text-white font-medium">{t.symbol}</span>
                      <span className={`text-xs ${t.profit >= 0 ? 'text-emerald-400' : 'text-red-400'}`}>${t.profit?.toFixed(2)}</span>
                      <span className="text-xs text-gray-500">{t.trade_date}</span>
                      {(ed.entry_reason || ed.psychological_state) && <CheckCircle size={14} className="text-emerald-400" />}
                    </div>
                    {isExpanded ? <ChevronUp size={16} className="text-gray-500" /> : <ChevronDown size={16} className="text-gray-500" />}
                  </button>
                  <AnimatePresence>
                    {isExpanded && (
                      <motion.div initial={{ height: 0 }} animate={{ height: 'auto' }} exit={{ height: 0 }} className="overflow-hidden">
                        <div className="p-4 border-t border-[#1a2340] space-y-3">
                          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                            <div>
                              <label className="block text-xs text-gray-400 mb-1">\u062a\u0635\u0646\u064a\u0641 \u0627\u0644\u0635\u0641\u0642\u0629</label>
                              <select value={ed.trade_classification || t.trade_classification || 'intraday'}
                                onChange={e => updateEnrich(t.id, 'trade_classification', e.target.value)}
                                className="w-full bg-[#0a0e1a] border border-[#1a2340] rounded-lg px-3 py-2 text-sm text-gray-200 focus:border-emerald-500/50 focus:outline-none">
                                {TRADE_CLASSIFICATIONS.map(c => <option key={c.value} value={c.value}>{c.label}</option>)}
                              </select>
                            </div>
                            <div>
                              <label className="block text-xs text-gray-400 mb-1">\u0633\u0628\u0628 \u0627\u0644\u062f\u062e\u0648\u0644</label>
                              <select value={ed.entry_reason || ''}
                                onChange={e => updateEnrich(t.id, 'entry_reason', e.target.value)}
                                className="w-full bg-[#0a0e1a] border border-[#1a2340] rounded-lg px-3 py-2 text-sm text-gray-200 focus:border-emerald-500/50 focus:outline-none">
                                <option value="">\u0627\u062e\u062a\u0631...</option>
                                {ENTRY_REASONS.map(r => <option key={r} value={r}>{r}</option>)}
                              </select>
                            </div>
                            <div>
                              <label className="block text-xs text-gray-400 mb-1">\u0627\u0644\u062d\u0627\u0644\u0629 \u0627\u0644\u0646\u0641\u0633\u064a\u0629</label>
                              <select value={ed.psychological_state || ''}
                                onChange={e => updateEnrich(t.id, 'psychological_state', e.target.value)}
                                className="w-full bg-[#0a0e1a] border border-[#1a2340] rounded-lg px-3 py-2 text-sm text-gray-200 focus:border-emerald-500/50 focus:outline-none">
                                <option value="">\u0627\u062e\u062a\u0631...</option>
                                {PSYCHOLOGICAL_STATES.map(s => <option key={s} value={s}>{s}</option>)}
                              </select>
                            </div>
                            <div>
                              <label className="block text-xs text-gray-400 mb-1">\u062f\u0631\u0648\u0627 \u062f\u0627\u0648\u0646 ($)</label>
                              <input type="number" step="any" value={ed.trade_drawdown || ''}
                                onChange={e => updateEnrich(t.id, 'trade_drawdown', parseFloat(e.target.value) || 0)}
                                className="w-full bg-[#0a0e1a] border border-[#1a2340] rounded-lg px-3 py-2 text-sm text-gray-200 focus:border-red-500/50 focus:outline-none"
                                placeholder="0.00" />
                            </div>
                          </div>
                          <div>
                            <label className="block text-xs text-gray-400 mb-1">\u0645\u0644\u0627\u062d\u0638\u0627\u062a</label>
                            <input type="text" value={ed.trading_notes || ''}
                              onChange={e => updateEnrich(t.id, 'trading_notes', e.target.value)}
                              className="w-full bg-[#0a0e1a] border border-[#1a2340] rounded-lg px-3 py-2 text-sm text-gray-200 focus:border-emerald-500/50 focus:outline-none" />
                          </div>
                          <button onClick={() => handleSaveEnrich(t.id)} disabled={savingEnrich}
                            className="px-4 py-2 bg-emerald-600/20 text-emerald-400 rounded-lg text-xs font-medium hover:bg-emerald-600/30">
                            \u062d\u0641\u0638 \u0647\u0630\u0647 \u0627\u0644\u0635\u0641\u0642\u0629
                          </button>
                        </div>
                      </motion.div>
                    )}
                  </AnimatePresence>
                </div>
              );
            })}
          </div>

          <button onClick={handleFinishAndDashboard} disabled={savingEnrich}
            className="w-full py-4 bg-gradient-to-l from-emerald-600 to-cyan-600 hover:from-emerald-700 hover:to-cyan-700 rounded-xl text-white font-bold text-lg flex items-center justify-center gap-3 disabled:opacity-50">
            {savingEnrich ? <Loader2 size={20} className="animate-spin" /> : <ArrowRight size={20} />}
            \u062d\u0641\u0638 \u0648\u0627\u0644\u0630\u0647\u0627\u0628 \u0644\u0644\u062f\u0627\u0634\u0628\u0648\u0631\u062f
          </button>
        </motion.div>
      )}

      {/* Step: Done */}
      {step === 'done' && (
        <motion.div initial={{ scale: 0.8, opacity: 0 }} animate={{ scale: 1, opacity: 1 }}
          className="flex flex-col items-center justify-center py-16">
          <CheckCircle size={70} className="text-emerald-400 mb-4" />
          <h2 className="text-2xl font-bold text-white mb-2">\u062a\u0645 \u0628\u0646\u062c\u0627\u062d!</h2>
          <p className="text-gray-400">\u062c\u0627\u0631\u064a \u0627\u0644\u062a\u062d\u0648\u064a\u0644 \u0644\u0644\u062f\u0627\u0634\u0628\u0648\u0631\u062f...</p>
        </motion.div>
      )}
    </div>
  );
}
