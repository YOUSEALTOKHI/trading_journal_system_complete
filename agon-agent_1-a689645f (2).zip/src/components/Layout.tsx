import { useState } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import {
  BarChart3, BookOpen, FileText, MessageSquare, TrendingUp, Upload,
  Calendar, CalendarDays, Menu, X, Home, PlusCircle, ClipboardCheck, Brain,
  Shield, Compass, AlertTriangle
} from 'lucide-react';
import PsychEmergencyModal from './PsychEmergencyModal';

const navSections = [
  {
    title: null,
    items: [
      { path: '/', label: '\u0627\u0644\u0631\u0626\u064a\u0633\u064a\u0629', icon: Home },
    ]
  },
  {
    title: '\u0627\u0644\u062a\u062f\u0627\u0648\u0644',
    items: [
      { path: '/trades', label: '\u0627\u0644\u0635\u0641\u0642\u0627\u062a', icon: TrendingUp },
      { path: '/import', label: '\u0627\u0633\u062a\u064a\u0631\u0627\u062f Statement', icon: Upload },
      { path: '/add-trade', label: '\u0625\u0636\u0627\u0641\u0629 \u0635\u0641\u0642\u0629', icon: PlusCircle },
      { path: '/debriefing', label: '\u0627\u0644\u062f\u064a\u0644\u064a \u062f\u0628\u0631\u064a\u0641\u0646\u062c', icon: ClipboardCheck },
    ]
  },
  {
    title: '\u0644\u0648\u062d\u0627\u062a \u0627\u0644\u062a\u062d\u0643\u0645',
    items: [
      { path: '/dashboard/daily', label: '\u0644\u0648\u062d\u0629 \u064a\u0648\u0645\u064a\u0629', icon: Calendar },
      { path: '/dashboard/weekly', label: '\u0644\u0648\u062d\u0629 \u0623\u0633\u0628\u0648\u0639\u064a\u0629', icon: CalendarDays },
      { path: '/dashboard/monthly', label: '\u0644\u0648\u062d\u0629 \u0634\u0647\u0631\u064a\u0629', icon: BarChart3 },
    ]
  },
  {
    title: '\u0627\u0644\u0645\u062a\u062f\u0627\u0648\u0644',
    items: [
      { path: '/hub', label: '\u0645\u0631\u0643\u0632 \u0627\u0644\u0645\u062a\u062f\u0627\u0648\u0644', icon: Shield, badge: null },
      { path: '/roadmap', label: '\u0645\u0635\u0641\u0648\u0641\u0629 \u0627\u0644\u0646\u062c\u0627\u062d', icon: Compass, badge: null },
      { path: '/coach', label: '\u0627\u0644\u0645\u062f\u0631\u0628 \u0627\u0644\u0630\u0643\u064a', icon: Brain, badge: 'AI' },
    ]
  },
  {
    title: '\u0623\u062e\u0631\u0649',
    items: [
      { path: '/reports', label: '\u0627\u0644\u062a\u0642\u0627\u0631\u064a\u0631 \u0627\u0644\u0623\u0633\u0627\u0633\u064a\u0629', icon: FileText },
      { path: '/journal', label: '\u0627\u0644\u064a\u0648\u0645\u064a\u0627\u062a', icon: BookOpen },
      { path: '/chat', label: '\u0627\u0644\u0645\u0633\u0627\u0639\u062f \u0627\u0644\u0630\u0643\u064a', icon: MessageSquare },
    ]
  },
];

export default function Layout({ children }: { children: React.ReactNode }) {
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [psychModalOpen, setPsychModalOpen] = useState(false);
  const location = useLocation();

  return (
    <div className="min-h-screen bg-[#0a0e1a] text-gray-100 flex" dir="rtl">
      <AnimatePresence>
        {sidebarOpen && (
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/60 z-40 lg:hidden" onClick={() => setSidebarOpen(false)} />
        )}
      </AnimatePresence>

      <aside className={`fixed lg:static inset-y-0 right-0 z-50 w-72 bg-[#0d1224] border-l border-[#1a2340] transform transition-transform duration-300 lg:translate-x-0 ${
        sidebarOpen ? 'translate-x-0' : 'translate-x-full lg:translate-x-0'
      }`}>
        <div className="p-5 border-b border-[#1a2340]">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-emerald-500 to-cyan-500 flex items-center justify-center">
              <TrendingUp size={22} className="text-white" />
            </div>
            <div>
              <h1 className="text-lg font-bold text-white">TradeScope</h1>
              <p className="text-xs text-gray-500">{'\u0646\u0638\u0627\u0645 \u0625\u062f\u0627\u0631\u0629 \u0627\u0644\u062a\u062f\u0627\u0648\u0644'}</p>
            </div>
          </div>
        </div>
        <nav className="p-3 overflow-y-auto h-[calc(100vh-160px)]">
          {navSections.map((section, si) => (
            <div key={si} className={si > 0 ? 'mt-4' : ''}>
              {section.title && (
                <p className="px-4 py-1.5 text-[10px] font-semibold text-gray-600 uppercase tracking-wider">{section.title}</p>
              )}
              <div className="space-y-0.5">
                {section.items.map((item: any) => {
                  const isActive = location.pathname === item.path;
                  const Icon = item.icon;
                  return (
                    <Link key={item.path} to={item.path} onClick={() => setSidebarOpen(false)}
                      className={`flex items-center gap-3 px-4 py-2.5 rounded-xl transition-all duration-200 group ${
                        isActive
                          ? 'bg-gradient-to-l from-emerald-500/20 to-cyan-500/10 text-emerald-400 border border-emerald-500/20'
                          : 'text-gray-400 hover:text-gray-200 hover:bg-[#131b35]'
                      }`}>
                      <Icon size={18} className={isActive ? 'text-emerald-400' : 'text-gray-500 group-hover:text-gray-300'} />
                      <span className="text-sm font-medium">{item.label}</span>
                      {item.badge && (
                        <span className="mr-auto px-1.5 py-0.5 rounded text-[10px] bg-purple-500/20 text-purple-400">{item.badge}</span>
                      )}
                    </Link>
                  );
                })}
              </div>
            </div>
          ))}

          {/* Psych Emergency Button */}
          <div className="mt-6 px-2">
            <button onClick={() => setPsychModalOpen(true)}
              className="w-full flex items-center justify-center gap-2 px-4 py-3 rounded-xl bg-gradient-to-l from-red-900/40 to-orange-900/30 border border-red-500/20 text-red-400 hover:text-red-300 hover:border-red-500/40 transition-all group">
              <AlertTriangle size={18} className="group-hover:animate-pulse" />
              <span className="text-sm font-semibold">{'\u062d\u0627\u0644\u0629 \u0627\u0644\u0637\u0648\u0627\u0631\u0626 \u0627\u0644\u0646\u0641\u0633\u064a\u0629'}</span>
            </button>
          </div>
        </nav>
      </aside>

      <div className="flex-1 flex flex-col min-h-screen overflow-x-hidden">
        <header className="sticky top-0 z-30 bg-[#0a0e1a]/80 backdrop-blur-xl border-b border-[#1a2340] px-4 lg:px-8 py-4">
          <div className="flex items-center justify-between">
            <button onClick={() => setSidebarOpen(true)} className="lg:hidden p-2 rounded-lg bg-[#131b35] text-gray-400 hover:text-white">
              {sidebarOpen ? <X size={20} /> : <Menu size={20} />}
            </button>
            <div className="flex items-center gap-3">
              <button onClick={() => setPsychModalOpen(true)}
                className="lg:hidden p-2 rounded-lg bg-red-500/10 text-red-400 hover:bg-red-500/20" title={'\u062d\u0627\u0644\u0629 \u0627\u0644\u0637\u0648\u0627\u0631\u0626'}>
                <AlertTriangle size={18} />
              </button>
              <div className="text-sm text-gray-500">
                {new Date().toLocaleDateString('ar-EG', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' })}
              </div>
            </div>
          </div>
        </header>
        <main className="flex-1 p-4 lg:p-8">
          <motion.div key={location.pathname} initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.3 }}>
            {children}
          </motion.div>
        </main>
      </div>

      <PsychEmergencyModal isOpen={psychModalOpen} onClose={() => setPsychModalOpen(false)} />
    </div>
  );
}
