export interface Trade {
  id: number;
  ticket: string;
  open_time: string;
  close_time: string;
  trade_type: string;
  lot_size: number;
  symbol: string;
  open_price: number;
  close_price: number;
  stop_loss: number | null;
  take_profit: number | null;
  profit: number;
  balance_after: number;
  trade_date: string;
  trade_classification: string | null;
  trading_notes: string | null;
  entry_reason: string | null;
  psychological_state: string | null;
  thoughts_at_entry: string | null;
  created_at: string;
}

export interface DailyDebriefing {
  id: number;
  debrief_date: string;
  error_analysis: string | null;
  root_causes: string | null;
  improvements: string | null;
  chart_images: string | null;
  ten_principles: string | null;
  overall_score: number | null;
  notes: string | null;
  action_plan: string | null;
  plan_adherence: string | null;
  created_at: string;
}

export interface AICoachFeedback {
  id: number;
  feedback_date: string;
  trades_summary: string | null;
  debrief_summary: string | null;
  action_plan: string | null;
  action_plan_adherence: string | null;
  strengths: string | null;
  weaknesses: string | null;
  recommendations: string | null;
  time_analysis: string | null;
  consistency_check: string | null;
  deep_insights: string | null;
  open_trades_assessment: string | null;
  overall_ai_score: number | null;
  ai_model_used: string | null;
  raw_response: string | null;
  principles_deficient: string | null;
  auto_alert_triggered: boolean;
  created_at: string;
}

export interface WeeklySummary {
  id: number;
  week_start_date: string;
  week_end_date: string;
  total_trades: number;
  total_profit: number;
  win_rate: number;
  performance_review: string | null;
  next_week_goals: string | null;
  key_lessons: string | null;
  created_at: string;
}

export interface MonthlySummary {
  id: number;
  month: string;
  total_trades: number;
  total_profit: number;
  win_rate: number;
  comprehensive_review: string | null;
  development_plans: string | null;
  best_trades: string | null;
  worst_trades: string | null;
  created_at: string;
}

export interface FundamentalReport {
  id: number;
  source: string;
  original_url: string;
  original_title: string;
  summary: string;
  language: string;
  extraction_date: string;
  ai_model_used: string | null;
  tags: string | null;
  created_at: string;
}

export interface TradingStats {
  totalTrades: number;
  wins: number;
  losses: number;
  breakeven: number;
  totalProfit: number;
  winRate: number;
  avgWin: number;
  avgLoss: number;
  profitFactor: number;
  riskRewardRatio: number;
  maxDrawdown: number;
  maxConsecutiveWins: number;
  maxConsecutiveLosses: number;
  equityCurve: { date: string; balance: number; profit: number }[];
  bySymbol: Record<string, { trades: number; profit: number; wins: number }>;
  byDay: Record<string, { trades: number; profit: number; wins: number }>;
  largestWin: number;
  largestLoss: number;
}

export const TEN_PRINCIPLES = [
  'اتبع خطة التداول بدقة',
  'إدارة المخاطر (لا تخاطر بأكثر من 1-2%)',
  'حدد وقف الخسارة قبل الدخول',
  'لا تحرك وقف الخسارة في اتجاه الخسارة',
  'تداول مع الاتجاه العام',
  'انتظر تأكيد الإشارة قبل الدخول',
  'لا تتداول بدافع الانتقام',
  'حافظ على الانضباط النفسي',
  'سجّل كل صفقة وحللها',
  'راجع أداءك بانتظام وتعلم من الأخطاء',
];

export const PSYCHOLOGICAL_STATES = [
  'هادئ ومركز',
  'واثق',
  'متوتر',
  'خائف',
  'طمّاع',
  'مندفع',
  'محبط',
  'متردد',
  'متحمس بشكل مفرط',
  'منضبط',
];

export const ENTRY_REASONS = [
  'كسر مقاومة/دعم',
  'ارتداد من مستوى فيبوناتشي',
  'تقاطع متوسطات متحركة',
  'نموذج شموع انعكاسي',
  'تباعد RSI/MACD',
  'أخبار اقتصادية',
  'تحليل العرض والطلب',
  'نمط سعري (رأس وكتفين، مثلث...)',
  'إشارة من مؤشر مخصص',
  'أخرى',
];

export const TRADE_CLASSIFICATIONS = [
  { value: 'scalping', label: 'Scalping (خاطفة)', color: 'bg-purple-500/20 text-purple-400' },
  { value: 'intraday', label: 'Intraday (يومية)', color: 'bg-blue-500/20 text-blue-400' },
  { value: 'short-term', label: 'Short-term (عدة أيام)', color: 'bg-amber-500/20 text-amber-400' },
  { value: 'swing', label: 'Swing (عدة أسابيع)', color: 'bg-cyan-500/20 text-cyan-400' },
];
